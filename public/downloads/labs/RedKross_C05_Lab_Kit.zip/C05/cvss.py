#!/usr/bin/env python3
"""C05 lab: CVSS v3.1 base-score calculator (offline, deterministic).

Implements the CVSS v3.1 base-score equations exactly as specified by FIRST,
so findings can be risk-ranked consistently rather than by gut feel. It takes
a base vector string and prints the base score and severity.

  python3 cvss.py AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N
  python3 cvss.py CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N

Reference: FIRST, "CVSS v3.1 Specification Document", section 7
(base-score equations). This is the base metric group only.
"""
import math, sys

W = {
    "AV": {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.2},
    "AC": {"L": 0.77, "H": 0.44},
    "PR": {"N": 0.85, "L": 0.62, "H": 0.27},           # S:U values
    "PR_C": {"N": 0.85, "L": 0.68, "H": 0.50},          # S:C values
    "UI": {"N": 0.85, "R": 0.62},
    "C": {"H": 0.56, "L": 0.22, "N": 0.0},
    "I": {"H": 0.56, "L": 0.22, "N": 0.0},
    "A": {"H": 0.56, "L": 0.22, "N": 0.0},
}

def roundup(x):
    # CVSS v3.1 Appendix A Roundup: round up to one decimal place
    i = int(round(x * 100000))
    if i % 10000 == 0:
        return i / 100000.0
    return (math.floor(i / 10000) + 1) / 10.0

def severity(score):
    if score == 0.0: return "None"
    if score < 4.0:  return "Low"
    if score < 7.0:  return "Medium"
    if score < 9.0:  return "High"
    return "Critical"

def parse(vector):
    v = vector.strip()
    if v.upper().startswith("CVSS:3.1/"):
        v = v[len("CVSS:3.1/"):]
    m = {}
    for part in v.split("/"):
        if ":" in part:
            k, val = part.split(":", 1)
            m[k.upper()] = val.upper()
    return m

def base_score(m):
    scope_changed = m.get("S", "U") == "C"
    isc_base = 1 - (1 - W["C"][m["C"]]) * (1 - W["I"][m["I"]]) * (1 - W["A"][m["A"]])
    if scope_changed:
        impact = 7.52 * (isc_base - 0.029) - 3.25 * (isc_base - 0.02) ** 15
    else:
        impact = 6.42 * isc_base
    pr = W["PR_C"][m["PR"]] if scope_changed else W["PR"][m["PR"]]
    expl = 8.22 * W["AV"][m["AV"]] * W["AC"][m["AC"]] * pr * W["UI"][m["UI"]]
    if impact <= 0:
        return 0.0, impact, expl
    if scope_changed:
        score = roundup(min(1.08 * (impact + expl), 10))
    else:
        score = roundup(min(impact + expl, 10))
    return score, impact, expl

def main():
    if len(sys.argv) != 2:
        print("usage: python3 cvss.py <CVSS:3.1 base vector>", file=sys.stderr)
        return 2
    m = parse(sys.argv[1])
    required = ["AV", "AC", "PR", "UI", "S", "C", "I", "A"]
    missing = [k for k in required if k not in m]
    if missing:
        print("missing metrics: %s" % ",".join(missing), file=sys.stderr)
        return 2
    score, impact, expl = base_score(m)
    print("vector      : CVSS:3.1/" + "/".join("%s:%s" % (k, m[k]) for k in required))
    print("impact SC   : %.1f" % impact)
    print("exploitability: %.1f" % expl)
    print("BASE SCORE  : %.1f (%s)" % (score, severity(score)))
    return 0

if __name__ == "__main__":
    sys.exit(main())
