#!/usr/bin/env python3
"""C05 lab: retest the findings against a target (confirm remediation).

Runs the same four checks as verify.py but against a chosen port, so you can
point it at the hardened target (app_fixed.py on 8100) and confirm each
finding is closed. Retesting is what turns "we fixed it" into evidence. It
runs only against loopback.

  python3 retest.py            # defaults to 127.0.0.1:8100 (hardened target)
  python3 retest.py --port 8099
"""
import argparse, json, socket, sys, urllib.request, urllib.error

ALLOWED_HOSTS = {"127.0.0.1", "localhost"}

def req(host, port, method, path, body=None, headers=None):
    url = "http://%s:%d%s" % (host, port, path)
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(url, data=data, method=method)
    for k, v in (headers or {}).items():
        r.add_header(k, v)
    try:
        with urllib.request.urlopen(r, timeout=2) as resp:
            return resp.status, dict(resp.headers), resp.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read().decode()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8100)
    args = ap.parse_args()
    if args.host not in ALLOWED_HOSTS:
        print("REFUSED: out of scope.", file=sys.stderr)
        return 2
    s = socket.socket(); s.settimeout(1.0)
    try:
        s.connect((args.host, args.port))
    except OSError:
        print("target not reachable on %d - start the hardened app first"
              % args.port, file=sys.stderr)
        return 1
    finally:
        s.close()

    print("=" * 60)
    print("RETEST  target=%s:%d" % (args.host, args.port))
    print("=" * 60)
    results = []

    # F1 default credential
    code, _, body = req(args.host, args.port, "POST", "/login",
                        {"user": "admin", "pass": "admin"})
    closed = not (code == 200 and "administrator" in body)
    results.append(("default-credential", closed))

    # F2 IDOR: unauthenticated read of another customer's invoice
    code, _, body = req(args.host, args.port, "GET", "/invoice?id=1002")
    closed = not (code == 200 and "Rohan" in body)
    results.append(("idor", closed))

    # F3 verbose error
    _, _, body = req(args.host, args.port, "GET", "/invoice")
    closed = ("debug" not in body) and ("SELECT" not in body)
    results.append(("verbose-error", closed))

    # F4 security headers
    _, headers, _ = req(args.host, args.port, "GET", "/")
    want = ["Content-Security-Policy", "X-Content-Type-Options",
            "Strict-Transport-Security"]
    closed = all(h in headers for h in want)
    results.append(("missing-sec-headers", closed))

    for fid, closed in results:
        print("  [%-6s] %s" % ("CLOSED" if closed else "OPEN", fid))
    remaining = [fid for fid, c in results if not c]
    print("\n%d of %d findings closed." % (sum(1 for _, c in results if c),
                                           len(results)))
    if remaining:
        print("still open: %s" % ", ".join(remaining))
        return 1
    print("all findings closed - remediation verified.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
