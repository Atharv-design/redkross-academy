#!/usr/bin/env python3
"""C05 lab: scoped enumeration of the OWNED loopback target (read-only).

Enumerates the in-scope lab service on 127.0.0.1 only. It REFUSES to run
against any other address, mirroring the rules-of-engagement boundary: a
tester's tooling should make out-of-scope action hard, not easy.

It performs two safe, non-destructive steps against the learner's own
target:
  1. a loopback TCP connect check on the agreed port (is the service up?);
  2. HTTP endpoint discovery from a small built-in word list, recording the
     status code and content type of each path.

No payloads, no fuzzing of inputs, no writes. This maps exposure; it does
not attack.

  python3 enumerate.py                 # defaults to 127.0.0.1:8099
  python3 enumerate.py --port 8099
"""
import argparse, json, socket, sys, urllib.request, urllib.error

ALLOWED_HOSTS = {"127.0.0.1", "localhost"}
WORDLIST = ["", "login", "admin", "invoice", "robots.txt", "status",
            "health", "backup", "config", ".git"]

def in_scope(host):
    return host in ALLOWED_HOSTS

def tcp_up(host, port, timeout=1.0):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect((host, port))
        return True
    except OSError:
        return False
    finally:
        s.close()

def probe(host, port, path):
    url = "http://%s:%d/%s" % (host, port, path)
    req = urllib.request.Request(url, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=2) as r:
            return r.status, r.headers.get("Content-Type", "-"), \
                   r.headers.get("Server", "-")
    except urllib.error.HTTPError as e:
        return e.code, e.headers.get("Content-Type", "-"), \
               e.headers.get("Server", "-")
    except urllib.error.URLError:
        return None, "-", "-"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8099)
    args = ap.parse_args()

    if not in_scope(args.host):
        print("REFUSED: %s is out of scope. This lab tool runs only against "
              "the loopback target you own (127.0.0.1)." % args.host,
              file=sys.stderr)
        return 2

    print("=" * 60)
    print("SCOPED ENUMERATION  target=%s:%d (in scope)" % (args.host, args.port))
    print("=" * 60)
    if not tcp_up(args.host, args.port):
        print("service not reachable - start target/app.py first")
        return 1
    print("[tcp] %s:%d open\n" % (args.host, args.port))
    print("%-14s %-6s %-26s %s" % ("path", "code", "content-type", "server"))
    print("-" * 60)
    findings = []
    for w in WORDLIST:
        code, ctype, server = probe(args.host, args.port, w)
        shown = "/" + w if w else "/"
        print("%-14s %-6s %-26s %s" % (shown, code if code else "-", ctype, server))
        if code == 200 and w in ("robots.txt", "invoice"):
            findings.append(shown)
    print("\nnotes:")
    print("  - Server header discloses the software/version (an exposure).")
    print("  - /robots.txt is readable and lists paths meant to be hidden.")
    print("  - record these in your asset inventory; verify, do not assume.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
