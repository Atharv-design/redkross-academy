# Rules of Engagement and Authorisation - Course 05 lab (TEMPLATE)

This is a FICTIONAL, FILLED-IN example of the authorisation and scope
document that MUST exist before any authorised test. In this course the
"client" and the "tester" are both you, and the target is a lab you run on
your own machine. In real work this document is signed by someone with the
authority to permit the testing, before any activity begins.

## 1. Parties and authority
- Client: Nilgiri Parts Pvt Ltd (fictional). Authorising signatory: the
  CISO (fictional), who confirms ownership of the target and authority to
  permit testing.
- Tester: the learner, operating only on their own machine.

## 2. Authorised target (in scope)
- The single host 127.0.0.1 (loopback on the tester's own machine) running
  the lab target `target/app.py` on TCP 8099.
- NOTHING ELSE. No other address, host, network, domain, or cloud account
  is in scope. The loopback restriction is enforced by the target itself.

## 3. Explicitly out of scope
- Any system the learner does not own.
- Any production system, any third party, any public internet host.
- Denial-of-service, data destruction, and any test that could affect
  availability beyond the single lab process.

## 4. Permitted activities
- Reconnaissance and enumeration of the in-scope loopback service.
- Controlled verification (safe proof-of-concept) of specific findings.
- Evidence collection (request/response captures with timestamps).

## 5. Windows and handling
- Test window: any time, on the learner's own machine.
- Evidence (data/) is lab-only and fictional; delete it when finished.
- Any real personal data encountered in a real engagement would be
  minimised and handled per the client's instructions and applicable law
  (in India: the DPDP Act 2023 and CERT-In Directions; seek counsel).

## 6. Safety and stop conditions
- Stop immediately if any activity would reach a system not listed in
  section 2, or if the target behaves unexpectedly.
- Report critical findings to the (fictional) client contact promptly
  rather than continuing to exploit.

## 7. Legal note (India)
Unauthorised access to a computer resource is an offence under the
Information Technology Act, 2000 (for example sections 43 and 66).
Authorisation is what separates this lawful lab exercise from a crime. This
template is not legal advice.
