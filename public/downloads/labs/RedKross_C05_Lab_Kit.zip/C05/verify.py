#!/usr/bin/env python3
"""C05 lab: controlled verification of findings on the OWNED target.

Turns suspected weaknesses into CONFIRMED findings with evidence, against
the in-scope loopback target only. Each check is the minimum, safe
proof-of-concept needed to demonstrate the issue is real - no more. It makes
no destructive change, writes nothing to the target, and refuses any host
other than loopback (the rules-of-engagement boundary in code).

Checks (all against your own target):
  1. default-credential     : does admin/admin return an administrator role?
  2. idor                   : can an unauthenticated request read an invoice
                              that belongs to another customer?
  3. verbose-error          : does an error response leak internal detail?
  4. missing-sec-headers    : are standard security headers absent?

Each confirmed check is written to data/findings.json with a timestamp as
evidence for the report.

  python3 verify.py
"""
import json, socket, sys, time, urllib.request, urllib.error, os

ALLOWED_HOSTS = {"127.0.0.1", "localhost"}
HOST, PORT = "127.0.0.1", 8099
HERE = os.path.dirname(os.path.abspath(__file__))

def req(method, path, body=None):
    url = "http://%s:%d%s" % (HOST, PORT, path)
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(url, data=data, method=method)
    try:
        with urllib.request.urlopen(r, timeout=2) as resp:
            return resp.status, dict(resp.headers), resp.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read().decode()

def check_default_cred():
    code, _, body = req("POST", "/login", {"user": "admin", "pass": "admin"})
    ok = code == 200 and '"role": "administrator"' in body
    return ok, "admin/admin accepted, returns administrator role" if ok \
        else "default credential not accepted"

def check_idor():
    # Read an invoice with no authentication at all. In a correct app this
    # must be denied unless the caller owns the invoice.
    code, _, body = req("GET", "/invoice?id=1002")
    ok = code == 200 and "Rohan" in body
    return ok, "unauthenticated read of another customer's invoice 1002" if ok \
        else "invoice read was not possible without auth"

def check_verbose_error():
    code, _, body = req("GET", "/invoice")
    ok = "debug" in body or "SELECT" in body
    return ok, "error response leaks internal query/detail" if ok \
        else "no verbose error observed"

def check_sec_headers():
    _, headers, _ = req("GET", "/")
    want = ["Content-Security-Policy", "X-Content-Type-Options",
            "Strict-Transport-Security"]
    missing = [h for h in want if h not in headers]
    ok = len(missing) == len(want)
    return ok, "missing security headers: %s" % ", ".join(missing) if missing \
        else "security headers present"

CHECKS = [
    ("default-credential", "Default administrator credential (admin/admin)",
     "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", check_default_cred),
    ("idor", "Insecure direct object reference on /invoice",
     "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N", check_idor),
    ("verbose-error", "Verbose error disclosure on /invoice",
     "AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N", check_verbose_error),
    ("missing-sec-headers", "Missing HTTP security headers",
     "AV:N/AC:H/PR:N/UI:R/S:U/C:L/I:N/A:N", check_sec_headers),
]

def main():
    if HOST not in ALLOWED_HOSTS:
        print("REFUSED: out of scope.", file=sys.stderr)
        return 2
    # confirm scope: target must be reachable on loopback
    s = socket.socket(); s.settimeout(1.0)
    try:
        s.connect((HOST, PORT))
    except OSError:
        print("target not reachable - start target/app.py first", file=sys.stderr)
        return 1
    finally:
        s.close()

    print("=" * 64)
    print("CONTROLLED VERIFICATION  target=%s:%d (in scope, owned)" % (HOST, PORT))
    print("=" * 64)
    confirmed = []
    for fid, title, vector, fn in CHECKS:
        ok, detail = fn()
        status = "CONFIRMED" if ok else "not present"
        print("[%-10s] %-42s %s" % (status, title, vector if ok else ""))
        print("             %s" % detail)
        if ok:
            confirmed.append({"id": fid, "title": title, "vector": vector,
                              "evidence": detail,
                              "verified_utc": time.strftime(
                                  "%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
    out = os.path.join(HERE, "data", "findings.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(confirmed, fh, indent=2)
    print("\n%d finding(s) confirmed; evidence written to data/findings.json"
          % len(confirmed))
    return 0

if __name__ == "__main__":
    sys.exit(main())
