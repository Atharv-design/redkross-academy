C05 - ETHICAL HACKING AND PENETRATION TESTING : LAB ASSETS
==========================================================
AUTHORISED-LAB-ONLY. Every tool here runs against a target you build and own
and that binds to 127.0.0.1 (loopback) only. The tools REFUSE any other
address in code. Never point any of this at a system you do not own and are
not explicitly authorised to test. Every company, person and value is
fictional.

The lab teaches the professional penetration-testing method end to end:
authorisation and scope, reconnaissance and enumeration, controlled
verification (safe proof-of-concept), CVSS risk-ranking, reporting with
remediation, and retesting to confirm fixes.

CONTENTS
  scope.md            a filled-in Rules of Engagement / authorisation template
  target/app.py       the authorised lab target (deliberately vulnerable),
                      Nilgiri Parts Portal, http://127.0.0.1:8099
  target/app_fixed.py the hardened version (all findings fixed),
                      http://127.0.0.1:8100
  enumerate.py        scoped endpoint enumeration (loopback only; refuses
                      out-of-scope hosts)
  cvss.py             CVSS v3.1 base-score calculator (offline)
  verify.py           controlled verification of findings -> data/findings.json
  report.py           risk-ranked report with remediation and retest steps
  retest.py           re-runs the checks (point at 8100 to confirm fixes)
  data/               saved tool output and evidence

RUN (from this directory; Python 3.10+; no third-party packages)
  python target/app.py &            # start the vulnerable target (8099)
  python enumerate.py               # map the exposure
  python verify.py                  # confirm findings with evidence
  python report.py                  # produce the risk-ranked report
  python target/app_fixed.py &      # start the hardened target (8100)
  python retest.py --port 8100      # confirm every finding is closed

VERIFIED OUTPUTS (execution-tested, CPython 3.14.4, 2026-11-08)
  * enumerate.py maps /, /robots.txt (info leak), /invoice, and discloses the
    Server header; refuses a non-loopback host with exit code 2.
  * cvss.py matches FIRST reference scores: 7.5, 10.0, 9.8 for the sample
    vectors.
  * verify.py confirms 4 findings: default credential (CVSS 9.8 Critical),
    IDOR (7.5 High), verbose error (5.3 Medium), missing security headers
    (3.1 Low); writes data/findings.json with timestamps.
  * report.py ranks them and attaches remediation and a retest step.
  * retest.py: against the vulnerable target (8099) all 4 are OPEN; against
    the hardened target (8100) all 4 are CLOSED - remediation verified.

SAFETY
  - The target binds to loopback and the tools refuse non-loopback hosts, by
    design, so the lab cannot reach anyone else's systems.
  - No weaponised payloads are included; verification uses the minimum safe
    proof that a finding is real.
  - Delete data/ (fictional evidence) when finished. Stop the servers with
    Ctrl-C (or stop the background processes).
