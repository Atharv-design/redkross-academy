#!/usr/bin/env python3
"""C05 lab: build a risk-ranked findings report from confirmed evidence.

Reads data/findings.json (written by verify.py), scores each finding with
the CVSS v3.1 calculator (cvss.py), attaches remediation and a retest step,
and prints an ordered report plus a one-line executive summary. This is the
deliverable that makes a test useful: ranked findings a team can act on and
verify.

  python3 report.py
"""
import json, os, sys
import cvss  # local module

HERE = os.path.dirname(os.path.abspath(__file__))

REMEDIATION = {
    "default-credential": (
        "Remove the default account; require a unique strong credential set "
        "at first use; add rate limiting and MFA for administrative logins.",
        "Re-run verify.py: the default-credential check must report 'not "
        "present'."),
    "idor": (
        "Enforce an authorisation check on every object access: confirm the "
        "authenticated caller owns (or may see) the requested invoice before "
        "returning it. Use unguessable identifiers as defence in depth.",
        "Re-run verify.py: the idor check must fail to read another "
        "customer's invoice without authorisation."),
    "verbose-error": (
        "Return generic error messages to clients; log internal detail "
        "server-side only; never expose queries or internal hints.",
        "Re-run verify.py: the verbose-error check must find no leaked "
        "internal detail."),
    "missing-sec-headers": (
        "Set Content-Security-Policy, X-Content-Type-Options: nosniff and, "
        "over TLS, Strict-Transport-Security; review the full header set.",
        "Re-run verify.py: the missing-sec-headers check must report the "
        "headers present."),
}

def score(vector):
    m = cvss.parse(vector)
    s, _, _ = cvss.base_score(m)
    return s, cvss.severity(s)

def main():
    path = os.path.join(HERE, "data", "findings.json")
    if not os.path.exists(path):
        print("no findings.json - run verify.py first", file=sys.stderr)
        return 1
    findings = json.load(open(path, encoding="utf-8"))
    for f in findings:
        f["score"], f["severity"] = score(f["vector"])
    findings.sort(key=lambda f: -f["score"])

    print("=" * 70)
    print("PENETRATION TEST REPORT - Nilgiri Parts Portal (authorised lab)")
    print("=" * 70)
    top = findings[0] if findings else None
    crit = sum(1 for f in findings if f["severity"] in ("Critical", "High"))
    if top:
        print("Executive summary: %d finding(s), %d high/critical. Most "
              "serious: %s (CVSS %.1f %s). Fix the critical items before any "
              "exposure beyond the lab." % (len(findings), crit, top["title"],
                                            top["score"], top["severity"]))
    print()
    for i, f in enumerate(findings, 1):
        rem, retest = REMEDIATION.get(f["id"], ("-", "-"))
        print("F%d  [%-8s CVSS %.1f]  %s" % (i, f["severity"], f["score"],
                                             f["title"]))
        print("    vector     : CVSS:3.1/%s" % f["vector"])
        print("    evidence   : %s (verified %s)" % (f["evidence"],
                                                     f["verified_utc"]))
        print("    remediation: %s" % rem)
        print("    retest     : %s" % retest)
        print()
    print("Ordering is by CVSS base score; a real report also weighs business "
          "context and the client's risk appetite.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
