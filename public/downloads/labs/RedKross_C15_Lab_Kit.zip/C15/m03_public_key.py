"""Course 15 Module 3 lab: public-key cryptography.

1. RSA-3072 with OAEP encryption (small data / key transport).
2. Ed25519 and ECDSA P-256 signatures (verify ok / tampered fails).
3. X25519 key agreement + HKDF: both sides derive the same session key.
4. Key and signature sizes.
Tested: CPython 3.14.4, cryptography 48.0.0, 2026-11-07.
"""
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, padding, rsa, x25519
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

msg = b"release shipments-1.0.0 sha256=d6ec461b... (FICTIONAL)"

print("== 1. RSA-3072 OAEP")
rk = rsa.generate_private_key(public_exponent=65537, key_size=3072)
oaep = padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
secret = b"32-byte data key for envelope..."
ct = rk.public_key().encrypt(secret, oaep)
print(f"  ciphertext {len(ct)} bytes; decrypt ok: {rk.decrypt(ct, oaep) == secret}")
max_len = 3072 // 8 - 2 * 32 - 2
print(f"  max OAEP-SHA256 plaintext for RSA-3072: {max_len} bytes")
try:
    rk.public_key().encrypt(b"x" * (max_len + 1), oaep)
except ValueError as e:
    print("  too long ->", type(e).__name__)

print("== 2. signatures")
ek = ed25519.Ed25519PrivateKey.generate()
sig = ek.sign(msg)
ek.public_key().verify(sig, msg)
print(f"  Ed25519 signature {len(sig)} bytes: verify ok")
try:
    ek.public_key().verify(sig, msg.replace(b"1.0.0", b"1.0.1"))
except InvalidSignature:
    print("  Ed25519 tampered message -> InvalidSignature")
pk = ec.generate_private_key(ec.SECP256R1())
s2 = pk.sign(msg, ec.ECDSA(hashes.SHA256()))
pk.public_key().verify(s2, msg, ec.ECDSA(hashes.SHA256()))
print(f"  ECDSA P-256 signature {len(s2)} bytes (DER, varies): verify ok")

print("== 3. X25519 + HKDF")
a, b = x25519.X25519PrivateKey.generate(), x25519.X25519PrivateKey.generate()
shared_a = a.exchange(b.public_key()); shared_b = b.exchange(a.public_key())
kdf = lambda s: HKDF(algorithm=hashes.SHA256(), length=32, salt=None,
                     info=b"tamarind session v1").derive(s)
print("  shared secrets equal:", shared_a == shared_b, " derived keys equal:", kdf(shared_a) == kdf(shared_b))

print("== 4. public key sizes (DER SubjectPublicKeyInfo)")
der = lambda k: len(k.public_bytes(serialization.Encoding.DER,
                                   serialization.PublicFormat.SubjectPublicKeyInfo))
print(f"  RSA-3072: {der(rk.public_key())} bytes  P-256: {der(pk.public_key())} bytes  "
      f"Ed25519: {der(ek.public_key())} bytes")
