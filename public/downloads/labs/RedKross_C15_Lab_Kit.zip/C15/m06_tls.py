"""Course 15 Module 6 lab: TLS on localhost with the Module 5 lab PKI.

A server thread presents leaf + intermediate (minimum TLS 1.2). Clients:
  1. trusts the lab root, correct name   -> handshake, shows version/cipher
  2. wrong server name                   -> hostname mismatch
  3. default trust store (no lab root)   -> unknown CA
  4. client capped at TLS 1.1            -> refused (server minimum 1.2)
  5. server pinned to TLS 1.3 only, client max 1.2 -> refused
Run after m05_pki_lab.sh. Tested: CPython 3.14.4 (OpenSSL 3.x), 2026-11-07.
Only 127.0.0.1 is used.
"""
import socket
import ssl
import threading

PKI = "pki/"
open(PKI + "chain.pem", "w").write(open(PKI + "leaf.crt").read() + open(PKI + "int.crt").read())


def serve(ctx):
    srv = socket.create_server(("127.0.0.1", 0))
    port = srv.getsockname()[1]

    def loop():
        while True:
            try:
                c, _ = srv.accept()
            except OSError:
                return
            try:
                with ctx.wrap_socket(c, server_side=True) as s:
                    s.sendall(b"hello from track.tamarind.example\n")
            except (ssl.SSLError, OSError):
                pass
    threading.Thread(target=loop, daemon=True).start()
    return srv, port


def server_ctx(minimum=ssl.TLSVersion.TLSv1_2, maximum=None):
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = minimum
    if maximum:
        ctx.maximum_version = maximum
    ctx.load_cert_chain(PKI + "chain.pem", PKI + "leaf.key")
    return ctx


def client(port, name, cafile=PKI + "root.crt", maxv=None):
    ctx = ssl.create_default_context(cafile=cafile) if cafile else ssl.create_default_context()
    if maxv:
        ctx.minimum_version = ssl.TLSVersion.MINIMUM_SUPPORTED
        ctx.maximum_version = maxv
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=5) as raw:
            with ctx.wrap_socket(raw, server_hostname=name) as s:
                data = s.recv(100).decode().strip()
                return f"OK {s.version()} {s.cipher()[0]} | {data}"
    except ssl.SSLCertVerificationError as e:
        return f"CERT ERROR: {e.verify_message}"
    except (ssl.SSLError, OSError) as e:
        return f"HANDSHAKE ERROR: {type(e).__name__}: {str(e)[:70]}"


print("Python", ssl.OPENSSL_VERSION)
srv, port = serve(server_ctx())
print("1.", client(port, "track.tamarind.example"))
print("2.", client(port, "portal.tamarind.example"))
print("3.", client(port, "track.tamarind.example", cafile=None))
print("4.", client(port, "track.tamarind.example", maxv=ssl.TLSVersion.TLSv1_1))
srv.close()
srv13, port13 = serve(server_ctx(minimum=ssl.TLSVersion.TLSv1_3))
print("5.", client(port13, "track.tamarind.example", maxv=ssl.TLSVersion.TLSv1_2))
srv13.close()
