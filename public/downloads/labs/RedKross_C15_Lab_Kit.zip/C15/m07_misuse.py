"""Course 15 Module 7 lab: common cryptographic misuse, shown so it can be
recognised and prevented in code review.

1. Nonce reuse with a stream mode (AES-CTR): XOR of two ciphertexts equals
   XOR of the two plaintexts, so knowing one message reveals the other.
2. A safe nonce strategy for AES-GCM: random 96-bit nonces with a per-key
   message limit, or a counter.
3. Deriving a key from a password: SHA-256(password) versus scrypt with salt.
4. Comparing MACs: == versus hmac.compare_digest (behaviour, not timing).
Tested: CPython 3.14.4, cryptography 48.0.0, 2026-11-07. Data fictional.
"""
import hashlib
import hmac
import os

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

key = os.urandom(32)
nonce = os.urandom(16)


def ctr(data, n):
    e = Cipher(algorithms.AES(key), modes.CTR(n)).encryptor()
    return e.update(data) + e.finalize()


p1 = b"Pay vendor 4410 INR 25,000.00 now"
p2 = b"Staff bonus pool INR 9,99,000 Q4!"
c1, c2 = ctr(p1, nonce), ctr(p2, nonce)          # MISUSE: same key + nonce
xor_c = bytes(a ^ b for a, b in zip(c1, c2))
xor_p = bytes(a ^ b for a, b in zip(p1, p2))
print("== 1. nonce reuse (AES-CTR)")
print("  C1 xor C2 == P1 xor P2:", xor_c == xor_p)
recovered = bytes(a ^ b for a, b in zip(xor_c, p1))
print("  knowing P1 recovers P2:", recovered.decode())
c3 = ctr(p2, os.urandom(16))                     # correct: fresh nonce
print("  with a fresh nonce, relation holds:",
      bytes(a ^ b for a, b in zip(c1, c3)) == xor_p)

print("== 2. GCM nonce budget (random 96-bit nonces)")
print("  NIST SP 800-38D guidance: with random nonces, limit invocations per key")
print("  to 2**32 messages; rotate keys well before that, or use a counter nonce.")

print("== 3. password -> key")
pw = b"Tamarind2026!"
weak = hashlib.sha256(pw).digest()
salt = os.urandom(16)
strong = hashlib.scrypt(pw, salt=salt, n=2**14, r=8, p=1, dklen=32)
print("  sha256(pw) identical across users/systems:", weak == hashlib.sha256(pw).digest())
print("  scrypt with a different salt differs:",
      strong != hashlib.scrypt(pw, salt=os.urandom(16), n=2**14, r=8, p=1, dklen=32))

print("== 4. MAC comparison")
mac = hmac.new(key, b"msg", hashlib.sha256).digest()
print("  compare_digest equal:", hmac.compare_digest(mac, mac),
      " different:", hmac.compare_digest(mac, bytes(32)))
print("  (== also returns correct booleans; the risk is timing, which compare_digest")
print("   avoids by not short-circuiting - not measurable reliably in this lab)")
