"""Course 15 Module 2 lab: symmetric encryption done right and wrong.

1. AES-256-GCM: encrypt, decrypt, and detect tampering (InvalidTag).
2. Associated data (AAD) binds context: wrong AAD fails.
3. ChaCha20-Poly1305 as an alternative AEAD.
4. Why ECB is unsafe: identical plaintext blocks give identical ciphertext.
5. Envelope encryption: a data key wrapped by a key-encryption key.
Tested: CPython 3.14.4, cryptography 48.0.0, 2026-11-07.
"""
import os

import cryptography
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
from cryptography.hazmat.primitives.keywrap import aes_key_unwrap, aes_key_wrap

print("cryptography", cryptography.__version__)
msg = b"Shipment TL-00000001 delivered to gate 4 (FICTIONAL)"
aad = b"tenant=tamarind;record=TL-00000001"

print("== 1. AES-256-GCM")
key = AESGCM.generate_key(bit_length=256)
nonce = os.urandom(12)
ct = AESGCM(key).encrypt(nonce, msg, aad)
print(f"  plaintext {len(msg)} bytes -> ciphertext+tag {len(ct)} bytes (16-byte tag)")
print("  decrypt ok:", AESGCM(key).decrypt(nonce, ct, aad) == msg)
bad = bytearray(ct); bad[0] ^= 0x01
try:
    AESGCM(key).decrypt(nonce, bytes(bad), aad)
except InvalidTag:
    print("  1 flipped bit -> InvalidTag (tampering detected)")

print("== 2. associated data must match")
try:
    AESGCM(key).decrypt(nonce, ct, b"tenant=other;record=TL-00000001")
except InvalidTag:
    print("  wrong AAD -> InvalidTag")

print("== 3. ChaCha20-Poly1305")
k2 = ChaCha20Poly1305.generate_key(); n2 = os.urandom(12)
print("  roundtrip ok:", ChaCha20Poly1305(k2).decrypt(n2, ChaCha20Poly1305(k2).encrypt(n2, msg, aad), aad) == msg)

print("== 4. ECB leaks patterns (demonstration only - never use ECB)")
block = b"PAYROLL-RECORD-1"            # exactly 16 bytes
pt = block * 3 + b"UNIQUE-TAIL-0001"
enc = Cipher(algorithms.AES(key), modes.ECB()).encryptor()
ecb = enc.update(pt) + enc.finalize()
blocks = [ecb[i:i + 16].hex()[:12] for i in range(0, len(ecb), 16)]
print("  ECB blocks:", blocks, "-> distinct:", len(set(blocks)), "of", len(blocks))
gcm = AESGCM(key).encrypt(os.urandom(12), pt, None)
gblocks = [gcm[i:i + 16].hex()[:12] for i in range(0, 64, 16)]
print("  GCM blocks:", gblocks, "-> distinct:", len(set(gblocks)), "of", len(gblocks))

print("== 5. envelope encryption")
kek = os.urandom(32)                    # key-encryption key (would live in a KMS/HSM)
dek = AESGCM.generate_key(bit_length=256)
wrapped = aes_key_wrap(kek, dek)
print(f"  data key {len(dek)} bytes wrapped -> {len(wrapped)} bytes (RFC 3394)")
print("  unwrap matches:", aes_key_unwrap(kek, wrapped) == dek)
