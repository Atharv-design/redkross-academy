"""Course 15 Module 4 lab: hashing, HMAC and password hashing.

1. Avalanche: one character changes about half the SHA-256 output bits.
2. HMAC-SHA256 verification and constant-time comparison.
3. Password hashing: scrypt and PBKDF2 timings versus plain SHA-256.
Tested: CPython 3.14.4, 2026-11-07.
"""
import hashlib
import hmac
import os
import time

print("== 1. avalanche")
h1 = hashlib.sha256(b"Invoice total: 1,234,567 INR").digest()
h2 = hashlib.sha256(b"Invoice total: 1,234,568 INR").digest()
diff = sum(bin(x ^ y).count("1") for x, y in zip(h1, h2))
print(f"  {h1.hex()[:32]}...\n  {h2.hex()[:32]}...\n  differing bits: {diff} of 256")

print("== 2. HMAC")
key = os.urandom(32)
body = b'{"tracking":"TL-00000001","status":"delivered"}'
tag = hmac.new(key, body, hashlib.sha256).hexdigest()
print("  tag:", tag[:32] + "...")
ok = hmac.compare_digest(tag, hmac.new(key, body, hashlib.sha256).hexdigest())
forged = hmac.compare_digest(tag, hmac.new(key, body.replace(b"delivered", b"returned"),
                                           hashlib.sha256).hexdigest())
print("  genuine verifies:", ok, " modified body verifies:", forged)

print("== 3. password hashing cost (one guess)")
pw, salt = b"correct horse battery staple", os.urandom(16)


def timed(label, f, n):
    t = time.perf_counter()
    for _ in range(n):
        f()
    per = (time.perf_counter() - t) / n
    print(f"  {label:34} {per * 1000:9.3f} ms/guess  ~{1 / per:12,.0f} guesses/s/core")


timed("sha256 (unsuitable)", lambda: hashlib.sha256(salt + pw).digest(), 20000)
timed("pbkdf2-sha256, 600000 iterations", lambda: hashlib.pbkdf2_hmac("sha256", pw, salt, 600000), 3)
timed("scrypt n=2**14 r=8 p=1", lambda: hashlib.scrypt(pw, salt=salt, n=2**14, r=8, p=1), 5)
