#!/bin/sh
# Course 15 Module 5 lab: a three-tier PKI with OpenSSL and chain validation.
# Creates FICTIONAL root CA -> intermediate CA -> server leaf (SAN
# track.tamarind.example), then verifies the chain and shows four failures.
set -e
export MSYS_NO_PATHCONV=1
rm -rf pki && mkdir pki && cd pki
openssl version
cat > root.cnf <<'C'
[req]
distinguished_name=dn
prompt=no
[dn]
CN=Tamarind Lab Root CA (FICTIONAL)
[v3_ca]
basicConstraints=critical,CA:TRUE
keyUsage=critical,keyCertSign,cRLSign
subjectKeyIdentifier=hash
[v3_int]
basicConstraints=critical,CA:TRUE,pathlen:0
keyUsage=critical,keyCertSign,cRLSign
subjectKeyIdentifier=hash
authorityKeyIdentifier=keyid
[v3_leaf]
basicConstraints=critical,CA:FALSE
keyUsage=critical,digitalSignature
extendedKeyUsage=serverAuth
subjectAltName=DNS:track.tamarind.example
subjectKeyIdentifier=hash
authorityKeyIdentifier=keyid
C
openssl genpkey -algorithm EC -pkeyopt ec_paramgen_curve:P-256 -out root.key 2>/dev/null
openssl req -x509 -new -key root.key -config root.cnf -extensions v3_ca -days 3650 -out root.crt
openssl genpkey -algorithm EC -pkeyopt ec_paramgen_curve:P-256 -out int.key 2>/dev/null
openssl req -new -key int.key -subj "/CN=Tamarind Lab Issuing CA (FICTIONAL)" -out int.csr
openssl x509 -req -in int.csr -CA root.crt -CAkey root.key -CAcreateserial -days 1825 \
  -extfile root.cnf -extensions v3_int -out int.crt 2>/dev/null
openssl genpkey -algorithm EC -pkeyopt ec_paramgen_curve:P-256 -out leaf.key 2>/dev/null
openssl req -new -key leaf.key -subj "/CN=track.tamarind.example" -out leaf.csr
openssl x509 -req -in leaf.csr -CA int.crt -CAkey int.key -CAcreateserial -days 90 \
  -extfile root.cnf -extensions v3_leaf -out leaf.crt 2>/dev/null
echo "== leaf summary"
openssl x509 -in leaf.crt -noout -subject -issuer -ext subjectAltName,basicConstraints,extendedKeyUsage
openssl x509 -in leaf.crt -noout -dates
echo "== 1. full chain, correct host"
openssl verify -CAfile root.crt -untrusted int.crt -verify_hostname track.tamarind.example leaf.crt
echo "== 2. missing intermediate"
openssl verify -CAfile root.crt leaf.crt 2>&1 | tail -2 || true
echo "== 3. wrong hostname"
openssl verify -CAfile root.crt -untrusted int.crt -verify_hostname portal.tamarind.example leaf.crt 2>&1 | tail -2 || true
echo "== 4. checked at a date after expiry (attime = now + 120 days)"
AT=$(( $(date +%s) + 120*86400 ))
openssl verify -CAfile root.crt -untrusted int.crt -attime $AT leaf.crt 2>&1 | tail -2 || true
echo "== 5. untrusted root (system store only)"
openssl verify -untrusted int.crt leaf.crt 2>&1 | tail -2 || true
echo "== fingerprints"
openssl x509 -in leaf.crt -noout -fingerprint -sha256
