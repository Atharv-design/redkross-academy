"""Course 15 Module 1 lab: randomness and entropy.
Shows why the random module is unsuitable for secrets (seeded output is
reproducible), uses the secrets module correctly, and estimates entropy of
password schemes. Tested: CPython 3.14.4, 2026-11-07."""
import math
import random
import secrets

print("== random with the same seed is fully predictable")
a = random.Random(20261107); b = random.Random(20261107)
print("  token A:", "".join(a.choice("0123456789abcdef") for _ in range(16)))
print("  token B:", "".join(b.choice("0123456789abcdef") for _ in range(16)))

print("== secrets: OS CSPRNG")
t1, t2 = secrets.token_hex(16), secrets.token_hex(16)
print("  two tokens differ:", t1 != t2, " length (hex chars):", len(t1))
print("  token_urlsafe(32) length:", len(secrets.token_urlsafe(32)))

print("== entropy estimates (bits = length x log2(alphabet)), uniform random choice")
for name, alphabet, length in [("4-digit PIN", 10, 4), ("8 lowercase", 26, 8),
                               ("12 mixed (94 printable)", 94, 12),
                               ("6 words from 7776-word list", 7776, 6),
                               ("token_hex(16)", 16, 32)]:
    print(f"  {name:30} {length * math.log2(alphabet):6.1f} bits")
