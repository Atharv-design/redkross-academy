"""Tests for rkcrypt (Course 15 capstone reference).
Run: python -m unittest test_rkcrypt -v      Tested: CPython 3.14.4, 2026-11-07
Uses log2n=14 in most tests for speed; the default (17) is tested once.
"""
import os
import tempfile
import unittest

import rkcrypt as rk

DATA = b"id,name\n1,FICTIONAL A\n2,FICTIONAL B\n"


class RoundTrip(unittest.TestCase):
    def test_roundtrip_fast_params(self):
        self.assertEqual(rk.decrypt_bytes(rk.encrypt_bytes(DATA, "pw-1", log2n=14), "pw-1"), DATA)

    def test_roundtrip_default_params(self):
        blob = rk.encrypt_bytes(DATA, "pw-1")
        self.assertEqual(blob[5], 17)
        self.assertEqual(rk.decrypt_bytes(blob, "pw-1"), DATA)

    def test_empty_file(self):
        self.assertEqual(rk.decrypt_bytes(rk.encrypt_bytes(b"", "pw", log2n=14), "pw"), b"")

    def test_same_input_different_output(self):
        a = rk.encrypt_bytes(DATA, "pw", log2n=14)
        b = rk.encrypt_bytes(DATA, "pw", log2n=14)
        self.assertNotEqual(a, b)                       # fresh salt and nonce
        self.assertNotEqual(a[8:24], b[8:24])


class Integrity(unittest.TestCase):
    def setUp(self):
        self.blob = rk.encrypt_bytes(DATA, "pw", log2n=14)

    def test_wrong_passphrase(self):
        with self.assertRaisesRegex(rk.RkcryptError, "authentication failed"):
            rk.decrypt_bytes(self.blob, "PW")

    def test_flipped_ciphertext_bit(self):
        bad = bytearray(self.blob); bad[-1] ^= 1
        with self.assertRaisesRegex(rk.RkcryptError, "authentication failed"):
            rk.decrypt_bytes(bytes(bad), "pw")

    def test_modified_header_salt_detected(self):
        bad = bytearray(self.blob); bad[10] ^= 1
        with self.assertRaisesRegex(rk.RkcryptError, "authentication failed"):
            rk.decrypt_bytes(bytes(bad), "pw")

    def test_truncated(self):
        with self.assertRaises(rk.RkcryptError):
            rk.decrypt_bytes(self.blob[:30], "pw")

    def test_not_rkcrypt(self):
        with self.assertRaisesRegex(rk.RkcryptError, "not an rkcrypt"):
            rk.decrypt_bytes(b"XXXX" + self.blob[4:], "pw")

    def test_kdf_parameters_bounded(self):
        bad = bytearray(self.blob); bad[5] = 30            # N = 2**30 would exhaust memory
        with self.assertRaisesRegex(rk.RkcryptError, "out of accepted range"):
            rk.decrypt_bytes(bytes(bad), "pw")


class Cli(unittest.TestCase):
    def test_cli_encrypt_decrypt_and_exit_codes(self):
        os.environ["RKCRYPT_PASS"] = "cli-pass"
        with tempfile.TemporaryDirectory() as d:
            src, enc, dec = (os.path.join(d, n) for n in ("a.csv", "a.rkc", "b.csv"))
            open(src, "wb").write(DATA)
            self.assertEqual(rk.main(["encrypt", src, enc]), 0)
            self.assertEqual(rk.main(["decrypt", enc, dec]), 0)
            self.assertEqual(open(dec, "rb").read(), DATA)
            os.environ["RKCRYPT_PASS"] = "wrong"
            self.assertEqual(rk.main(["decrypt", enc, dec]), 1)
            self.assertEqual(rk.main(["frobnicate", src]), 2)
            self.assertEqual(rk.sha256_file(src), rk.sha256_file(dec))


if __name__ == "__main__":
    unittest.main()
