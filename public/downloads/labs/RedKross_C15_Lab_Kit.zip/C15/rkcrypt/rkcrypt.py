"""rkcrypt - teaching file encryption and integrity utility (Course 15 capstone).

Format (all integers big-endian):
  magic  b"RKC1"           4 bytes
  kdf    0x01 = scrypt     1 byte
  log2n  scrypt N exponent 1 byte
  r, p                     1 byte each
  salt                     16 bytes
  nonce                    12 bytes
  ciphertext||tag          AES-256-GCM, with the 36-byte header as AAD
The header is authenticated, so changing parameters or salt makes decryption
fail. Files are processed in memory (teaching limit: MAX_SIZE).

Usage:
  python rkcrypt.py encrypt IN OUT      (passphrase from RKCRYPT_PASS or prompt)
  python rkcrypt.py decrypt IN OUT
  python rkcrypt.py hash FILE           (SHA-256, for integrity records)
Exit codes: 0 ok, 1 authentication/integrity failure, 2 usage or input error.
Tested: CPython 3.14.4, cryptography 48.0.0, 2026-11-07.
"""
import getpass
import hashlib
import os
import struct
import sys

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

MAGIC, KDF_SCRYPT = b"RKC1", 1
HEADER = struct.Struct(">4sBBBB16s12s")       # 36 bytes
MAX_SIZE = 64 * 1024 * 1024
DEFAULT_LOG2N, R, P = 17, 8, 1                 # OWASP scrypt minimum N=2**17, r=8, p=1


class RkcryptError(Exception):
    pass


def derive_key(passphrase: str, salt: bytes, log2n: int, r: int, p: int) -> bytes:
    if not passphrase:
        raise RkcryptError("empty passphrase")
    return hashlib.scrypt(passphrase.encode("utf-8"), salt=salt, n=2 ** log2n, r=r, p=p,
                          maxmem=2 ** 30, dklen=32)


def encrypt_bytes(data: bytes, passphrase: str, log2n: int = DEFAULT_LOG2N) -> bytes:
    if len(data) > MAX_SIZE:
        raise RkcryptError("input larger than MAX_SIZE")
    salt, nonce = os.urandom(16), os.urandom(12)
    header = HEADER.pack(MAGIC, KDF_SCRYPT, log2n, R, P, salt, nonce)
    key = derive_key(passphrase, salt, log2n, R, P)
    return header + AESGCM(key).encrypt(nonce, data, header)


def decrypt_bytes(blob: bytes, passphrase: str) -> bytes:
    if len(blob) < HEADER.size + 16:
        raise RkcryptError("file too short")
    magic, kdf, log2n, r, p, salt, nonce = HEADER.unpack(blob[:HEADER.size])
    if magic != MAGIC or kdf != KDF_SCRYPT:
        raise RkcryptError("not an rkcrypt v1 file")
    if not (14 <= log2n <= 20 and 1 <= r <= 16 and 1 <= p <= 4):
        raise RkcryptError("KDF parameters out of accepted range")
    key = derive_key(passphrase, salt, log2n, r, p)
    try:
        return AESGCM(key).decrypt(nonce, blob[HEADER.size:], blob[:HEADER.size])
    except InvalidTag:
        raise RkcryptError("authentication failed: wrong passphrase or modified file") from None


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def main(argv) -> int:
    if len(argv) < 2 or argv[0] not in ("encrypt", "decrypt", "hash"):
        print(__doc__.split("Usage:")[1].split("Exit")[0].strip(), file=sys.stderr)
        return 2
    try:
        if argv[0] == "hash":
            print(sha256_file(argv[1]), argv[1])
            return 0
        if len(argv) != 3:
            raise RkcryptError("need IN and OUT")
        pw = os.environ.get("RKCRYPT_PASS") or getpass.getpass("passphrase: ")
        data = open(argv[1], "rb").read()
        out = encrypt_bytes(data, pw) if argv[0] == "encrypt" else decrypt_bytes(data, pw)
        tmp = argv[2] + ".tmp"
        with open(tmp, "wb") as fh:
            fh.write(out)
        os.replace(tmp, argv[2])
        print(f"{argv[0]}ed {len(data)} -> {len(out)} bytes: {argv[2]}")
        return 0
    except RkcryptError as e:
        print("error:", e, file=sys.stderr)
        return 1 if "authentication" in str(e) else 2
    except OSError as e:
        print("error:", e.strerror, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
