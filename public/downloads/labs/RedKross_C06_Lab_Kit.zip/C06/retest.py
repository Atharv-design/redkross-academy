#!/usr/bin/env python3
"""
retest.py - confirm that the hardening closed every finding.

Runs the same controlled checks (findings.py) against two ports and shows,
per weakness, whether it is still PRESENT. On the vulnerable app (8200) all
ten should be present; on the hardened app (8201) all ten should be absent.
A finding is only "closed" when the retest proves it.

Start both targets first:
  python target/app.py          # 8200 vulnerable
  python target/app_fixed.py    # 8201 hardened
Then: python retest.py
"""
import argparse
from findings import run


def summarise(host, port):
    results = run(host, port)
    present = sum(1 for r in results if r["present"])
    return results, present


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--vuln-port", type=int, default=8200)
    ap.add_argument("--fixed-port", type=int, default=8201)
    args = ap.parse_args()

    vuln, vn = summarise(args.host, args.vuln_port)
    fixed, fn = summarise(args.host, args.fixed_port)
    fixed_by_id = {r["id"]: r for r in fixed}

    print("%-32s %-10s %-10s %s" % ("weakness", "vuln:8200", "fixed:8201", "closed?"))
    print("-" * 66)
    closed = 0
    for r in vuln:
        f = fixed_by_id.get(r["id"], {})
        v = "PRESENT" if r["present"] else "absent"
        x = "PRESENT" if f.get("present") else "absent"
        ok = r["present"] and not f.get("present")
        closed += 1 if ok else 0
        print("%-32s %-10s %-10s %s" % (r["title"][:32], v, x, "yes" if ok else "-"))
    print("-" * 66)
    print("vulnerable: %d/%d present | hardened: %d/%d present | closed: %d/%d"
          % (vn, len(vuln), fn, len(fixed), closed, len(vuln)))


if __name__ == "__main__":
    main()
