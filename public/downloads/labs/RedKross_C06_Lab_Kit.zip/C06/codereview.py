#!/usr/bin/env python3
"""
codereview.py - a small secure-code-review aid for the Course 06 capstone.

Static (no execution) scan of a Python web source file for well-known unsafe
patterns. It does NOT prove a vulnerability - a human confirms each hit in
context - but it points a reviewer at the lines that most often carry web
flaws. Run it on app.py (many hits) and app_fixed.py (few/none) to see how
secure code reads differently.

Usage: python codereview.py target/app.py
"""
import re
import sys

# (label, OWASP/CWE, compiled regex, note)
RULES = [
    ("SQL built by string formatting", "A05/CWE-89",
     re.compile(r"execute\(\s*[\"'].*%s|[\"']\s*%\s*\(.*\).*(SELECT|INSERT|UPDATE)",
                re.I),
     "Use parameterised queries (execute(sql, params))."),
    ("Possible SQL via f-string/concat", "A05/CWE-89",
     re.compile(r"(SELECT|INSERT|UPDATE|DELETE).*(\+|f[\"'])", re.I),
     "Never concatenate input into SQL."),
    ("Unencoded output of input", "A05/CWE-79",
     re.compile(r"%\s*(term|body|email|name|r\[0\])|format\(body=.*%s", re.I),
     "Encode with html.escape() at output; check manually."),
    ("Cookie without HttpOnly/SameSite", "A07/CWE-1004",
     re.compile(r"Set-Cookie.*session", re.I),
     "Session cookies need HttpOnly, Secure, SameSite."),
    ("Open outbound fetch (SSRF)", "A01/CWE-918",
     re.compile(r"urlopen\(\s*url|requests\.get\(\s*url", re.I),
     "Allowlist destinations; block internal ranges."),
    ("Path join of user input", "A01/CWE-22",
     re.compile(r"os\.path\.join\([^)]*name", re.I),
     "Canonicalise and confine to a base directory."),
    ("Verbose error to client", "A10/CWE-209",
     re.compile(r"repr\(exc\)|str\(exc\)", re.I),
     "Return a generic error; log details server-side."),
    ("Missing CSRF token check", "A01/CWE-352",
     re.compile(r"do_POST", re.I),
     "Confirm state-changing POSTs verify a per-session CSRF token."),
]


def main():
    if len(sys.argv) < 2:
        print("usage: python codereview.py <source.py>")
        sys.exit(1)
    src = open(sys.argv[1], encoding="utf-8").read().splitlines()
    print("Secure code review of %s" % sys.argv[1])
    print("-" * 68)
    hits = 0
    for n, line in enumerate(src, 1):
        for label, ref, rx, note in RULES:
            if rx.search(line):
                hits += 1
                print("L%-4d %-30s %s" % (n, label[:30], ref))
                print("       %s" % line.strip()[:60])
                print("       -> %s" % note)
    print("-" * 68)
    print("%d pattern hit(s). Each requires human confirmation in context."
          % hits)


if __name__ == "__main__":
    main()
