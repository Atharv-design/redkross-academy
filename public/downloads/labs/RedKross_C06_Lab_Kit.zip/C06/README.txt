RedKross Academy - Course 06: Web Application Security
AUTHORISED LAB (loopback only). Read scope.md before anything else.
================================================================================

WHAT THIS IS
A complete, self-contained web application security lab built around one
deliberately vulnerable web app that you build and own, "Sahyadri Reads".
Everything runs against 127.0.0.1 (loopback). The tools refuse, in code, any
host other than 127.0.0.1/localhost. Never point these tools at a system you
do not own and are not authorised in writing to test.

SAFETY AND LAW
Authorisation within a defined scope is what makes security testing lawful.
In India, unauthorised access to a computer resource is an offence under the
Information Technology Act, 2000 (e.g. sections 43 and 66). This lab keeps you
lawful by keeping you on your own machine. See scope.md.

FILES
  scope.md             Filled-in Rules of Engagement / authorisation example
  target/app.py        Vulnerable "Sahyadri Reads" app on 127.0.0.1:8200
  target/app_fixed.py  Hardened version (all findings fixed) on 127.0.0.1:8201
  labutil.py           Shared helpers; enforces the loopback-only rule
  map.py               Application mapping (endpoint discovery)      Module 2
  findings.py          Controlled verification of each weakness       Modules 3-7
  cvss.py              CVSS v3.1 base-score calculator (offline)      Module 4/8
  report.py            Risk-ranked report with remediation            Module 8
  retest.py            Re-runs checks on both apps to prove fixes     Module 8
  codereview.py        Static secure-code-review aid                  Module 8
  data/                Saved tool output and evidence

WEAKNESSES IN THE LAB (OWASP Top 10:2025 / CWE)
  SQL injection (login/search)        A03 / CWE-89
  Reflected and stored XSS            A03 / CWE-79
  IDOR (another user's order)         A01 / CWE-639
  Broken access control (/admin)      A01 / CWE-284
  Weak session cookie                 A07 / CWE-1004 (and CWE-384)
  Cross-site request forgery          A01 / CWE-352
  Path traversal (download)           A05 / CWE-22
  Server-side request forgery         A10 / CWE-918
  Missing security headers            A05 / CWE-693

HOW TO RUN (two terminals)
  Terminal 1:  python target/app.py          # vulnerable, port 8200
  Terminal 2:  python target/app_fixed.py    # hardened,  port 8201
  Then:        python map.py --port 8200
               python findings.py --port 8200 --save
               python report.py
               python retest.py
               python codereview.py target/app.py

TESTED
All tools were execution-tested on 2026-11-08 with CPython 3.14.4 on Windows
11, standard library only. Saved outputs are in data/. On the vulnerable app
all ten weaknesses are PRESENT; on the hardened app all ten are ABSENT; the
retest shows 10/10 closed.
