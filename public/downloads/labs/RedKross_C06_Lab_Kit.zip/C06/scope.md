# Rules of Engagement and Authorisation - Course 06 Web Security Lab

> This is a FILLED-IN EXAMPLE of the written authorisation that must exist
> before any web application security test. In this course the "client" and
> the "tester" are the same person, and the target is a web application you
> build and run on your own machine, on loopback only. Keep a document like
> this for every real engagement - a test without written authorisation is
> not a test, it is an offence.

## 1. Parties
- Authorising owner: the learner (owner of this machine and the lab app).
- Tester: the learner.
- Both roles are the same person for this self-owned lab.

## 2. Authorisation statement
I authorise security testing of the application described below, which I own
and operate, for the purpose of learning and of finding and fixing
weaknesses. This authorisation is limited to the target and scope stated
here.

## 3. Target (in scope)
- Application: "Sahyadri Reads" lab (target/app.py), a deliberately
  vulnerable web app with fictional data.
- Address: http://127.0.0.1:8200 ONLY (loopback interface).
- Hardened comparison build: http://127.0.0.1:8201 (target/app_fixed.py).
- Hosts: 127.0.0.1 / localhost ONLY.

## 4. Explicitly OUT of scope
- Any host, IP, domain or URL other than 127.0.0.1 / localhost.
- Any system you do not own or are not authorised in writing to test.
- Any third-party service, cloud account, or shared network device.
- The lab tools enforce this in code: they refuse non-loopback hosts.

## 5. Permitted activities
- Mapping the application's endpoints (map.py).
- Controlled verification of specific weakness classes (findings.py), using
  the minimum safe proof per finding.
- Severity scoring (cvss.py), reporting (report.py), retesting (retest.py),
  and secure code review (codereview.py).

## 6. Prohibited activities
- Any denial-of-service, destructive, or data-exfiltration action.
- Testing outside the stated loopback scope.
- Using these techniques against any system without written authorisation.

## 7. Data handling
- The lab holds only fictional sample data created at startup. No real
  personal data is involved. In a real test, handling of any personal data
  must follow the Digital Personal Data Protection Act, 2023 and the
  engagement's data-handling terms.

## 8. Timing and stop conditions
- Testing window: any time, on the local machine.
- Stop immediately if the target behaves unexpectedly outside the lab, if any
  non-loopback traffic is observed, or if real data is encountered.

## 9. Legal note (India)
Unauthorised access to a computer resource is an offence under the
Information Technology Act, 2000 (for example sections 43 and 66).
AUTHORISATION within a defined scope is the line between lawful security
testing and a crime. This note is not legal advice; obtain qualified counsel
for a real engagement.

## 10. Sign-off
- Owner: learner        Date: (fill in)
- Tester: learner       Date: (fill in)
