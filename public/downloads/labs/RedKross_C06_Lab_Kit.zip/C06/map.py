#!/usr/bin/env python3
"""
map.py - scoped application mapping for the Course 06 lab (Module 2).

Probes a short list of KNOWN endpoints on the loopback lab target and records
status, content type and whether the response reflects input. This is the
"attack surface map" step of an authorised web test: you enumerate what the
application exposes before testing any single endpoint.

Loopback only: the tool refuses any host other than 127.0.0.1/localhost.

Usage: python map.py [--port 8200]
"""
import argparse
import json
import os
from labutil import get

ENDPOINTS = [
    ("GET", "/"),
    ("GET", "/robots.txt"),
    ("GET", "/login?user=asha&pw=reader123"),
    ("GET", "/search?q=ghats"),
    ("GET", "/account?id=1001"),
    ("GET", "/reviews?book=The%20Western%20Ghats"),
    ("GET", "/admin"),
    ("GET", "/download?file=readme.txt"),
    ("GET", "/fetch?url=http://127.0.0.1:1/"),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8200)
    args = ap.parse_args()

    rows = []
    print("Application map for http://%s:%d (loopback lab)" % (args.host, args.port))
    print("%-6s %-34s %-6s %s" % ("METHOD", "PATH", "STATUS", "CONTENT-TYPE"))
    for method, path in ENDPOINTS:
        try:
            status, hdrs, _ = get(args.host, args.port, path)
            ctype = hdrs.get("content-type", "-")
            server = hdrs.get("server", "-")
        except Exception as exc:
            status, ctype, server = "ERR", repr(exc), "-"
        print("%-6s %-34s %-6s %s" % (method, path[:34], status, ctype))
        rows.append({"method": method, "path": path, "status": status,
                     "content_type": ctype, "server": server})
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "map.json")
    with open(out, "w") as fh:
        json.dump(rows, fh, indent=2)
    print("\nServer banner reported:", rows[0].get("server", "-"))
    print("Saved %s" % out)


if __name__ == "__main__":
    main()
