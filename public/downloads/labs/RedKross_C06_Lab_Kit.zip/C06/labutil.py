"""Shared helpers for the Course 06 web-security lab tools.

Every tool imports require_loopback() and refuses, in code, to talk to any
host other than the loopback interface. This is a hard safety control: these
tools must never be pointed at a system you do not own and are not authorised
to test.
"""
import http.client
import urllib.parse

ALLOWED_HOSTS = {"127.0.0.1", "localhost"}


def require_loopback(host):
    """Exit the program if host is not a loopback name. Returns host if ok."""
    if host not in ALLOWED_HOSTS:
        raise SystemExit(
            "REFUSED: host %r is not loopback. This authorised lab tool only "
            "targets 127.0.0.1/localhost - the system you own." % host)
    return host


def get(host, port, path, headers=None, timeout=4):
    """Minimal GET returning (status, headers_dict, body_text)."""
    require_loopback(host)
    conn = http.client.HTTPConnection(host, port, timeout=timeout)
    conn.request("GET", path, headers=headers or {})
    r = conn.getresponse()
    body = r.read().decode("utf-8", "replace")
    hdrs = {k.lower(): v for k, v in r.getheaders()}
    conn.close()
    return r.status, hdrs, body


def post(host, port, path, data, headers=None, timeout=4):
    require_loopback(host)
    body = urllib.parse.urlencode(data)
    h = {"Content-Type": "application/x-www-form-urlencoded"}
    h.update(headers or {})
    conn = http.client.HTTPConnection(host, port, timeout=timeout)
    conn.request("POST", path, body=body, headers=h)
    r = conn.getresponse()
    text = r.read().decode("utf-8", "replace")
    hdrs = {k.lower(): v for k, v in r.getheaders()}
    conn.close()
    return r.status, hdrs, text
