#!/usr/bin/env python3
"""
report.py - turn confirmed findings into a risk-ranked web-security report.

Reads data/findings.json (produced by findings.py --save), scores each present
finding with the CVSS v3.1 calculator, maps it to its OWASP Top 10:2025
category and CWE, attaches a remediation, and prints the findings in priority
order. This is the deliverable that gives an authorised test its value.

Usage: python report.py
"""
import json
import os
from cvss import base_score, parse, severity

HERE = os.path.dirname(os.path.abspath(__file__))

REMEDIATION = {
    "sqli": "Use parameterised queries / prepared statements; never build SQL "
            "by string concatenation.",
    "xss_refl": "Contextually encode all user-influenced output; set a "
                "Content-Security-Policy.",
    "xss_stored": "Encode stored content at output time; validate on input; "
                  "apply a CSP.",
    "idor": "Enforce per-object ownership/authorisation on every request; do "
            "not trust client-supplied identifiers.",
    "authz_admin": "Enforce function-level access control server-side from the "
                   "authenticated session, not from client cookies.",
    "session": "Set HttpOnly, Secure and SameSite on session cookies; use "
               "random server-side session identifiers.",
    "csrf": "Require a per-session anti-CSRF token on all state-changing "
            "requests; use SameSite cookies.",
    "traversal": "Canonicalise paths and confirm they stay within an allowed "
                 "base directory; reject '..'.",
    "ssrf": "Default-deny outbound fetches; allowlist destinations; block "
            "internal address ranges.",
    "headers": "Set X-Content-Type-Options, X-Frame-Options, a strong CSP and "
               "Referrer-Policy on all responses.",
}


def main():
    path = os.path.join(HERE, "data", "findings.json")
    findings = json.load(open(path))
    scored = []
    for f in findings:
        if not f.get("present"):
            continue
        score, _, _ = base_score(parse(f["cvss_vector"]))
        scored.append((score, f))
    scored.sort(key=lambda x: x[0], reverse=True)

    print("=" * 70)
    print("SAHYADRI READS - AUTHORISED WEB APPLICATION SECURITY TEST REPORT")
    print("Target: http://127.0.0.1:8200 (owned loopback lab)")
    print("Standard: OWASP Top 10:2025; severity by CVSS v3.1 (FIRST)")
    print("=" * 70)
    print("\nEXECUTIVE SUMMARY")
    crit = sum(1 for s, _ in scored if s >= 9.0)
    high = sum(1 for s, _ in scored if 7.0 <= s < 9.0)
    print("  %d confirmed findings: %d critical, %d high, %d medium/low."
          % (len(scored), crit, high, len(scored) - crit - high))
    print("  Highest risk: %s (%.1f). Fix in the order below."
          % (scored[0][1]["title"], scored[0][0]))

    print("\nFINDINGS (priority order)")
    for i, (score, f) in enumerate(scored, 1):
        print("-" * 70)
        print("%2d. %s" % (i, f["title"]))
        print("    Severity : %.1f (%s)   %s / %s"
              % (score, severity(score), f["owasp"], f["cwe"]))
        print("    Vector   : CVSS:3.1/%s" % f["cvss_vector"])
        print("    Evidence : %s" % f["evidence"])
        print("    Fix      : %s" % REMEDIATION.get(f["id"], "See OWASP guidance."))
    print("-" * 70)
    print("\nRetest: re-run findings.py against the hardened app (port 8201);")
    print("all findings should be absent. See retest.py.")


if __name__ == "__main__":
    main()
