"""Model and data provenance check for BanyanBot (Course 18 Module 6).

Compares what is deployed with what was approved:
  - the local Ollama model's name and digest against approved_models.json
  - the knowledge-base files against kb_manifest.json (SHA-256)
Reports APPROVED / NOT APPROVED / CHANGED. Reads the local Ollama API on
127.0.0.1 only. Run: python supply_check.py
Tested: CPython 3.14.4, Ollama with qwen3:4b, 2026-11-08.
"""
import hashlib
import json
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    approved = json.load(open(os.path.join(HERE, "approved_models.json")))
    tags = json.loads(urllib.request.urlopen("http://127.0.0.1:11434/api/tags", timeout=10).read())
    bad = 0
    print("== models")
    for m in tags["models"]:
        want = approved.get(m["name"])
        d = m["details"]
        status = "APPROVED" if want == m["digest"] else ("CHANGED (digest differs)" if want
                                                          else "NOT APPROVED")
        bad += status != "APPROVED"
        print(f"  {m['name']:12s} {m['digest'][:12]} {d.get('parameter_size')} "
              f"{d.get('quantization_level')} {d.get('format')} -> {status}")
    print("== knowledge base")
    manifest = json.load(open(os.path.join(HERE, "kb_manifest.json")))
    kb = os.path.join(HERE, "kb")
    present = set(os.listdir(kb))
    for fn in sorted(present | set(manifest)):
        if fn not in present:
            print(f"  {fn:20s} MISSING"); bad += 1; continue
        h = hashlib.sha256(open(os.path.join(kb, fn), "rb").read()).hexdigest()
        status = "OK" if manifest.get(fn) == h else ("CHANGED" if fn in manifest else "NEW (unreviewed)")
        bad += status != "OK"
        print(f"  {fn:20s} {h[:12]} {status}")
    print(f"summary: {bad} item(s) need review")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
