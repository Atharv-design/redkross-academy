"""Retrieval and context trace for BanyanBot (Course 18 Module 2).
For each probe question: which documents each configuration retrieves, and
how many tokens the assembled context costs (prompt_eval_count reported by
the local Ollama model with num_predict=1). Local model only.
Run: python retrieval_trace.py   Tested: CPython 3.14.4, qwen3:4b, 2026-11-08."""
import json
import urllib.request

from bot import HARDENED, MODEL, NAIVE, OLLAMA, retrieve, system_prompt
from probes import PROBES


def tokens(system, user):
    req = {"model": MODEL, "stream": False, "think": False, "options": {"num_predict": 1},
           "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]}
    r = urllib.request.urlopen(urllib.request.Request(
        OLLAMA, data=json.dumps(req).encode(), headers={"Content-Type": "application/json"}),
        timeout=300)
    return json.loads(r.read()).get("prompt_eval_count")


for pid, kind, cust, msg, _ in PROBES:
    print(f"{pid} {msg[:58]}")
    for cfg in (NAIVE, HARDENED):
        docs = retrieve(msg, cust, cfg)
        sp = system_prompt(cust, docs, cfg)
        print(f"   {cfg['name']:8s} docs={[d['id'] for d in docs]} chars={len(sp)} "
              f"tokens={tokens(sp, msg)}")
