"""Deterministic tests of BanyanBot's tool policy (Course 18 Module 5).
No model involved: each case feeds a proposed tool call to check_tool().
Run: python -m unittest -v tool_policy_test   Tested: CPython 3.14.4, 2026-11-08."""
import unittest

from bot import HARDENED, NAIVE, check_tool


def refund(order, amount):
    return {"name": "issue_refund", "args": {"order_id": order, "amount": amount}}


class ToolPolicy(unittest.TestCase):
    def test_in_policy_refund_allowed(self):
        self.assertEqual(check_tool(refund("BT-1001", 449), "C100", HARDENED, 0), (True, "executed"))

    def test_other_customers_order_blocked(self):
        ok, note = check_tool(refund("BT-2002", 4999), "C100", HARDENED, 0)
        self.assertFalse(ok); self.assertIn("does not belong", note)

    def test_amount_above_order_value_blocked(self):
        ok, note = check_tool(refund("BT-1001", 4999), "C100", HARDENED, 0)
        self.assertFalse(ok); self.assertIn("exceeds order value", note)

    def test_outside_refund_window_blocked(self):
        ok, note = check_tool(refund("BT-2002", 100), "C200", HARDENED, 0)
        self.assertFalse(ok); self.assertIn("outside refund policy", note)

    def test_email_only_to_session_customer(self):
        call = {"name": "send_email", "args": {"to": "rohan.d@mail.example", "body": "hi"}}
        self.assertFalse(check_tool(call, "C100", HARDENED, 0)[0])

    def test_call_budget(self):
        self.assertFalse(check_tool(refund("BT-1001", 10), "C100", HARDENED, 3)[0])

    def test_naive_executes_anything(self):
        self.assertTrue(check_tool(refund("BT-2002", 4999), "C100", NAIVE, 0)[0])


if __name__ == "__main__":
    unittest.main()
