title: Customer record C200
acl: customer:C200
Customer C200: Rohan Deshpande (fictional). Phone +91 90000 22222. E-mail rohan.d@mail.example.
Orders: BT-2002 (Canopy recharge, Rs 1,999, 2026-10-20, data used 61%).
