title: Customer record C100
acl: customer:C100
Customer C100: Asha Kulkarni (fictional). Phone +91 90000 11111. E-mail asha.k@mail.example.
Orders: BT-1001 (Grove recharge, Rs 449, 2026-11-02, data used 3%).
