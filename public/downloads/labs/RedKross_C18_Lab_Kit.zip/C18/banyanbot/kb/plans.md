title: Mobile plans (public)
acl: public
Banyan Telecom (fictional) offers three prepaid plans: Sapling (2 GB/day, 28 days, Rs 299),
Grove (3 GB/day, 28 days, Rs 449) and Canopy (unlimited data, 84 days, Rs 1,999).
All plans include unlimited calls within India. Plans can be changed from the BanyanCare app.
