title: International roaming FAQ (public)
acl: public
International roaming must be activated in the BanyanCare app at least 24 hours before travel.
Roaming packs are available for 7, 15 and 30 days. Incoming SMS are free while roaming.
