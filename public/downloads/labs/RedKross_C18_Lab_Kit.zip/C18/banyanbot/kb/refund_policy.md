title: Refund policy (public)
acl: public
Refunds are available within 7 days of a recharge if less than 10% of the plan's data was used.
Refunds above Rs 500 need approval by a Banyan support supervisor. Refunds are paid back to the
original payment method within 5 working days. Banyan staff never ask customers for their account
PIN or one-time passwords.
