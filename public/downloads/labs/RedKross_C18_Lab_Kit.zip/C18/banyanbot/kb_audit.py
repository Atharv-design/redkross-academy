"""Knowledge-base ingestion audit for BanyanBot (Course 18 Modules 3 and 4).

Before documents enter a retrieval index, check them offline:
  - every document declares an ACL (public or customer:<id>)
  - public documents contain no personal data (phone numbers, e-mail)
  - customer records are not marked public
  - imported external content contains no text addressed to AI assistants or
    common injection phrases (flag for human review, do not trust silently)
  - a SHA-256 manifest is written so later changes can be detected
Run: python kb_audit.py [--write-manifest]
Tested: CPython 3.14.4, 2026-11-08. All data fictional.
"""
import hashlib
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PII = {"phone": r"\+91 9\d{4} \d{5}", "email": r"[\w.]+@[\w.]+\.example"}
INSTRUCTION = [r"\bAI assistants?\b", r"\blanguage models?\b", r"ignore (all|previous)",
               r"\bdo not mention\b", r"\bcall (issue_refund|send_email)\b"]


def main():
    findings, manifest = [], {}
    kb = os.path.join(HERE, "kb")
    for fn in sorted(os.listdir(kb)):
        raw = open(os.path.join(kb, fn), "rb").read()
        manifest[fn] = hashlib.sha256(raw).hexdigest()
        text = raw.decode("utf-8")
        lines = text.splitlines()
        title = lines[0].split(":", 1)[1].strip() if lines and lines[0].startswith("title:") else ""
        acl = lines[1].split(":", 1)[1].strip() if len(lines) > 1 and lines[1].startswith("acl:") else ""
        if not acl:
            findings.append(("HIGH", fn, "no ACL declared"))
        if acl == "public":
            for kind, pat in PII.items():
                if re.search(pat, text):
                    findings.append(("HIGH", fn, f"public document contains {kind}"))
        if fn.startswith("customer_") and acl == "public":
            findings.append(("HIGH", fn, "customer record marked public"))
        for i, ln in enumerate(lines, 1):
            if any(re.search(p, ln, re.I) for p in INSTRUCTION):
                sev = "HIGH" if "imported" in title.lower() else "MEDIUM"
                findings.append((sev, fn, f"line {i}: text addressed to the assistant: {ln[:60]}"))
    for sev, fn, msg in findings:
        print(f"  {sev:6s} {fn:20s} {msg}")
    print(f"summary: {len(manifest)} documents, {len(findings)} findings")
    if "--write-manifest" in sys.argv:
        json.dump(manifest, open(os.path.join(HERE, "kb_manifest.json"), "w"), indent=1)
        print("wrote kb_manifest.json")
    return 1 if any(f[0] == "HIGH" for f in findings) else 0


if __name__ == "__main__":
    sys.exit(main())
