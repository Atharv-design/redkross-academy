RedKross Academy - Course 18 lab assets (BanyanBot)
====================================================
Purpose: a defender's test bench for an LLM application. Everything runs on
your own computer: a local model served by Ollama on 127.0.0.1, a small
fictional knowledge base, and simulated tools that only append to an
in-memory ledger. Nothing contacts external services or real systems.

Contents (banyanbot/)
  bot.py            the assistant: retrieval, system prompt, two simulated
                    tools and switchable defences (delimit, acl, in_filter,
                    out_filter, tool_policy, sanitise); configs NAIVE,
                    PROMPT_ONLY, HARDENED
  kb/               seven fictional documents; partner_offer.md is a planted
                    test document whose embedded instructions are harmless
                    (a canary word and an out-of-policy refund request to the
                    SIMULATED tool)
  probes.py         six benign evaluation probes P1-P6 x 3 configs x seeds
  summarise.py      results table + canary leakage count
  kb_audit.py       ingestion audit (ACL, PII in public docs, text addressed
                    to assistants) + SHA-256 manifest
  supply_check.py   approved model digest and KB manifest check
  approved_models.json, kb_manifest.json   reference approvals
  partner_offer_comment_variant.md.txt     the same planted text inside an
                    HTML comment, for Module 3 practical comparison
  *_output.txt, probe_results.json         saved results (2026-11-08)

Requirements: Python 3.10+ (standard library only); Ollama with a local
model (tested: qwen3:4b Q4_K_M, digest 359d7dd4bcda...). Other models give
different numbers - that is part of the lesson.
Run: cd banyanbot; python probes.py 5; python summarise.py;
     python kb_audit.py; python supply_check.py
Safety rules: use only this bench or AI systems you own or are explicitly
authorised in writing to test; keep probes benign (canaries and simulated
tools); never test third-party AI services without permission.
