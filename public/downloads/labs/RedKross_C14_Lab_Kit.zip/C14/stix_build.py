"""C14 Module 6: build and validate a STIX 2.1 bundle for MONSOON LANTERN.

Usage: python stix_build.py     (needs the stix2 package; see README)
Uses the managed, active IOCs from ioc_pipeline.py. The campaign is a
Campaign object, NOT an Intrusion Set or Threat Actor: we have not
attributed it (Module 4). Indicators carry STIX patterns, validity
windows and the confidence produced by the pipeline; a Sighting records
Nilgiri's own observation. Writes stix/monsoon_lantern_bundle.json.
"""
import json
import os
import sys
from datetime import date, datetime, timedelta, timezone

import stix2
from stix2patterns.validator import run_validator

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import ioc_pipeline  # noqa: E402

NOW = datetime(2026, 10, 28, 18, 0, tzinfo=timezone.utc)
PATTERN = {"ipv4": "[ipv4-addr:value = '{v}']", "domain": "[domain-name:value = '{v}']",
           "url": "[url:value = '{v}']", "sha256": "[file:hashes.'SHA-256' = '{v}']"}
ATTACK = {"T1566.001": "Spearphishing Attachment", "T1566.002": "Spearphishing Link",
          "T1204.002": "Malicious File", "T1059.001": "PowerShell", "T1053.005": "Scheduled Task",
          "T1560.001": "Archive via Utility", "T1041": "Exfiltration Over C2 Channel"}


def main():
    marking = stix2.TLP_AMBER
    me = stix2.Identity(name="Nilgiri Mutual CTI (fictional)", identity_class="organization",
                        sectors=["financial-services"], created=NOW, modified=NOW)
    camp = stix2.Campaign(name="MONSOON LANTERN", created_by_ref=me, created=NOW, modified=NOW,
                          description="Brand-impersonation phishing and intrusion activity against "
                                      "Nilgiri Mutual (fictional). Not attributed to any actor.",
                          first_seen="2026-10-02T00:00:00Z", confidence=70, object_marking_refs=[marking])
    objs = [me, camp]
    _, active, _ = ioc_pipeline.managed(ioc_pipeline.load_feeds(), date(2026, 10, 28))
    inds = {}
    for m in active:
        pat = PATTERN[m["type"]].format(v=m["value"])
        errs = run_validator(pat)
        assert not errs, (pat, errs)
        valid_until = NOW + timedelta(days=ioc_pipeline.HALF_LIFE[m["type"]])
        ind = stix2.Indicator(name=f"MONSOON LANTERN {m['type']} {m['value'][:40]}", pattern=pat,
                              pattern_type="stix", valid_from=NOW, valid_until=valid_until,
                              indicator_types=["malicious-activity"], confidence=int(min(m["score"], 100)),
                              created_by_ref=me, created=NOW, modified=NOW,
                              labels=sorted("feed:" + f for f in m["feeds"]), object_marking_refs=[marking])
        inds[m["value"]] = ind
        objs += [ind, stix2.Relationship(ind, "indicates", camp, created_by_ref=me, created=NOW, modified=NOW)]
    for tid, name in ATTACK.items():
        ap = stix2.AttackPattern(name=name, created=NOW, modified=NOW, created_by_ref=me,
                                 external_references=[{"source_name": "mitre-attack", "external_id": tid,
                                                       "url": "https://attack.mitre.org/techniques/"
                                                              + tid.replace(".", "/")}])
        objs += [ap, stix2.Relationship(camp, "uses", ap, created_by_ref=me, created=NOW, modified=NOW)]
    sight = stix2.Sighting(sighting_of_ref=inds["198.51.100.77"], count=6,
                           first_seen="2026-10-28T10:30:00Z", last_seen="2026-10-28T10:55:20Z",
                           where_sighted_refs=[me], created_by_ref=me, created=NOW, modified=NOW,
                           description="Six HTTPS POSTs from one finance workstation (proxy log).",
                           object_marking_refs=[stix2.TLP_RED])
    objs.append(sight)
    rep = stix2.Report(name="MONSOON LANTERN flash report 2026-10-28", published=NOW, created=NOW, modified=NOW,
                       report_types=["campaign"], object_refs=[o.id for o in objs if o.type != "identity"],
                       created_by_ref=me, object_marking_refs=[marking])
    bundle = stix2.Bundle(objects=objs + [rep])
    os.makedirs(os.path.join(HERE, "stix"), exist_ok=True)
    out = os.path.join(HERE, "stix", "monsoon_lantern_bundle.json")
    open(out, "w", encoding="utf-8").write(bundle.serialize(pretty=True))
    # round-trip: parse strictly (no custom properties allowed)
    parsed = stix2.parse(open(out, encoding="utf-8").read(), allow_custom=False)
    from collections import Counter
    print(f"bundle {parsed.id}: {len(parsed.objects)} objects")
    for t, n in sorted(Counter(o.type for o in parsed.objects).items()):
        print(f"   {t:16s} {n}")
    print("markings:", sorted({m for o in parsed.objects for m in getattr(o, 'object_marking_refs', [])}))
    print("all patterns valid; strict parse OK ->", os.path.relpath(out, HERE))


if __name__ == "__main__":
    main()
