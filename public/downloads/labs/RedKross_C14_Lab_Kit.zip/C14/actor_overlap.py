"""C14 Module 4: technique overlap between an observed campaign and ATT&CK
groups - and why overlap is not attribution.

Usage: python actor_overlap.py [TECHNIQUE_ID ...]
Default observed set: the techniques in data/reports.json (MONSOON
LANTERN). Reads data/enterprise-attack.json (MITRE ATT&CK STIX). Revoked
techniques are followed to their replacements; sub-techniques are also
compared at parent level.
"""
import json
import os
import sys
from collections import defaultdict

D = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")


def load():
    b = json.load(open(os.path.join(D, "enterprise-attack.json"), encoding="utf-8"))
    objs = {o["id"]: o for o in b["objects"]}
    ext = {}
    for o in b["objects"]:
        if o["type"] == "attack-pattern":
            for r in o.get("external_references", []):
                if r.get("source_name") == "mitre-attack":
                    ext[o["id"]] = r["external_id"]
    revoked_by = {}
    uses = defaultdict(set)
    for o in b["objects"]:
        if o["type"] != "relationship" or o.get("revoked") or o.get("x_mitre_deprecated"):
            continue
        if o["relationship_type"] == "revoked-by":
            revoked_by[o["source_ref"]] = o["target_ref"]
        elif o["relationship_type"] == "uses" and o["source_ref"].startswith("intrusion-set") \
                and o["target_ref"].startswith("attack-pattern"):
            t = objs.get(o["target_ref"])
            if t and not t.get("revoked") and not t.get("x_mitre_deprecated"):
                uses[o["source_ref"]].add(ext[o["target_ref"]])
    by_ext = {v: k for k, v in ext.items()}
    groups = {k: o["name"] for k, o in objs.items() if o["type"] == "intrusion-set" and not o.get("revoked")
              and not o.get("x_mitre_deprecated")}
    collection = next(o for o in b["objects"] if o["type"] == "x-mitre-collection")
    return objs, ext, by_ext, revoked_by, uses, groups, collection.get("x_mitre_version")


def main(argv):
    objs, ext, by_ext, revoked_by, uses, groups, version = load()
    if argv:
        observed = set(argv)
    else:
        observed = {t for r in json.load(open(os.path.join(D, "reports.json"))) for t in r["techniques"]}
    resolved = set()
    for t in sorted(observed):
        sid = by_ext.get(t)
        if sid and objs[sid].get("revoked") and sid in revoked_by:
            new = ext[revoked_by[sid]]
            print(f"note: {t} is revoked in ATT&CK {version}; using {new}")
            resolved.add(new)
        elif sid:
            resolved.add(t)
        else:
            print(f"note: {t} not found in ATT&CK {version}")
    parent = lambda s: {x.split(".")[0] for x in s}
    print(f"Observed techniques ({len(resolved)}): {', '.join(sorted(resolved))}")
    rows = []
    for gid, name in groups.items():
        g = uses.get(gid, set())
        if not g:
            continue
        inter = resolved & g
        jac = len(inter) / len(resolved | g)
        pint = parent(resolved) & parent(g)
        rows.append((len(pint), len(inter), jac, name, len(g)))
    rows.sort(key=lambda r: (-r[0], -r[1], -r[2]))
    print(f"\nATT&CK {version}: {len(groups)} groups, {len(rows)} with technique mappings")
    print(f"{'group':32s} {'shared(parent)':>14s} {'shared(exact)':>13s} {'Jaccard':>8s} {'group techs':>11s}")
    for p, i, j, n, size in rows[:10]:
        print(f"{n[:32]:32s} {p:14d} {i:13d} {j:8.3f} {size:11d}")
    for k in (len(parent(resolved)), len(parent(resolved)) - 1):
        cnt = sum(1 for r in rows if r[0] >= k)
        print(f"groups sharing >= {k} of {len(parent(resolved))} parent techniques: {cnt}")


if __name__ == "__main__":
    main(sys.argv[1:])
