"""C14 Module 7: map campaign techniques to ATT&CK 20.1, find analytic gaps
against our log inventory, and write an ATT&CK Navigator layer.

Usage: python attack_map.py
Reads data/enterprise-attack.json, data/reports.json and
data/log_inventory.json (the data components Nilgiri actually collects).
For each technique: tactics, the detection strategies that "detect" it,
the data components their analytics reference, and coverage:
  COVERED  at least one detection strategy whose analytics use only
           components we collect
  PARTIAL  some referenced components are collected, none fully
  BLIND    none of the referenced components are collected
Writes navigator/monsoon_lantern_layer.json (Navigator layer format 4.5).
"""
import json
import os
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data")


def ext_id(o):
    return next((r["external_id"] for r in o.get("external_references", [])
                 if r.get("source_name") == "mitre-attack"), None)


def main():
    b = json.load(open(os.path.join(D, "enterprise-attack.json"), encoding="utf-8"))
    O = {o["id"]: o for o in b["objects"]}
    tech = {ext_id(o): o for o in b["objects"] if o["type"] == "attack-pattern"
            and not o.get("revoked") and not o.get("x_mitre_deprecated")}
    detects = defaultdict(list)
    for r in b["objects"]:
        if r["type"] == "relationship" and r["relationship_type"] == "detects" and not r.get("revoked"):
            detects[r["target_ref"]].append(O[r["source_ref"]])
    have = set(json.load(open(os.path.join(D, "log_inventory.json")))["collected_data_components"])
    version = next(o for o in b["objects"] if o["type"] == "x-mitre-collection")["x_mitre_version"]
    reports = json.load(open(os.path.join(D, "reports.json")))
    evidence = defaultdict(list)
    for r in reports:
        for t in r["techniques"]:
            evidence[t].append(r["id"])
    layer_techs, summary = [], defaultdict(int)
    print(f"ATT&CK {version}; collected data components: {len(have)}")
    for t in sorted(evidence):
        o = tech.get(t)
        if not o:
            print(f"{t}: not an active technique in {version}")
            continue
        tactics = [p["phase_name"] for p in o.get("kill_chain_phases", [])]
        best, used = "BLIND", set()
        dets = detects.get(o["id"], [])
        for ds in dets:
            comps = set()
            for aref in ds.get("x_mitre_analytic_refs", []):
                for ls in O[aref].get("x_mitre_log_source_references", []):
                    comps.add(O[ls["x_mitre_data_component_ref"]]["name"])
            used |= comps
            if comps and comps <= have:
                best = "COVERED"
            elif comps & have and best == "BLIND":
                best = "PARTIAL"
        summary[best] += 1
        print(f"\n{t} {o['name']}  [{', '.join(tactics)}]  evidence: {', '.join(evidence[t])}")
        print(f"   detection strategies: {', '.join(ext_id(d) for d in dets) or 'none'}")
        print(f"   data components referenced: {', '.join(sorted(used)) or 'none'}")
        print(f"   missing from our inventory: {', '.join(sorted(used - have)) or '-'}")
        print(f"   coverage: {best}")
        score = {"COVERED": 3, "PARTIAL": 2, "BLIND": 1}[best]
        layer_techs.append({"techniqueID": t, "score": score, "comment": f"{best}; evidence "
                            + ", ".join(evidence[t]), "enabled": True})
    print("\nSummary:", dict(summary))
    layer = {"name": "MONSOON LANTERN - observed techniques and coverage", "versions":
             {"attack": version.split(".")[0], "navigator": "5.1.0", "layer": "4.5"},
             "domain": "enterprise-attack", "description": "Fictional C14 lab layer. Score 3 covered, "
             "2 partial, 1 blind.", "techniques": layer_techs,
             "gradient": {"colors": ["#ff6666", "#ffe766", "#8ec843"], "minValue": 1, "maxValue": 3}}
    os.makedirs(os.path.join(HERE, "navigator"), exist_ok=True)
    json.dump(layer, open(os.path.join(HERE, "navigator", "monsoon_lantern_layer.json"), "w"), indent=2)
    print("wrote navigator/monsoon_lantern_layer.json")


if __name__ == "__main__":
    main()
