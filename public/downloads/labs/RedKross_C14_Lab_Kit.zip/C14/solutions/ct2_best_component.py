"""C14 course task CT2 model solution: which single data component addition
improves the most MONSOON LANTERN techniques (re-using attack_map logic)."""
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INV = os.path.join(HERE, "data", "log_inventory.json")
original = open(INV, encoding="utf-8").read()
cands = ["Module Load", "Network Traffic Content", "Scheduled Job Creation", "File Metadata",
         "Process Metadata", "File Access", "Windows Registry Key Modification", "Passive DNS"]


def summary():
    out = subprocess.run([sys.executable, os.path.join(HERE, "attack_map.py")], capture_output=True,
                         text=True, cwd=HERE).stdout
    return next(l for l in out.splitlines() if l.startswith("Summary"))


try:
    base = json.loads(original)
    print("baseline:", summary())
    for c in cands:
        inv = dict(base, collected_data_components=base["collected_data_components"] + [c])
        open(INV, "w", encoding="utf-8").write(json.dumps(inv, indent=2))
        print(f"+ {c:34s}", summary())
finally:
    open(INV, "w", encoding="utf-8").write(original)
    summary()  # regenerate the layer for the original inventory
