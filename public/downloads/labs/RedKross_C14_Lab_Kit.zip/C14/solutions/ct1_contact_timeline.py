"""C14 course task CT1 model solution: per-user contact timeline with active IOCs."""
import json
import os
import sys
from collections import defaultdict
from datetime import date

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
import ioc_pipeline  # noqa: E402

_, active, _ = ioc_pipeline.managed(ioc_pipeline.load_feeds(), date(2026, 10, 28))
hits = ioc_pipeline.match(active)
per = defaultdict(list)
for ind, evs in hits.items():
    for e in evs:
        per[(e["user"], e["src"])].append((e["ts"], ind, e["method"], e["bytes"]))
for (user, src), rows in per.items():
    rows.sort()
    print(f"{user} {src}: {len(rows)} events, first {rows[0][0]}, last {rows[-1][0]}, "
          f"bytes out (POST) {sum(b for _, _, m, b in rows if m == 'POST')}, "
          f"bytes in (GET) {sum(b for _, _, m, b in rows if m == 'GET')}")
    for ts, ind, m, b in rows:
        print(f"   {ts} {m:4s} {b:8d}  {ind}")
