"""C14 Module 3: passive context for ONE domain - DNS, TLS certificate, RDAP.

Usage: python live_context.py example.com
The lab runs it only against example.com, a domain IANA reserves for
documentation. Each step is a normal client request (a DNS lookup, one TLS
handshake, one RDAP query); nothing is scanned. Use it on other domains
only when a documented requirement and your organisation's OSINT policy
allow it.
"""
import json
import socket
import ssl
import sys
import urllib.request

domain = sys.argv[1]
print(f"Domain: {domain}")
addrs = sorted({ai[4][0] for ai in socket.getaddrinfo(domain, 443, proto=socket.IPPROTO_TCP)})
print("DNS A/AAAA:", ", ".join(addrs))

ctx = ssl.create_default_context()
with socket.create_connection((domain, 443), timeout=10) as s:
    with ctx.wrap_socket(s, server_hostname=domain) as t:
        cert = t.getpeercert()
        print("TLS version:", t.version())
subject = dict(x[0] for x in cert["subject"])
issuer = dict(x[0] for x in cert["issuer"])
sans = [v for k, v in cert.get("subjectAltName", []) if k == "DNS"]
print("Certificate subject CN:", subject.get("commonName"))
print("Certificate issuer:", issuer.get("organizationName"), "/", issuer.get("commonName"))
print("Valid:", cert["notBefore"], "->", cert["notAfter"])
print(f"Subject alternative names ({len(sans)}):", ", ".join(sans[:8]) + (" ..." if len(sans) > 8 else ""))

req = urllib.request.Request(f"https://rdap.org/domain/{domain}", headers={"User-Agent": "rk-c14-lab"})
with urllib.request.urlopen(req, timeout=20) as r:
    rd = json.load(r)
events = {e["eventAction"]: e["eventDate"] for e in rd.get("events", [])}
print("RDAP handle:", rd.get("handle"), "| status:", ", ".join(rd.get("status", [])))
for k in ("registration", "expiration", "last changed"):
    if k in events:
        print(f"RDAP {k}: {events[k]}")
print("RDAP name servers:", ", ".join(n["ldhName"] for n in rd.get("nameservers", [])))
