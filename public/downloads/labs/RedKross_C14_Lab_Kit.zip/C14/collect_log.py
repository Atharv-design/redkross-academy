"""C14 Module 2: append-only collection log for OSINT artefacts.

Usage: python collect_log.py LOG.jsonl FILE SOURCE_URL REQUIREMENT_ID PURPOSE...
       python collect_log.py --verify LOG.jsonl
Records for each saved artefact: UTC time, collector, the URL it came from,
the requirement it serves, the purpose, the file's SHA-256 and size, and a
hash chain (each entry includes the previous entry's hash) so that later
edits to the log are detectable.
"""
import datetime
import getpass
import hashlib
import json
import os
import sys


def entry_hash(e):
    return hashlib.sha256(json.dumps(e, sort_keys=True).encode()).hexdigest()


def append(log, path, url, req, purpose):
    prev = "0" * 64
    if os.path.exists(log):
        lines = open(log, encoding="utf-8").read().splitlines()
        if lines:
            prev = json.loads(lines[-1])["entry_sha256"]
    data = open(path, "rb").read()
    e = {"time_utc": datetime.datetime.now(datetime.UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
         "collector": getpass.getuser(), "file": os.path.basename(path), "source_url": url,
         "requirement": req, "purpose": purpose, "sha256": hashlib.sha256(data).hexdigest(),
         "bytes": len(data), "prev_entry_sha256": prev}
    e["entry_sha256"] = entry_hash(e)
    with open(log, "a", encoding="utf-8") as f:
        f.write(json.dumps(e) + "\n")
    print(f"logged {e['file']} sha256={e['sha256'][:16]}... for {req}")


def verify(log):
    prev, ok = "0" * 64, True
    for n, line in enumerate(open(log, encoding="utf-8"), 1):
        e = json.loads(line)
        claimed = e.pop("entry_sha256")
        good = e["prev_entry_sha256"] == prev and entry_hash(e) == claimed
        print(f"entry {n}: {'ok' if good else 'TAMPERED OR OUT OF ORDER'}  {e['file']}")
        ok &= good
        prev = claimed
    return 0 if ok else 1


if __name__ == "__main__":
    if sys.argv[1] == "--verify":
        sys.exit(verify(sys.argv[2]))
    append(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], " ".join(sys.argv[5:]))
