"""Check analytic judgments in a brief for estimative language (C14 M01/M08).

Usage: python estimative_lint.py BRIEF.txt
Each line starting with "Judgment:" must
  - contain one likelihood term from the ICD 203 scale (row 1), e.g. "likely";
  - state confidence as a SEPARATE sentence, "Confidence: low|moderate|high.",
    because ICD 203 says a product must not combine a confidence level and a
    degree of likelihood in the same sentence;
  - cite at least one source in square brackets, e.g. [RPT-002].
Vague words ("could", "may", "possibly") without a scale term are flagged.
Limitation: matching is exact, so "almost certainly" is not recognised as
"almost certain"; reword or extend SCALE.
"""
import re
import sys

SCALE = ["almost no chance", "very unlikely", "unlikely", "roughly even chance", "likely",
         "very likely", "almost certain"]
VAGUE = ["could", "may", "might", "possibly", "perhaps", "potentially"]
CONF = re.compile(r"\b(low|moderate|high) confidence\b|\bconfidence:\s*(low|moderate|high)\b", re.I)


def sentences(text):
    return [s for s in re.split(r"(?<=[.;])\s+", text) if s]


def check(line):
    text = line[len("Judgment:"):].strip()
    issues = []
    sents = sentences(text)
    scale_sents = [s for s in sents if any(re.search(rf"\b{re.escape(t)}\b", s.lower()) for t in SCALE)]
    conf_sents = [s for s in sents if CONF.search(s)]
    if not scale_sents:
        issues.append("no likelihood term from the scale")
    if not conf_sents:
        issues.append("no confidence statement")
    if set(scale_sents) & set(conf_sents):
        issues.append("likelihood and confidence combined in one sentence (ICD 203)")
    if not re.search(r"\[[A-Z]+-\d+\]", text):
        issues.append("no source citation")
    vague = [v for v in VAGUE if re.search(rf"\b{v}\b", text.lower())]
    if vague and not scale_sents:
        issues.append(f"vague wording: {', '.join(vague)}")
    return issues


if __name__ == "__main__":
    problems = 0
    for n, line in enumerate(open(sys.argv[1], encoding="utf-8"), 1):
        if not line.startswith("Judgment:"):
            continue
        issues = check(line)
        problems += bool(issues)
        print(f"{'OK  ' if not issues else 'FIX '} line {n}: {line.strip()[:90]}")
        for i in issues:
            print(f"       - {i}")
    print(f"{problems} judgment(s) need revision")
    sys.exit(1 if problems else 0)
