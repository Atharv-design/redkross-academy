"""Generate the C14 synthetic threat-intelligence dataset (deterministic).

Scenario: "Nilgiri Mutual" (a fictional insurer) tracks "MONSOON LANTERN",
a fictional phishing-and-intrusion campaign. Every domain uses the reserved
.example TLD and every address comes from the RFC 5737 documentation
ranges, so nothing here identifies a real system, organisation or person.

Writes into data/:
  requirements.yaml   intelligence requirements (PIRs, SIRs, EEIs)
  sources.json        source register with Admiralty ratings
  reports.json        incoming reports (claims with source and date)
  pdns.jsonl          passive DNS observations
  certs.json          TLS certificate observations
  whois.json          registration records (registrant e-mails hashed)
  feed_*.csv          three IOC feeds of different quality
  proxy_log.jsonl     one day of Nilgiri web-proxy logs
"""
import csv
import hashlib
import json
import os
import random
from datetime import datetime, timedelta, timezone

SEED = 1414
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
T0 = datetime(2026, 10, 1, tzinfo=timezone.utc)


def iso(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def sha(s):
    return hashlib.sha256(s.encode()).hexdigest()


def main():
    rnd = random.Random(SEED)
    os.makedirs(OUT, exist_ok=True)

    requirements = """\
# Nilgiri Mutual intelligence requirements, Q4 2026 (fictional)
pirs:
  - id: PIR-1
    question: Which threat actors are likely to target Indian insurers' policyholder data in the next 6 months?
    consumer: CISO, Board risk committee
    priority: 1
    sirs:
      - id: SIR-1.1
        question: Which phishing infrastructure is being prepared against Nilgiri brands?
        eeis: [lure domains resembling nilgiri brands, hosting addresses, certificate reuse]
      - id: SIR-1.2
        question: Which techniques do campaigns against our sector use after initial access?
        eeis: [ATT&CK techniques with evidence, tools named in reports]
  - id: PIR-2
    question: Is MONSOON LANTERN infrastructure active against Nilgiri networks now?
    consumer: SOC lead
    priority: 1
    sirs:
      - id: SIR-2.1
        question: Do proxy or DNS logs show contact with campaign infrastructure?
        eeis: [matches of current IOCs in proxy_log, first and last contact times]
  - id: PIR-3
    question: Which regulatory reporting duties apply if policyholder data is exposed?
    consumer: Legal, DPO
    priority: 2
    sirs: []
"""
    open(os.path.join(OUT, "requirements.yaml"), "w", encoding="utf-8").write(requirements)

    sources = [
        {"id": "SRC-01", "name": "Sector ISAC bulletin", "type": "sharing community", "reliability": "B",
         "notes": "usually reliable; occasional duplication of vendor reports"},
        {"id": "SRC-02", "name": "Vendor blog (fictional 'Kaveri Labs')", "type": "commercial report",
         "reliability": "B", "notes": "detailed technical analysis; marketing bias possible"},
        {"id": "SRC-03", "name": "Anonymous paste site post", "type": "open web", "reliability": "E",
         "notes": "no track record; possibly planted"},
        {"id": "SRC-04", "name": "Nilgiri SOC telemetry", "type": "internal", "reliability": "A",
         "notes": "first-hand observation of our own systems"},
        {"id": "SRC-05", "name": "National CERT advisory (fictional)", "type": "government", "reliability": "A",
         "notes": "authoritative; often delayed"},
        {"id": "SRC-06", "name": "Social media researcher thread", "type": "open web", "reliability": "C",
         "notes": "fairly reliable individual; claims rarely sourced"},
    ]
    json.dump(sources, open(os.path.join(OUT, "sources.json"), "w"), indent=2)

    reports = [
        {"id": "RPT-001", "source": "SRC-02", "date": "2026-10-03", "credibility": 2,
         "claim": "MONSOON LANTERN sends invoice-themed lures from domains resembling insurer brands; "
                  "payloads are ISO archives containing a shortcut file that starts PowerShell.",
         "techniques": ["T1566.001", "T1204.002", "T1059.001"]},
        {"id": "RPT-002", "source": "SRC-01", "date": "2026-10-06", "credibility": 3,
         "claim": "Members report MONSOON LANTERN using scheduled tasks for persistence and exfiltrating "
                  "archives over HTTPS to the same servers used for command and control.",
         "techniques": ["T1053.005", "T1560.001", "T1041"]},
        {"id": "RPT-003", "source": "SRC-03", "date": "2026-10-07", "credibility": 5,
         "claim": "MONSOON LANTERN is run by a named state agency and has already stolen all policy data "
                  "from three Indian insurers.",
         "techniques": []},
        {"id": "RPT-004", "source": "SRC-05", "date": "2026-10-12", "credibility": 1,
         "claim": "Advisory lists infrastructure 198.51.100.77 and portal-nilgiri-claims.example as phishing "
                  "hosts observed against financial-sector targets.",
         "techniques": ["T1566.002", "T1583.001"]},
        {"id": "RPT-005", "source": "SRC-06", "date": "2026-10-14", "credibility": 3,
         "claim": "Researcher links MONSOON LANTERN to a certificate reused across eleven lure domains.",
         "techniques": ["T1588.004"]},
        {"id": "RPT-006", "source": "SRC-04", "date": "2026-10-20", "credibility": 1,
         "claim": "SOC blocked one user's visit to nilgiri-policy-renewal.example from the finance VLAN.",
         "techniques": ["T1566.002"]},
    ]
    json.dump(reports, open(os.path.join(OUT, "reports.json"), "w"), indent=2)

    # Infrastructure: cluster A (campaign), cluster B (unrelated shared hosting), noise
    cluster_a_domains = ["portal-nilgiri-claims.example", "nilgiri-policy-renewal.example",
                         "nilgirimutual-docs.example", "claims-nilgiri-help.example",
                         "nm-invoice-share.example", "secure-nilgiri-login.example"]
    cluster_a_ips = ["198.51.100.77", "198.51.100.78", "203.0.113.45"]
    shared_hosting_ip = "192.0.2.10"
    benign_on_shared = ["bakery-kolhapur.example", "yoga-classes-pune.example", "tiffin-service.example",
                        "school-alumni.example", "portal-nilgiri-claims.example"]
    pdns = []
    for i, d in enumerate(cluster_a_domains):
        ip = cluster_a_ips[i % 3]
        first = T0 + timedelta(days=rnd.randint(0, 10))
        pdns.append({"rrname": d, "rrtype": "A", "rdata": ip, "first_seen": iso(first),
                     "last_seen": iso(first + timedelta(days=rnd.randint(5, 25))), "count": rnd.randint(20, 400)})
        pdns.append({"rrname": d, "rrtype": "NS", "rdata": "ns1.cheap-dns-host.example",
                     "first_seen": iso(first), "last_seen": iso(first + timedelta(days=30)), "count": 5})
    for d in benign_on_shared:
        first = T0 - timedelta(days=rnd.randint(100, 900))
        pdns.append({"rrname": d, "rrtype": "A", "rdata": shared_hosting_ip, "first_seen": iso(first),
                     "last_seen": iso(T0 + timedelta(days=30)), "count": rnd.randint(1000, 90000)})
        pdns.append({"rrname": d, "rrtype": "NS", "rdata": "ns1.cheap-dns-host.example",
                     "first_seen": iso(first), "last_seen": iso(T0 + timedelta(days=30)), "count": 50})
    for n in range(40):
        d = f"site{n:02d}.example"
        pdns.append({"rrname": d, "rrtype": "A", "rdata": f"203.0.113.{100 + n}",
                     "first_seen": iso(T0 - timedelta(days=rnd.randint(30, 2000))),
                     "last_seen": iso(T0 + timedelta(days=30)), "count": rnd.randint(50, 5000)})
    with open(os.path.join(OUT, "pdns.jsonl"), "w") as f:
        for r in pdns:
            f.write(json.dumps(r) + "\n")

    lantern_cert = sha("lantern-cert")[:40]
    certs = [{"domain": d, "sha1": lantern_cert, "issuer": "Fictional Free CA R3",
              "not_before": "2026-09-28T00:00:00Z", "subject_cn": d} for d in cluster_a_domains[:5]]
    certs.append({"domain": "secure-nilgiri-login.example", "sha1": sha("other")[:40],
                  "issuer": "Fictional Free CA R3", "not_before": "2026-10-09T00:00:00Z",
                  "subject_cn": "secure-nilgiri-login.example"})
    for d in benign_on_shared[:4]:
        certs.append({"domain": d, "sha1": sha(d)[:40], "issuer": "Fictional Free CA R3",
                      "not_before": "2026-08-01T00:00:00Z", "subject_cn": d})
    json.dump(certs, open(os.path.join(OUT, "certs.json"), "w"), indent=2)

    reg_a = sha("registrant-a@mail.example")[:16]
    whois = [{"domain": d, "created": "2026-09-2%d" % (i % 9), "registrar": "Fictional Registrar Ltd",
              "registrant_email_sha256_16": reg_a if i < 4 else "redacted-for-privacy"}
             for i, d in enumerate(cluster_a_domains)]
    whois += [{"domain": d, "created": "2023-0%d-15" % (i + 1), "registrar": "Other Registrar",
               "registrant_email_sha256_16": "redacted-for-privacy"} for i, d in enumerate(benign_on_shared[:4])]
    json.dump(whois, open(os.path.join(OUT, "whois.json"), "w"), indent=2)

    # IOC feeds
    feed_rows = {
        "feed_isac.csv": [
            ("domain", "portal-nilgiri-claims.example", "2026-10-03", "2026-10-25", 80, "MONSOON LANTERN lure"),
            ("domain", "nilgiri-policy-renewal.example", "2026-10-04", "2026-10-24", 80, "MONSOON LANTERN lure"),
            ("ipv4", "198.51.100.77", "2026-10-03", "2026-10-26", 75, "MONSOON LANTERN C2"),
            ("ipv4", "198.51.100.78", "2026-10-05", "2026-10-26", 70, "MONSOON LANTERN C2"),
            ("sha256", sha("lantern-iso-1"), "2026-10-03", "2026-10-03", 90, "ISO lure archive"),
            ("domain", "nilgirimutual-docs.example", "2026-10-06", "2026-10-21", 70, "MONSOON LANTERN lure"),
        ],
        "feed_vendor.csv": [
            ("ipv4", "198.51.100.77", "2026-10-02", "2026-10-27", 85, "C2"),
            ("ipv4", "203.0.113.45", "2026-10-07", "2026-10-27", 60, "C2 (suspected)"),
            ("domain", "claims-nilgiri-help.example", "2026-10-08", "2026-10-20", 65, "lure"),
            ("url", "https://nm-invoice-share.example/inv/2026-10.iso", "2026-10-09", "2026-10-09", 70, "payload"),
            ("sha256", sha("lantern-lnk-1"), "2026-10-03", "2026-10-03", 90, "LNK loader"),
            ("ipv4", "192.0.2.10", "2026-10-03", "2026-10-03", 40, "hosted lure briefly"),
        ],
        "feed_free.csv": [
            ("ipv4", "8.8.8.8", "2026-06-01", "2026-10-30", 50, "seen in malware sandbox"),
            ("domain", "update.microsoft.com", "2026-05-01", "2026-10-30", 30, "contacted by sample"),
            ("ipv4", "198.51.100.77", "2026-03-01", "2026-03-15", 50, "old scanner"),
            ("domain", "portal-nilgiri-claims.example", "2026-10-03", "2026-10-29", 60, "phishing"),
            ("md5", "d41d8cd98f00b204e9800998ecf8427e", "2026-01-01", "2026-10-30", 50, "malware"),
            ("ipv4", "203.0.113.200", "2025-11-01", "2025-11-02", 40, "botnet"),
        ],
    }
    for name, rows in feed_rows.items():
        with open(os.path.join(OUT, name), "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["type", "value", "first_seen", "last_seen", "confidence", "description"])
            w.writerows(rows)

    # Proxy log, 2026-10-28 (UTC)
    day = datetime(2026, 10, 28, tzinfo=timezone.utc)
    users = [f"u{n:03d}" for n in range(1, 61)]
    normal = ["intranet.nilgiri.example", "mail.nilgiri.example", "update.microsoft.com", "www.gov.example",
              "news.example", "cdn.example", "bakery-kolhapur.example"] + [f"site{n:02d}.example" for n in range(40)]
    log = []
    for _ in range(1800):
        t = day + timedelta(seconds=rnd.randint(8 * 3600, 19 * 3600))
        host = rnd.choice(normal)
        ip = "192.0.2.10" if host == "bakery-kolhapur.example" else (
            f"203.0.113.{100 + int(host[4:6])}" if host.startswith("site") else "192.0.2.200")
        log.append({"ts": iso(t), "user": rnd.choice(users), "src": f"10.40.{rnd.randint(1, 9)}.{rnd.randint(2, 250)}",
                    "host": host, "dst_ip": ip, "method": "GET", "status": 200, "bytes": rnd.randint(300, 90000)})
    # the true positives
    for k, (h, ip, b) in enumerate([("nilgiri-policy-renewal.example", "198.51.100.78", 5300),
                                    ("nm-invoice-share.example", "203.0.113.45", 1830000)]):
        t = day + timedelta(hours=10, minutes=12 + 3 * k)
        log.append({"ts": iso(t), "user": "u017", "src": "10.40.3.57", "host": h, "dst_ip": ip,
                    "method": "GET", "status": 200, "bytes": b})
    for m in range(6):
        t = day + timedelta(hours=10, minutes=30 + 5 * m, seconds=rnd.randint(0, 20))
        log.append({"ts": iso(t), "user": "u017", "src": "10.40.3.57", "host": "198.51.100.77",
                    "dst_ip": "198.51.100.77", "method": "POST", "status": 200, "bytes": rnd.randint(900, 1400)})
    log.sort(key=lambda r: r["ts"])
    with open(os.path.join(OUT, "proxy_log.jsonl"), "w") as f:
        for r in log:
            f.write(json.dumps(r) + "\n")
    print(f"wrote requirements, {len(sources)} sources, {len(reports)} reports, {len(pdns)} pdns, "
          f"{len(certs)} certs, {len(whois)} whois, 3 feeds, {len(log)} proxy events -> {OUT}")


if __name__ == "__main__":
    main()
