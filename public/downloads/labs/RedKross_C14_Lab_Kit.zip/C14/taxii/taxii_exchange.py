"""C14 Module 6: publish and consume STIX over TAXII 2.1 (local lab server).

Usage: python taxii_exchange.py   (server from run_taxii.sh must be running)
Steps: discovery -> API root -> collections -> add the bundle to the
writable collection -> poll with filters (type, added_after) -> try to
write to the read-only collection -> try a wrong password.
"""
import json
import os
import time

from taxii2client.exceptions import TAXIIServiceException
from taxii2client.v21 import ApiRoot, Server, as_pages

HERE = os.path.dirname(os.path.abspath(__file__))
URL = "http://127.0.0.1:5005/taxii2/"
USER, PW = "nilgiri-cti", "lab-only-password-1"


def main():
    srv = Server(URL, user=USER, password=PW)
    print("Discovery:", srv.title, "| api roots:", [a.url for a in srv.api_roots])
    root = srv.api_roots[0]
    print("API root:", root.title, "| versions:", root.versions)
    cols = {c.title: c for c in root.collections}
    for c in root.collections:
        print(f"  collection {c.id}  read={c.can_read} write={c.can_write}  {c.title}")
    camp = next(c for t, c in cols.items() if t.startswith("MONSOON"))
    ro = next(c for t, c in cols.items() if t.startswith("Read-only"))

    bundle = open(os.path.join(HERE, "..", "stix", "monsoon_lantern_bundle.json"), encoding="utf-8").read()
    before = time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime(time.time() - 1))
    st = camp.add_objects(bundle)
    print(f"add_objects: status={st.status} total={st.total_count} success={st.success_count} "
          f"failure={st.failure_count} pending={st.pending_count}")

    inds = camp.get_objects(type="indicator")
    print("poll type=indicator:", len(inds.get("objects", [])), "objects")
    new = camp.get_objects(added_after=before)
    print(f"poll added_after={before}:", len(new.get("objects", [])), "objects")
    pages = list(as_pages(camp.get_objects, per_request=10))
    print("paged fetch, 10 per request:", len(pages), "pages,",
          sum(len(p.get("objects", [])) for p in pages), "objects")
    man = camp.get_manifest()
    print("manifest entries:", len(man.get("objects", [])))

    try:
        ro.add_objects(bundle)
        print("write to read-only collection: UNEXPECTEDLY ACCEPTED")
    except (TAXIIServiceException, Exception) as e:  # client refuses before sending when can_write is false
        print("write to read-only collection refused:", type(e).__name__, str(e)[:90])

    try:
        ApiRoot(root.url, user=USER, password="wrong").refresh()
        print("wrong password: UNEXPECTEDLY ACCEPTED")
    except Exception as e:
        print("wrong password refused:", type(e).__name__, str(e)[:80])


if __name__ == "__main__":
    main()
