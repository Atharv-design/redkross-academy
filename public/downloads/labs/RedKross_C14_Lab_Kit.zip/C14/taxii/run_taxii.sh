#!/bin/sh
# Start the lab TAXII 2.1 server on 127.0.0.1:5005 (medallion, memory backend).
cd "$(dirname "$0")"
exec medallion --host 127.0.0.1 --port 5005 medallion_config.json
