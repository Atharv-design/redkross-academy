"""C14 Module 5: IOC normalisation, de-duplication, ageing, allowlisting and
matching against proxy logs.

Usage: python ioc_pipeline.py [--naive] [--asof YYYY-MM-DD]
Naive mode loads every feed value and matches it - the common mistake.
Managed mode:
  1. normalise (lower-case, strip, refang "[.]" and "hxxp");
  2. reject known-bad data (the MD5 of an empty file, invalid values);
  3. drop allowlisted values (shared public services) and record why;
  4. merge duplicates across feeds, keeping every source;
  5. age each IOC: score = confidence x 0.5 ** (days since last_seen /
     half-life), half-lives by type; corroboration by a second feed adds 10;
  6. keep IOCs scoring >= THRESHOLD as "active";
  7. match active IOCs against data/proxy_log.jsonl (host and dst_ip).
"""
import csv
import glob
import ipaddress
import json
import os
import sys
from collections import defaultdict
from datetime import date

D = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
HALF_LIFE = {"ipv4": 14, "domain": 30, "url": 30, "sha256": 365, "md5": 365}
THRESHOLD = 40
ALLOW = {"8.8.8.8": "public DNS resolver", "update.microsoft.com": "vendor update service",
         "192.0.2.10": "shared hosting for many unrelated sites (see M03 pivot)"}
KNOWN_BAD_DATA = {"d41d8cd98f00b204e9800998ecf8427e": "MD5 of an empty file"}


def norm(t, v):
    v = v.strip().replace("[.]", ".").replace("hxxp", "http")
    return v.lower() if t in ("domain", "url", "md5", "sha256") else v


def load_feeds():
    rows = []
    for path in sorted(glob.glob(os.path.join(D, "feed_*.csv"))):
        feed = os.path.basename(path)[5:-4]
        for r in csv.DictReader(open(path)):
            r["feed"] = feed
            rows.append(r)
    return rows


def valid(t, v):
    if t == "ipv4":
        try:
            ipaddress.IPv4Address(v)
            return True
        except ValueError:
            return False
    return bool(v)


def managed(rows, asof):
    merged, dropped = {}, []
    for r in rows:
        t, v = r["type"], norm(r["type"], r["value"])
        if v in KNOWN_BAD_DATA or not valid(t, v):
            dropped.append((v, r["feed"], KNOWN_BAD_DATA.get(v, "invalid")))
            continue
        if v in ALLOW:
            dropped.append((v, r["feed"], "allowlist: " + ALLOW[v]))
            continue
        m = merged.setdefault((t, v), {"type": t, "value": v, "feeds": set(), "confidence": 0,
                                       "last_seen": "0000", "desc": set()})
        m["feeds"].add(r["feed"])
        m["confidence"] = max(m["confidence"], int(r["confidence"]))
        m["last_seen"] = max(m["last_seen"], r["last_seen"])
        m["desc"].add(r["description"])
    active = []
    for m in merged.values():
        age = (asof - date.fromisoformat(m["last_seen"])).days
        score = m["confidence"] * 0.5 ** (max(age, 0) / HALF_LIFE[m["type"]]) + (10 if len(m["feeds"]) > 1 else 0)
        m["age"], m["score"] = age, round(score, 1)
        if score >= THRESHOLD:
            active.append(m)
    return merged, active, dropped


def match(iocs):
    """Count each log event once, under the first indicator it matches.

    URL indicators are matched on their host, because the proxy log records
    hosts, not full URLs (the first version silently never matched them).
    """
    vals = {}
    for i in iocs:
        v = i["value"]
        vals.setdefault(v, v)
        if v.startswith("http"):
            vals.setdefault(v.split("/")[2], v + " (host)")
    hits = defaultdict(list)
    for line in open(os.path.join(D, "proxy_log.jsonl")):
        e = json.loads(line)
        for field in ("host", "dst_ip"):
            if e[field] in vals:
                hits[vals[e[field]]].append(e)
                break
    return hits


def main(argv):
    asof = date.fromisoformat(argv[argv.index("--asof") + 1]) if "--asof" in argv else date(2026, 10, 28)
    rows = load_feeds()
    print(f"{len(rows)} feed rows from {len({r['feed'] for r in rows})} feeds; as of {asof}")
    if "--naive" in argv:
        iocs = [{"value": r["value"].strip().lower() if r["type"] != "ipv4" else r["value"]} for r in rows]
        print(f"naive: {len({i['value'] for i in iocs})} unique values, no ageing, no allowlist")
    else:
        merged, iocs, dropped = managed(rows, asof)
        print(f"managed: {len(merged)} unique IOCs after merge; {len(dropped)} rows dropped:")
        for v, feed, why in dropped:
            print(f"   drop {v[:40]:40s} ({feed}): {why}")
        print(f"active (score >= {THRESHOLD}): {len(iocs)}")
        for m in sorted(merged.values(), key=lambda m: -m["score"]):
            flag = "ACTIVE " if m in iocs else "expired"
            print(f"   {flag} {m['type']:6s} {m['value'][:44]:44s} score {m['score']:5.1f} "
                  f"age {m['age']:3d}d feeds {','.join(sorted(m['feeds']))}")
    hits = match(iocs)
    total = sum(len(v) for v in hits.values())
    print(f"\nProxy-log matches: {total} events on {len(hits)} indicators")
    for v, evs in sorted(hits.items(), key=lambda kv: -len(kv[1])):
        users = sorted({e["user"] for e in evs})
        print(f"   {v:34s} {len(evs):4d} events, {len(users):2d} users "
              f"({', '.join(users[:3])}{'...' if len(users) > 3 else ''}) first {evs[0]['ts'][11:19]}")


if __name__ == "__main__":
    main(sys.argv[1:])
