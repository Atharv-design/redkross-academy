"""C14 Module 1: requirements tree, collection coverage and gaps.

Usage: python requirements_view.py
Reads data/requirements.yaml, data/reports.json and data/sources.json and
shows, for each PIR/SIR, which reports address it (by EEI keyword match)
and which requirements have no collection yet.
"""
import json
import os

import yaml

D = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
KEYWORDS = {  # EEI -> words that indicate a report addresses it
    "lure domains resembling nilgiri brands": ["domain", "lure"],
    "hosting addresses": ["198.51.100", "203.0.113", "infrastructure", "servers"],
    "certificate reuse": ["certificate"],
    "ATT&CK techniques with evidence": ["persistence", "powershell", "exfiltrat", "scheduled"],
    "tools named in reports": ["tool", "loader"],
    "matches of current IOCs in proxy_log": ["blocked", "visit"],
    "first and last contact times": ["blocked", "visit"],
}


def main():
    req = yaml.safe_load(open(os.path.join(D, "requirements.yaml"), encoding="utf-8"))
    reports = json.load(open(os.path.join(D, "reports.json")))
    sources = {s["id"]: s for s in json.load(open(os.path.join(D, "sources.json")))}
    gaps = []
    for pir in req["pirs"]:
        print(f"{pir['id']} (priority {pir['priority']}, for {pir['consumer']})")
        print(f"  {pir['question']}")
        if not pir["sirs"]:
            print("  !! no SIRs or EEIs defined - this requirement cannot be collected against")
            gaps.append(pir["id"])
        for sir in pir["sirs"]:
            print(f"  {sir['id']} {sir['question']}")
            for eei in sir["eeis"]:
                hits = [r for r in reports if any(k.lower() in r["claim"].lower() for k in KEYWORDS.get(eei, []))]
                tag = ", ".join(f"{r['id']}({sources[r['source']]['reliability']}{r['credibility']})"
                                for r in hits) or "NONE"
                print(f"     EEI {eei:40s} <- {tag}")
                if not hits:
                    gaps.append(f"{sir['id']}: {eei}")
    print("\nCollection gaps:")
    for g in gaps:
        print("  -", g)


if __name__ == "__main__":
    main()
