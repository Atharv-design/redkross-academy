"""C14 Module 3: pivot from a seed indicator across passive DNS, certificates
and registration data, with and without pivot discipline.

Usage: python infra_pivot.py SEED [--naive]
Edges: domain-IP (passive DNS A records), domain-NS, domain-certificate
(SHA-1 fingerprint) and domain-registrant (hashed e-mail). Disciplined mode
skips "noisy" pivots: an IP or name server that serves more than MAX_FANOUT
domains, or records whose first_seen predates the campaign window; and it
never pivots on "redacted-for-privacy".
"""
import json
import os
import sys
from collections import defaultdict

D = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
MAX_FANOUT = 6
WINDOW_START = "2026-09-01"


def load():
    edges = defaultdict(set)   # node -> set of (other, label, evidence)
    meta = {}
    for line in open(os.path.join(D, "pdns.jsonl")):
        r = json.loads(line)
        kind = "ip" if r["rrtype"] == "A" else "ns"
        a, b = ("dom:" + r["rrname"]), (f"{kind}:" + r["rdata"])
        ev = f"pDNS {r['rrtype']} {r['first_seen'][:10]}..{r['last_seen'][:10]}"
        edges[a].add((b, ev, r["first_seen"]))
        edges[b].add((a, ev, r["first_seen"]))
    for c in json.load(open(os.path.join(D, "certs.json"))):
        a, b = "dom:" + c["domain"], "cert:" + c["sha1"][:12]
        edges[a].add((b, f"cert {c['issuer']} {c['not_before'][:10]}", c["not_before"]))
        edges[b].add((a, f"cert {c['issuer']} {c['not_before'][:10]}", c["not_before"]))
    for w in json.load(open(os.path.join(D, "whois.json"))):
        if w["registrant_email_sha256_16"] == "redacted-for-privacy":
            meta["dom:" + w["domain"]] = "redacted"
            continue
        a, b = "dom:" + w["domain"], "reg:" + w["registrant_email_sha256_16"]
        edges[a].add((b, f"whois created {w['created']}", w["created"]))
        edges[b].add((a, f"whois created {w['created']}", w["created"]))
    return edges


def pivot(seed, naive):
    edges = load()
    start = ("ip:" if seed[0].isdigit() else "dom:") + seed
    seen, frontier, log = {start}, [start], []
    while frontier:
        node = frontier.pop(0)
        if not naive and not node.startswith("dom:"):
            fan = sum(1 for o, *_ in edges[node] if o.startswith("dom:"))
            if fan > MAX_FANOUT:
                log.append(f"  skip pivot on {node} (serves {fan} domains: shared infrastructure)")
                continue
        for other, ev, first in sorted(edges[node]):
            if other in seen:
                continue
            if not naive and other.startswith("dom:") and first[:10] < WINDOW_START:
                log.append(f"  skip {other} via {node} (record from {first[:10]}, before campaign window)")
                continue
            seen.add(other)
            frontier.append(other)
            log.append(f"  {node} -> {other}   [{ev}]")
    doms = sorted(n[4:] for n in seen if n.startswith("dom:"))
    return doms, sorted(n for n in seen if not n.startswith("dom:")), log


if __name__ == "__main__":
    naive = "--naive" in sys.argv
    doms, infra, log = pivot(sys.argv[1], naive)
    print(f"Seed {sys.argv[1]}  mode={'naive' if naive else 'disciplined'}")
    print("\n".join(log))
    print(f"\nDomains in cluster ({len(doms)}): " + ", ".join(doms))
    print(f"Infrastructure ({len(infra)}): " + ", ".join(infra))
