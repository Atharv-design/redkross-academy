data/enterprise-attack.json (MITRE ATT&CK Enterprise, STIX 2.1, ~53 MB) is not shipped.
Download it from the official MITRE repository and save it as data/enterprise-attack.json:
https://github.com/mitre-attack/attack-stix-data/tree/master/enterprise-attack
