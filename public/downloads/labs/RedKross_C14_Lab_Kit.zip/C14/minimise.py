"""C14 Module 2: data minimisation for collected open-source text.

Usage: python minimise.py INPUT.txt OUTPUT.txt
Replaces personal data that an intelligence product does not need with
typed placeholders and reports counts. Patterns (deliberately simple; tune
and test them for your jurisdiction and data):
  EMAIL   e-mail addresses
  PHONE   Indian mobile numbers (+91 / 0 prefix optional, 10 digits from 6-9,
          optionally written 5+5 with a space or hyphen; v1 missed that form)
  ID12    12-digit numbers in 4-4-4 groups (the shape of an Aadhaar number)
  PAN     the Indian PAN shape: five letters, four digits, one letter
Infrastructure indicators (domains, IPs) are kept: they are the subject of
the analysis. Keep the raw collection under restricted access and record
why it was collected (collect_log.py).
"""
import re
import sys
from collections import Counter

PATTERNS = [
    ("EMAIL", re.compile(r"\b[\w.+-]+@[\w-]+(?:\.[\w-]+)+\b")),
    ("PHONE", re.compile(r"(?<![\d])(?:\+91[\s-]?|0)?[6-9]\d{4}[\s-]?\d{5}(?![\d])")),
    ("ID12", re.compile(r"\b\d{4}\s\d{4}\s\d{4}\b")),
    ("PAN", re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b")),
]


def minimise(text):
    counts = Counter()
    for label, pat in PATTERNS:
        text, n = pat.subn(f"[{label}]", text)
        counts[label] += n
    return text, counts


if __name__ == "__main__":
    src = open(sys.argv[1], encoding="utf-8").read()
    out, counts = minimise(src)
    open(sys.argv[2], "w", encoding="utf-8").write(out)
    print("replaced:", dict(counts) or "nothing")
