"""C14 Module 8: assemble an intelligence brief from YAML and check it.

Usage: python brief_builder.py BRIEF.yaml OUTPUT.txt
Checks (exit 1 if any fails):
  B1  a TLP label (TLP 2.0: CLEAR, GREEN, AMBER, AMBER+STRICT, RED)
  B2  every judgment has a scale term, a confidence level and sources
  B3  every cited source ID exists in data/reports.json
  B4  no judgment rests only on sources graded E/F or credibility >= 5
  B5  every recommendation names the PIR it answers and an owner
  B6  the brief states a review-by date
"""
import json
import os
import re
import sys

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data")
TLP = {"CLEAR", "GREEN", "AMBER", "AMBER+STRICT", "RED"}
SCALE = ["almost no chance", "very unlikely", "unlikely", "roughly even chance", "likely", "very likely",
         "almost certain"]


def main(argv):
    b = yaml.safe_load(open(argv[0], encoding="utf-8"))
    reports = {r["id"]: r for r in json.load(open(os.path.join(D, "reports.json")))}
    rel = {s["id"]: s["reliability"] for s in json.load(open(os.path.join(D, "sources.json")))}
    pirs = {p["id"] for p in yaml.safe_load(open(os.path.join(D, "requirements.yaml")))["pirs"]}
    fails = []
    if b.get("tlp") not in TLP:
        fails.append(f"B1 TLP label missing or invalid: {b.get('tlp')!r}")
    for i, j in enumerate(b.get("judgments", []), 1):
        txt = j["text"].lower()
        if not any(re.search(rf"\b{s}\b", txt) for s in SCALE) or j.get("confidence") not in ("low", "moderate", "high"):
            fails.append(f"B2 judgment {i}: needs a scale term and confidence")
        srcs = j.get("sources", [])
        if not srcs:
            fails.append(f"B2 judgment {i}: no sources")
        unknown = [s for s in srcs if s not in reports]
        if unknown:
            fails.append(f"B3 judgment {i}: unknown source IDs {unknown}")
        known = [reports[s] for s in srcs if s in reports]
        if known and all(rel[r["source"]] in "EF" or r["credibility"] >= 5 for r in known):
            fails.append(f"B4 judgment {i}: rests only on weak sources {srcs}")
    for i, r in enumerate(b.get("recommendations", []), 1):
        if r.get("pir") not in pirs or not r.get("owner"):
            fails.append(f"B5 recommendation {i}: needs a valid PIR and an owner")
    if not b.get("review_by"):
        fails.append("B6 no review-by date")
    lines = [f"TLP:{b.get('tlp')}", b["title"], f"Date: {b['date']}   Review by: {b.get('review_by')}", "",
             "BOTTOM LINE UP FRONT", b["bluf"], "", "KEY JUDGMENTS"]
    for i, j in enumerate(b.get("judgments", []), 1):
        # ICD 203: do not combine likelihood and confidence in one sentence
        lines.append(f"  {i}. {j['text']} Confidence: {j.get('confidence')}. [{', '.join(j.get('sources', []))}]")
    lines += ["", "RECOMMENDED ACTIONS"]
    for i, r in enumerate(b.get("recommendations", []), 1):
        lines.append(f"  {i}. {r['action']} - owner {r.get('owner')}, answers {r.get('pir')}")
    lines += ["", "INTELLIGENCE GAPS"] + [f"  - {g}" for g in b.get("gaps", [])]
    lines += ["", "SOURCES"] + [f"  [{k}] {v['source']} {rel[v['source']]}{v['credibility']} {v['date']}"
                                for k, v in reports.items() if any(k in j.get("sources", [])
                                                                   for j in b.get("judgments", []))]
    open(argv[1], "w", encoding="utf-8").write("\n".join(lines) + "\n")
    print(f"wrote {argv[1]} ({len(lines)} lines)")
    for f in fails:
        print("FAIL", f)
    print("checks:", "PASS" if not fails else f"{len(fails)} failure(s)")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
