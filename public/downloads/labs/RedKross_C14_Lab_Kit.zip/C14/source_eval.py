"""C14 Module 2: grade reports with the Admiralty (NATO) system and check
corroboration.

Usage: python source_eval.py
Reliability of the SOURCE: A completely reliable ... F cannot be judged.
Credibility of the INFORMATION: 1 confirmed by other sources ... 6 cannot
be judged. The two are assessed separately: a reliable source can pass on
an improbable claim, and an unknown source can be right.
A claim counts as corroborated when another report from a DIFFERENT source
shares at least one technique or indicator with it.
"""
import json
import os
import re

D = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
REL = {"A": "completely reliable", "B": "usually reliable", "C": "fairly reliable",
       "D": "not usually reliable", "E": "unreliable", "F": "cannot be judged"}
CRED = {1: "confirmed", 2: "probably true", 3: "possibly true", 4: "doubtful", 5: "improbable",
        6: "cannot be judged"}
IND = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b|\b[a-z0-9-]+\.example\b")


def main():
    sources = {s["id"]: s for s in json.load(open(os.path.join(D, "sources.json")))}
    reports = json.load(open(os.path.join(D, "reports.json")))
    feats = {r["id"]: set(r["techniques"]) | set(IND.findall(r["claim"])) for r in reports}
    print(f"{'report':8s} {'grade':5s} {'source':38s} corroborated by")
    for r in reports:
        s = sources[r["source"]]
        grade = f"{s['reliability']}{r['credibility']}"
        corr = [o["id"] for o in reports if o["source"] != r["source"] and feats[r["id"]] & feats[o["id"]]]
        print(f"{r['id']:8s} {grade:5s} {s['name'][:38]:38s} {', '.join(corr) or '-'}")
        weak = s["reliability"] in "EF" or r["credibility"] >= 5
        if weak and not corr:
            print(f"         !! {REL[s['reliability']]} source, information {CRED[r['credibility']]}, "
                  f"uncorroborated: do not use as the basis of a judgment")


if __name__ == "__main__":
    main()
