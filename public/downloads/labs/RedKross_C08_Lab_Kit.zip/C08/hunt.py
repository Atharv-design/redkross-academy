"""Hypothesis-driven hunts over minisiem (Course 08 Module 8).

H1  Beaconing: any host/URL pair with many requests at near-constant
    intervals (low coefficient of variation) - not just the known IOC.
H2  Rare parent-child process pairs across the estate (stacking).
H3  Hosts other than WS-104 contacting the known-bad domains.
Usage: python minisiem.py load ; python hunt.py
Tested: CPython 3.14.4, 2026-11-07. Data synthetic.
"""
import sqlite3
from collections import defaultdict
from datetime import datetime
from statistics import mean, pstdev

from minisiem import DB

con = sqlite3.connect(DB)


def ts(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


print("H1 beaconing candidates (>= 8 requests, interval CV < 0.2)")
series = defaultdict(list)
for host, url, t in con.execute(
        "SELECT host, url, ts FROM events WHERE source='proxy' ORDER BY ts"):
    series[(host, url)].append(ts(t))
for (host, url), times in sorted(series.items()):
    if len(times) < 8:
        continue
    gaps = [(b - a).total_seconds() for a, b in zip(times, times[1:])]
    cv = pstdev(gaps) / mean(gaps)
    if cv < 0.2:
        print(f"  {host} {url} n={len(times)} mean_gap={mean(gaps):.0f}s cv={cv:.3f}")

print("H2 parent-child pairs seen on only one host")
for parent, child, hosts, n in con.execute("""
        SELECT parent_image, image, COUNT(DISTINCT host), COUNT(*) FROM events
        WHERE source='sysmon' GROUP BY parent_image, image
        HAVING COUNT(DISTINCT host) = 1 ORDER BY 4"""):
    print(f"  {parent.split(chr(92))[-1]} -> {child.split(chr(92))[-1]} hosts={hosts} n={n}")

print("H3 other hosts contacting known-bad domains")
rows = con.execute("""
        SELECT host, COUNT(*) FROM events WHERE host <> 'WS-104' AND
        (url LIKE '%://cdn-telemetry-sync.example/%' OR
         url LIKE '%://banyan-payroll-update.example/%' OR
         url LIKE '%://files-share-drop.example/%') GROUP BY host""").fetchall()
print("  none found" if not rows else "\n".join(f"  {h} {n}" for h, n in rows))
