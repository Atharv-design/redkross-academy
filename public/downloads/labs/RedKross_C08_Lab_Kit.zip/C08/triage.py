"""Alert triage helper (Course 08 Module 4).

Runs the minisiem rules, enriches each hit with asset and identity context,
computes a priority score and applies documented suppressions.
Usage: python minisiem.py load ; python triage.py
Tested: CPython 3.14.4, 2026-11-07. All data synthetic.
"""
import ipaddress
import sqlite3

from minisiem import DB, RULES

# Context a real SOC would pull from a CMDB and the identity provider.
ASSETS = {"WS-104": ("finance workstation", 3), "WS-107": ("sales laptop", 2)}
USERS = {"divya": ("Finance", "payments approver"), "gopal": ("Sales", "standard")}
PRIMARY_HOST = {"divya": "WS-104", "gopal": "WS-107"}  # VPN events carry no host
# Rule base severity 1-4 and confidence 0.0-1.0, reviewed by detection engineering.
RULE_META = {
    "R1": (3, 0.8), "R2": (4, 0.9), "R3": (3, 0.6),
    "R4": (3, 0.5), "R5": (4, 0.9), "R6": (2, 0.6),
}
# Suppressions: (rule, field, value, reason, expiry) - every entry has an owner ticket.
SUPPRESS = [("R3", "user", "itadmin", "approved build account, CHG-1042", "2026-12-31")]


def ip_context(ip):
    if not ip:
        return "n/a"
    a = ipaddress.ip_address(ip)
    if a in ipaddress.ip_network("10.0.0.0/8"):
        return "internal"
    if a in ipaddress.ip_network("203.0.113.0/24"):
        return "external (documentation range in this lab)"
    return "external"


def priority(rule, host):
    sev, conf = RULE_META[rule]
    crit = ASSETS.get(host, ("unknown asset", 2))[1]
    return round(sev * conf * crit, 1)


def main():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    queue = []
    for name, sql in RULES.items():
        rid = name.split()[0]
        for row in con.execute(sql):
            hit = dict(row)
            if any(r == rid and hit.get(f) == v for r, f, v, *_ in SUPPRESS):
                print("suppressed", rid, hit)
                continue
            user = hit.get("user") or hit.get("success_user")
            host = hit.get("host") or PRIMARY_HOST.get(user)
            queue.append((priority(rid, host), name, host, user,
                          ASSETS.get(host, ("unknown asset", 2))[0],
                          USERS.get(user, ("?", "?"))[1], ip_context(hit.get("src_ip"))))
    for p, name, host, user, asset, role, ipc in sorted(queue, reverse=True):
        print(f"{p:4}  {name:26} host={host} ({asset}) user={user} ({role}) ip={ipc}")


if __name__ == "__main__":
    main()
