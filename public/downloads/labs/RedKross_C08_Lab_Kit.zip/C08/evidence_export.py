"""Export case evidence with hashes and a custody record (Course 08 Module 7).

Exports the raw events for one host and time window from minisiem, writes a
SHA-256 manifest and appends a chain-of-custody entry.
Usage: python minisiem.py load ; python evidence_export.py CASE-0001 WS-104
Tested: CPython 3.14.4, 2026-11-07. Data synthetic.
"""
import hashlib
import json
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

from minisiem import DB


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def main(case, host, start="2026-11-03T06:00:00Z", end="2026-11-03T09:00:00Z"):
    out = Path("evidence") / case
    out.mkdir(parents=True, exist_ok=True)
    rows = sqlite3.connect(DB).execute(
        "SELECT raw FROM events WHERE host = ? AND ts >= ? AND ts < ? ORDER BY ts",
        (host, start, end)).fetchall()
    export = out / f"{host}_{start[:10]}_events.jsonl"
    with open(export, "w", encoding="utf-8", newline="\n") as fh:
        for (raw,) in rows:
            fh.write(raw + "\n")
    digest = sha256(export)
    (out / "SHA256SUMS").write_text(f"{digest}  {export.name}\n", encoding="utf-8",
                                       newline="\n")  # sha256sum -c rejects CRLF
    entry = {"case": case, "item": export.name, "sha256": digest, "events": len(rows),
             "query": {"host": host, "start": start, "end": end},
             "action": "exported from minisiem", "by": "analyst.t2",
             "utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
    with open(out / "custody.jsonl", "a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry) + "\n")
    print(f"exported {len(rows)} events -> {export}")
    print(f"sha256 {digest}")


if __name__ == "__main__":
    main(*sys.argv[1:3])
