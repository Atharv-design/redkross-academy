"""Generate the synthetic Banyan Microfinance SOC dataset (Course 08).

Creates banyan_events.jsonl: one normalised JSON event per line from four
sources (windows security, sysmon-style endpoint, proxy, vpn) covering one
fictional day, with a scripted intrusion storyline hidden among routine
activity. Deterministic (fixed seed) so every learner gets identical data.
All names, hosts and addresses are fictional; IPs use RFC 1918 and RFC 5737
documentation ranges; domains use .example.
Tested: CPython 3.14.4, 2026-11-07.
"""
import json
import random
from datetime import datetime, timedelta, timezone

random.seed(20261107)
DAY = datetime(2026, 11, 3, 0, 0, tzinfo=timezone.utc)
USERS = ["asha", "ben", "chen", "divya", "eshan", "farah", "gopal", "hema"]
HOSTS = {u: f"WS-{i:03d}" for i, u in enumerate(USERS, start=101)}
SITES = ["intranet.banyan.example", "mail.banyan.example", "crm.banyan.example",
         "news.example.com", "maps.example.net", "cdn.example.org"]
events = []


def add(ts, **fields):
    events.append({"@timestamp": ts.isoformat().replace("+00:00", "Z"), **fields})


# Routine activity: logons, process starts, web browsing, VPN sessions
for u in USERS:
    start = DAY + timedelta(hours=3, minutes=random.randint(0, 50))   # 08:30 IST approx
    add(start, source="windows", event_id=4624, host=HOSTS[u], user=u, logon_type=2,
        src_ip="-", outcome="success")
    for _ in range(random.randint(25, 40)):
        t = start + timedelta(minutes=random.randint(1, 540))
        add(t, source="proxy", host=HOSTS[u], user=u, src_ip=f"10.40.0.{USERS.index(u)+20}",
            url=f"https://{random.choice(SITES)}/", status=200, bytes_out=random.randint(300, 4000))
    for proc in ["explorer.exe", "outlook.exe", "msedge.exe", "excel.exe"]:
        t = start + timedelta(minutes=random.randint(1, 120))
        add(t, source="sysmon", event_id=1, host=HOSTS[u], user=u,
            image=f"C:\\Program Files\\App\\{proc}", parent_image="C:\\Windows\\explorer.exe",
            command_line=proc)
    if random.random() < 0.4:
        t = start + timedelta(hours=10)
        add(t, source="vpn", user=u, src_ip=f"198.51.100.{random.randint(10, 200)}",
            outcome="success", country="IN")

# Noise: a few genuine typos
for u in ["ben", "hema"]:
    t = DAY + timedelta(hours=4, minutes=5)
    add(t, source="windows", event_id=4625, host=HOSTS[u], user=u, logon_type=2,
        src_ip="-", outcome="failure", status="0xC000006A")

# --- Scripted storyline (the "incident") ---------------------------------------
t0 = DAY + timedelta(hours=6, minutes=12)
# 1. Phishing click: finance user visits look-alike domain, downloads a document
add(t0, source="proxy", host="WS-104", user="divya", src_ip="10.40.0.23",
    url="https://banyan-payroll-update.example/invoice.docm", status=200, bytes_out=812)
# 2. Office spawns a script interpreter (suspicious parent-child)
add(t0 + timedelta(minutes=2), source="sysmon", event_id=1, host="WS-104", user="divya",
    image="C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
    parent_image="C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE",
    command_line="powershell.exe -NoP -W Hidden -EncodedCommand <redacted-for-course>")
# 3. Periodic beacon to a rare domain (every 5 minutes, small, regular)
for i in range(18):
    add(t0 + timedelta(minutes=5 + 5 * i, seconds=random.randint(0, 3)), source="proxy",
        host="WS-104", user="divya", src_ip="10.40.0.23",
        url="https://cdn-telemetry-sync.example/api/v2/ping", status=200, bytes_out=220)
# 4. Password spray against VPN from external address
for i, u in enumerate(USERS):
    add(t0 + timedelta(minutes=30, seconds=7 * i), source="vpn", user=u, src_ip="203.0.113.66",
        outcome="failure", country="??")
# 5. One success from the spraying address
add(t0 + timedelta(minutes=34), source="vpn", user="gopal", src_ip="203.0.113.66",
    outcome="success", country="??")
# 6. New local admin created on the finance workstation
add(t0 + timedelta(minutes=50), source="windows", event_id=4720, host="WS-104", user="divya",
    target_user="svc_update", outcome="success")
add(t0 + timedelta(minutes=51), source="windows", event_id=4732, host="WS-104", user="divya",
    target_user="svc_update", group="Administrators", outcome="success")
# 7. Large upload to a file-sharing look-alike
add(t0 + timedelta(hours=2), source="proxy", host="WS-104", user="divya", src_ip="10.40.0.23",
    url="https://files-share-drop.example/upload", status=200, bytes_out=48_200_000)
# 8. Security log cleared
add(t0 + timedelta(hours=2, minutes=5), source="windows", event_id=1102, host="WS-104",
    user="divya", outcome="success")

events.sort(key=lambda e: e["@timestamp"])
with open("banyan_events.jsonl", "w", encoding="utf-8", newline="\n") as fh:
    for e in events:
        fh.write(json.dumps(e, sort_keys=True) + "\n")
print("events written:", len(events))
print("sources:", sorted({e["source"] for e in events}))
