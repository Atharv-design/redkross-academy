"""SOC metrics demo (Course 08 Module 1). Synthetic cases. CPython 3.14.4."""
from datetime import datetime
from statistics import mean, median

CASES = [  # (created, acknowledged, resolved, disposition) - synthetic
    ("2026-11-03T06:15", "2026-11-03T06:20", "2026-11-03T07:05", "TP"),
    ("2026-11-03T07:00", "2026-11-03T07:02", "2026-11-03T07:10", "FP"),
    ("2026-11-03T08:20", "2026-11-03T08:21", "2026-11-03T08:30", "FP"),
    ("2026-11-03T09:00", "2026-11-03T11:30", "2026-11-03T15:00", "TP"),
    ("2026-11-03T10:00", "2026-11-03T10:04", "2026-11-03T10:20", "BTP"),
]
p = lambda s: datetime.fromisoformat(s)
ack = [(p(a) - p(c)).total_seconds() / 60 for c, a, r, d in CASES]
res = [(p(r) - p(c)).total_seconds() / 60 for c, a, r, d in CASES]
print(f"MTTA mean {mean(ack):.1f} min, median {median(ack):.1f} min")
print(f"MTTR mean {mean(res):.1f} min, median {median(res):.1f} min")
fp = sum(1 for *_, d in CASES if d == "FP") / len(CASES)
print(f"false-positive share {fp:.0%}")
