"""IOC matching with confidence and expiry (Course 08 Module 5).

Matches a small fictional intelligence feed (STIX-inspired fields, not a full
STIX implementation) against minisiem events and reports context.
Usage: python minisiem.py load ; python ioc_match.py
Tested: CPython 3.14.4, 2026-11-07. Feed and events are synthetic.
"""
import sqlite3
from datetime import date

from minisiem import DB

AS_OF = date(2026, 11, 3)
FEED = [  # type, value, confidence 0-100, valid_until, source, context, TLP
    ("domain", "cdn-telemetry-sync.example", 85, "2026-12-31", "ISAC-A",
     "C2 for loader seen in finance-sector phishing", "TLP:AMBER"),
    ("domain", "banyan-payroll-update.example", 70, "2026-11-30", "internal",
     "look-alike registered 2026-10-29", "TLP:GREEN"),
    ("ipv4", "203.0.113.66", 60, "2026-11-10", "ISAC-A",
     "password spraying against VPNs", "TLP:GREEN"),
    ("ipv4", "198.51.100.104", 40, "2026-06-30", "open feed",
     "scanning (old, shared hosting)", "TLP:CLEAR"),
    ("sha256", "9f2c...e1a0", 90, "2027-01-31", "vendor",
     "malicious invoice.docm (hash truncated for course)", "TLP:AMBER"),
]


def main():
    con = sqlite3.connect(DB)
    for ioc_type, value, conf, until, src, ctx, tlp in FEED:
        expired = date.fromisoformat(until) < AS_OF
        if ioc_type == "domain":
            rows = con.execute("SELECT ts, host FROM events WHERE url LIKE ?",
                               (f"%://{value}/%",)).fetchall()
        elif ioc_type == "ipv4":
            rows = con.execute("SELECT ts, source FROM events WHERE src_ip = ?",
                               (value,)).fetchall()
        else:
            rows = []  # dataset has no file hashes
        status = "EXPIRED" if expired else ("MATCH" if rows else "no match")
        first = rows[0][0] if rows else "-"
        print(f"{status:8} {ioc_type:6} {value:32} conf={conf:3} hits={len(rows):3} "
              f"first={first} src={src} {tlp}")
        if expired and rows:
            print("         expired indicator still matches: review before acting")


if __name__ == "__main__":
    main()
