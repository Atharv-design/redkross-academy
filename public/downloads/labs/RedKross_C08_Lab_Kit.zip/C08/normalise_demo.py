"""Parse two raw formats into one normalised schema (Course 08 Module 3)."""
import json
import re
from datetime import datetime, timezone, timedelta

RAW_SYSLOG = "Nov  3 12:16:21 fw01 kernel: DROP IN=eth0 SRC=203.0.113.66 DST=10.40.0.5 PROTO=TCP DPT=3389"
RAW_JSON = '{"time":"2026-11-03T06:46:00Z","service":"vpn","user":"gopal","clientIP":"203.0.113.66","result":"SUCCESS"}'
IST = timezone(timedelta(hours=5, minutes=30))

def from_syslog(line, year=2026, tz=IST):
    m = re.match(r"(\w{3})\s+(\d+) (\d\d:\d\d:\d\d) (\S+) kernel: (\w+) .*SRC=(\S+) DST=(\S+) PROTO=(\w+) DPT=(\d+)", line)
    ts = datetime.strptime(f"{year} {m[1]} {m[2]} {m[3]}", "%Y %b %d %H:%M:%S").replace(tzinfo=tz)
    return {"@timestamp": ts.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
            "event.module": "firewall", "event.action": m[5].lower(), "host.name": m[4],
            "source.ip": m[6], "destination.ip": m[7], "network.transport": m[8].lower(),
            "destination.port": int(m[9])}

def from_vpn_json(text):
    d = json.loads(text)
    return {"@timestamp": d["time"], "event.module": d["service"], "event.action": "login",
            "event.outcome": d["result"].lower(), "user.name": d["user"], "source.ip": d["clientIP"]}

for e in (from_syslog(RAW_SYSLOG), from_vpn_json(RAW_JSON)):
    print(json.dumps(e, sort_keys=True))
