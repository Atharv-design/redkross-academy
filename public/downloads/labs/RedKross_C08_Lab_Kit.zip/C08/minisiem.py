"""minisiem - a teaching SIEM in ~60 lines (Course 08).

Loads banyan_events.jsonl into SQLite (ingestion), keeps common fields as
columns (normalisation) and the raw event as JSON, then runs saved searches
and simple correlation rules. Usage:
    python minisiem.py load
    python minisiem.py search "SELECT ... FROM events ..."
    python minisiem.py rules
Tested: CPython 3.14.4 (sqlite3 standard library), 2026-11-07.
"""
import json
import sqlite3
import sys

DB = "minisiem.db"
FIELDS = ["ts", "source", "event_id", "host", "user", "src_ip", "url", "outcome",
          "image", "parent_image", "bytes_out", "target_user"]

RULES = {
    "R1 office_spawns_script": """
        SELECT ts, host, user, image FROM events
        WHERE source='sysmon' AND event_id=1
          AND lower(parent_image) LIKE '%winword.exe%'
          AND (lower(image) LIKE '%powershell.exe%' OR lower(image) LIKE '%cmd.exe%')""",
    "R2 vpn_spray_then_success": """
        SELECT s.src_ip, COUNT(DISTINCT f.user) AS users_failed, s.user AS success_user, s.ts
        FROM events s JOIN events f ON f.src_ip = s.src_ip
        WHERE s.source='vpn' AND s.outcome='success' AND f.source='vpn'
          AND f.outcome='failure' AND f.ts <= s.ts
        GROUP BY s.src_ip, s.user, s.ts HAVING users_failed >= 5""",
    "R3 new_local_admin": """
        SELECT ts, host, user, target_user FROM events
        WHERE source='windows' AND event_id IN (4720, 4732)""",
    "R4 large_upload": """
        SELECT ts, host, user, url, bytes_out FROM events
        WHERE source='proxy' AND bytes_out > 10000000""",
    "R5 log_cleared": "SELECT ts, host, user FROM events WHERE event_id=1102",
    "R6 beacon_regular_small": """
        SELECT host, url, COUNT(*) AS hits, MIN(bytes_out) AS min_b, MAX(bytes_out) AS max_b
        FROM events WHERE source='proxy'
        GROUP BY host, url HAVING hits >= 10 AND max_b - min_b < 50""",
}


def load():
    con = sqlite3.connect(DB)
    con.execute("DROP TABLE IF EXISTS events")
    con.execute(f"CREATE TABLE events ({', '.join(FIELDS)}, raw TEXT)")
    with open("banyan_events.jsonl", encoding="utf-8") as fh:
        rows = []
        for line in fh:
            e = json.loads(line)
            e["ts"] = e.get("@timestamp")
            rows.append([e.get(f) for f in FIELDS] + [line.strip()])
    con.executemany(f"INSERT INTO events VALUES ({', '.join('?' * (len(FIELDS) + 1))})", rows)
    con.execute("CREATE INDEX idx_ts ON events(ts)")
    con.commit()
    print("loaded", len(rows), "events")


def search(sql):
    con = sqlite3.connect(DB)
    cur = con.execute(sql)
    cols = [d[0] for d in cur.description]
    print(" | ".join(cols))
    for row in cur.fetchall():
        print(" | ".join(str(v) for v in row))


def rules():
    con = sqlite3.connect(DB)
    for name, sql in RULES.items():
        hits = con.execute(sql).fetchall()
        print(f"{name}: {len(hits)} hit(s)")
        for h in hits[:3]:
            print("   ", h)


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "rules"
    {"load": load, "rules": rules}.get(cmd, lambda: search(sys.argv[2]))()
