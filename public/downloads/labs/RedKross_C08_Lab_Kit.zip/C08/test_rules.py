"""Detection unit tests for minisiem rules (Course 08 Module 6).

Each rule gets a known-bad event that must match and a near-miss benign event
that must not. Run: python -m unittest test_rules -v
Tested: CPython 3.14.4, 2026-11-07. Events are synthetic.
"""
import sqlite3
import unittest

from minisiem import FIELDS, RULES


def run(rule, events):
    con = sqlite3.connect(":memory:")
    con.execute(f"CREATE TABLE events ({', '.join(FIELDS)}, raw TEXT)")
    for e in events:
        con.execute(f"INSERT INTO events VALUES ({', '.join('?' * (len(FIELDS) + 1))})",
                    [e.get(f) for f in FIELDS] + [""])
    return con.execute(RULES[rule]).fetchall()


WORD = r"C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE"
PS = r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"


class R1(unittest.TestCase):
    rule = "R1 office_spawns_script"

    def test_word_spawns_powershell(self):
        e = dict(source="sysmon", event_id=1, parent_image=WORD, image=PS)
        self.assertEqual(len(run(self.rule, [e])), 1)

    def test_explorer_spawns_powershell_is_not_matched(self):
        e = dict(source="sysmon", event_id=1, parent_image=r"C:\Windows\explorer.exe", image=PS)
        self.assertEqual(run(self.rule, [e]), [])


class R2(unittest.TestCase):
    rule = "R2 vpn_spray_then_success"

    def spray(self, n, success=True):
        ev = [dict(source="vpn", outcome="failure", user=f"u{i}", src_ip="203.0.113.9",
                   ts=f"2026-11-03T06:00:{i:02d}Z") for i in range(n)]
        if success:
            ev.append(dict(source="vpn", outcome="success", user="u0", src_ip="203.0.113.9",
                           ts="2026-11-03T06:05:00Z"))
        return ev

    def test_five_users_then_success(self):
        self.assertEqual(len(run(self.rule, self.spray(5))), 1)

    def test_four_users_is_below_threshold(self):
        self.assertEqual(run(self.rule, self.spray(4)), [])

    def test_spray_without_success(self):
        self.assertEqual(run(self.rule, self.spray(8, success=False)), [])


class R6(unittest.TestCase):
    rule = "R6 beacon_regular_small"

    def test_regular_small_requests(self):
        ev = [dict(source="proxy", host="WS-1", url="https://c2.example/p", bytes_out=220)
              for _ in range(10)]
        self.assertEqual(len(run(self.rule, ev)), 1)

    def test_variable_sizes_not_matched(self):
        ev = [dict(source="proxy", host="WS-1", url="https://news.example/", bytes_out=200 + 40 * i)
              for i in range(10)]
        self.assertEqual(run(self.rule, ev), [])


if __name__ == "__main__":
    unittest.main()
