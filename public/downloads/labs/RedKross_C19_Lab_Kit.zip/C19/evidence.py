#!/usr/bin/env python3
"""evidence.py - offline evidence log with integrity chain (RedKross C19).

Manages an append-only evidence log for an engagement: each entry records the
step, a description, the operator tag, a timestamp and a sha256 that chains to
the previous entry (tamper-evident). 'verify' recomputes the chain to confirm no
entry was altered or removed. This supports evidence management and chain of
custody. It reads/writes only the local log file.

Usage:
  python3 evidence.py add  data/evidence_log.jsonl 2 "enumerated range DC (lab)" analyst1
  python3 evidence.py list data/evidence_log.jsonl
  python3 evidence.py verify data/evidence_log.jsonl
"""
import hashlib
import json
import os
import sys
from datetime import datetime, timezone


def _hash(prev, rec):
    h = hashlib.sha256()
    h.update(prev.encode("utf-8"))
    h.update(json.dumps(rec, sort_keys=True).encode("utf-8"))
    return h.hexdigest()


def add(path, step, desc, operator):
    prev = "GENESIS"
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as fh:
            lines = [ln for ln in fh if ln.strip()]
        if lines:
            prev = json.loads(lines[-1])["entry_hash"]
    rec = {
        "step": step,
        "description": desc,
        "operator": operator,
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "prev_hash": prev,
    }
    rec["entry_hash"] = _hash(prev, {k: rec[k] for k in
                                     ("step", "description", "operator", "timestamp", "prev_hash")})
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(rec) + "\n")
    print("added entry step=%s hash=%s" % (step, rec["entry_hash"][:16]))
    return 0


def _load(path):
    with open(path, "r", encoding="utf-8") as fh:
        return [json.loads(ln) for ln in fh if ln.strip()]


def list_log(path):
    for r in _load(path):
        print("  step %-3s %-40s op=%-10s %s" % (
            r["step"], r["description"][:40], r["operator"], r["timestamp"]))
    return 0


def verify(path):
    prev = "GENESIS"
    ok = True
    for i, r in enumerate(_load(path), 1):
        core = {k: r[k] for k in ("step", "description", "operator", "timestamp", "prev_hash")}
        expect = _hash(prev, core)
        if r.get("prev_hash") != prev or r.get("entry_hash") != expect:
            print("  [BROKEN] entry %d (step %s) fails integrity check" % (i, r.get("step")))
            ok = False
        prev = r.get("entry_hash", "")
    if ok:
        print("integrity OK: evidence chain intact")
        return 0
    print("integrity FAILED: evidence chain broken")
    return 1


def main(argv):
    if len(argv) < 3:
        print("usage: python3 evidence.py <add|list|verify> <log.jsonl> [args]")
        return 2
    cmd, path = argv[1], argv[2]
    if cmd == "add":
        if len(argv) != 6:
            print("usage: python3 evidence.py add <log.jsonl> <step> <desc> <operator>")
            return 2
        return add(path, argv[3], argv[4], argv[5])
    if cmd == "list":
        return list_log(path)
    if cmd == "verify":
        return verify(path)
    print("unknown command: %s" % cmd)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
