RedKross Academy - Course 19 lab (Advanced Penetration Testing and Red Team
Operations). DEFENDER / ENGAGEMENT-GOVERNANCE lab. ENTIRELY OFFLINE.

READ scope.md FIRST.

This lab contains NO exploit code, NO payloads and NO attack commands. Every tool
reads a local file you own and produces a governance, planning, detection or
reporting artifact. Nothing scans, connects to, exploits or collects data from any
system. Adversary emulation is taught as a PLANNING + DETECTION discipline bounded
to an isolated, owned range.

Requirements: Python 3 (standard library only). Tested on CPython 3.14.4,
Windows 11. No third-party packages, no network.

Tools and typical use (run from this directory):

  python3 roe.py data/roe_incomplete.json        # FAIL: 10 findings, 6 HIGH
  python3 roe.py data/roe_complete.json          # PASS: engagement may proceed

  python3 scopecheck.py data/authorized_scope.json 10.70.0.10 rk-range-web 8.8.8.8
                                                 # in-scope vs OUT-OF-SCOPE (refuses)

  python3 emulation_plan.py data/emulation_plan.json data/authorized_scope.json
                                                 # validate plan: safe + in scope

  python3 attackmap.py data/emulation_plan.json                 # all techniques
  python3 attackmap.py data/emulation_plan.json --tactic "Lateral Movement"
  python3 attackmap.py data/emulation_plan.json --tactic "Command and Control"

  python3 evidence.py add  data/evidence_log.jsonl 2 "enumerated range DC (lab)" analyst1
  python3 evidence.py list data/evidence_log.jsonl
  python3 evidence.py verify data/evidence_log.jsonl            # tamper-evident

  python3 purple.py data/emulation_plan.json data/telemetry.json  # gap analysis
  python3 report.py data/roe_complete.json data/emulation_plan.json data/telemetry.json

Data files (data/): roe_incomplete.json, roe_complete.json, authorized_scope.json,
emulation_plan.json, telemetry.json, evidence_log.jsonl, and *_output.txt captures.

Module map: M01 roe.py; M02 emulation_plan.py; M03 scopecheck.py + evidence.py;
M04 attackmap.py (endpoint/identity); M05 attackmap.py --tactic "Lateral Movement";
M06 attackmap.py --tactic "Command and Control"; M07 purple.py; M08 report.py.

Standards (verified at source 2026-11-08): MITRE ATT&CK Enterprise v20.1
(techniques T1595, T1078, T1021, T1550, T1071 current; tactics incl. TA0008
Lateral Movement, TA0011 Command and Control); NIST SP 800-115 (technical
assessment); MITRE adversary-emulation / threat-informed-defense guidance.
