#!/usr/bin/env python3
"""purple.py - offline purple-team detection-gap analysis (RedKross C19).

Compares the emulation plan (what was emulated) with the blue-team telemetry
(what was detected) and reports, per technique: DETECTED or GAP. Gaps become the
retest list - the detections to engineer and then re-emulate to confirm. This is
the core purple-team deliverable: turn emulation into improved detection.

It reads only the two local files; it runs nothing.

Usage:  python3 purple.py data/emulation_plan.json data/telemetry.json
"""
import json
import sys


def main(argv):
    if len(argv) != 3:
        print("usage: python3 purple.py <emulation_plan.json> <telemetry.json>")
        return 2
    with open(argv[1], "r", encoding="utf-8") as fh:
        plan = json.load(fh)
    with open(argv[2], "r", encoding="utf-8") as fh:
        tel = json.load(fh)
    det = {d["step"]: d for d in tel.get("detections", [])}
    print("Purple-team detection-gap analysis")
    print("=" * 70)
    detected, gaps = [], []
    for s in plan.get("steps", []):
        n = s.get("step")
        d = det.get(n, {})
        if d.get("detected"):
            detected.append(s)
            print("  [DETECTED] step %s %-7s %-32s" % (n, s.get("technique_id"), s.get("technique")))
            print("             alert: %s" % d.get("alert"))
        else:
            gaps.append(s)
            print("  [GAP]      step %s %-7s %-32s" % (n, s.get("technique_id"), s.get("technique")))
            print("             needed: %s (%s)" % (s.get("detection"), s.get("data_source")))
    print("-" * 70)
    total = len(plan.get("steps", []))
    print("coverage: %d/%d techniques detected; %d gap(s) to engineer and retest"
          % (len(detected), total, len(gaps)))
    if gaps:
        print("RETEST LIST:")
        for s in gaps:
            print("  - step %s %s (%s): build '%s' on %s, then re-emulate"
                  % (s.get("step"), s.get("technique_id"), s.get("technique"),
                     s.get("detection"), s.get("data_source")))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
