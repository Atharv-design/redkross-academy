#!/usr/bin/env python3
"""report.py - offline engagement report assembler (RedKross C19).

Assembles the capstone deliverable from the engagement artifacts: an EXECUTIVE
summary (scope, outcome, detection coverage, top recommendations) and a TECHNICAL
section (per-technique emulation, detection result, and the retest list). Every
statement traces to a provided artifact. It reads only local files; it runs
nothing.

Usage:  python3 report.py data/roe_complete.json data/emulation_plan.json data/telemetry.json
"""
import json
import sys


def load(path):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def main(argv):
    if len(argv) != 4:
        print("usage: python3 report.py <roe.json> <emulation_plan.json> <telemetry.json>")
        return 2
    roe, plan, tel = load(argv[1]), load(argv[2]), load(argv[3])
    det = {d["step"]: d for d in tel.get("detections", [])}
    steps = plan.get("steps", [])
    total = len(steps)
    ndet = sum(1 for s in steps if det.get(s.get("step"), {}).get("detected"))
    gaps = [s for s in steps if not det.get(s.get("step"), {}).get("detected")]

    print("=" * 72)
    print("ADVERSARY-EMULATION ENGAGEMENT REPORT (isolated range)")
    print("=" * 72)
    print()
    print("EXECUTIVE SUMMARY")
    print("-" * 72)
    print("Engagement : %s" % roe.get("engagement_name"))
    print("Authorised : %s" % roe.get("authorizing_party"))
    print("Scope      : %s (isolated lab range; simulation-only)"
          % ", ".join(roe.get("authorized_scope", [])))
    print("Outcome    : emulated %d ATT&CK techniques; detection stack caught %d/%d."
          % (total, ndet, total))
    pct = int(round(100.0 * ndet / total)) if total else 0
    print("             Detection coverage %d%%. %d gap(s) identified for improvement."
          % (pct, len(gaps)))
    print("Top recommendations:")
    for s in gaps[:3]:
        print("  - Build detection for %s (%s) on %s."
              % (s.get("technique"), s.get("technique_id"), s.get("data_source")))
    if not gaps:
        print("  - Maintain coverage; schedule periodic re-emulation.")
    print()
    print("TECHNICAL DETAIL")
    print("-" * 72)
    for s in steps:
        d = det.get(s.get("step"), {})
        status = "DETECTED" if d.get("detected") else "GAP"
        print("Step %s | %s %s | %s/%s | %s"
              % (s.get("step"), s.get("technique_id"), s.get("technique"),
                 s.get("tactic"), s.get("tactic_id"), status))
        print("   safety    : %s" % s.get("safety_control"))
        if d.get("detected"):
            print("   detection : %s" % d.get("alert"))
        else:
            print("   gap       : needed '%s' on %s" % (s.get("detection"), s.get("data_source")))
        print("   containment: %s" % s.get("containment", "(none listed)"))
    print()
    print("RETEST LIST (purple-team follow-up)")
    print("-" * 72)
    if not gaps:
        print("  none - all emulated techniques detected")
    for s in gaps:
        print("  - %s %s: engineer detection, then re-emulate to confirm"
              % (s.get("technique_id"), s.get("technique")))
    print()
    print("All activity was confined to the authorised isolated range under the RoE; "
          "no third-party or production system was involved.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
