#!/usr/bin/env python3
"""emulation_plan.py - offline adversary-emulation plan validator (RedKross C19).

Reads a threat-informed emulation plan and checks that every step is safe to run
in the isolated range: each step must name an ATT&CK tactic+technique, a target
that is in authorised scope, a safety control, a data source and a detection.
A step missing any of these is a planning FINDING - it must not be run.

This validates a PLAN; it runs no technique and touches no system.

Usage:  python3 emulation_plan.py data/emulation_plan.json data/authorized_scope.json
"""
import json
import sys

import scopecheck

REQUIRED = ["tactic", "tactic_id", "technique", "technique_id",
            "target", "safety_control", "data_source", "detection"]


def validate(plan, scope_args):
    nets, host_ips, host_ids = scope_args
    findings = []
    for s in plan.get("steps", []):
        n = s.get("step", "?")
        for key in REQUIRED:
            if not str(s.get(key, "")).strip():
                findings.append((n, "missing field '%s'" % key))
        tgt = str(s.get("target", ""))
        # a target may be a network or host; check scope membership for IP-like targets
        first = tgt.split("/")[0]
        verdict, _ = scopecheck.classify(first, nets, host_ips, host_ids)
        if verdict != "IN-SCOPE" and tgt not in plan_networks(plan):
            # allow exact authorised networks as targets
            if not _is_authorised_network(tgt, nets):
                findings.append((n, "target '%s' not in authorised scope" % tgt))
    return findings


def plan_networks(plan):
    return set()


def _is_authorised_network(tgt, nets):
    import ipaddress
    try:
        net = ipaddress.ip_network(tgt, strict=False)
    except ValueError:
        return False
    for n in nets:
        if net.subnet_of(n) or net == n:
            return True
    return False


def main(argv):
    if len(argv) != 3:
        print("usage: python3 emulation_plan.py <emulation_plan.json> <authorized_scope.json>")
        return 2
    with open(argv[1], "r", encoding="utf-8") as fh:
        plan = json.load(fh)
    scope_args = scopecheck.load_scope(argv[2])
    print("Adversary-emulation plan validation (isolated range)")
    print("-" * 70)
    for s in plan.get("steps", []):
        print("  step %s  %-20s %-7s %-38s" % (
            s.get("step"), s.get("tactic"), s.get("technique_id"), s.get("technique")))
        print("           target=%s  safety=%s" % (s.get("target"), s.get("safety_control")))
        print("           detect=%s" % s.get("detection"))
    print("-" * 70)
    findings = validate(plan, scope_args)
    if not findings:
        print("%d step(s) validated: all in scope, all safety-bounded, all mapped to a "
              "detection -> PASS" % len(plan.get("steps", [])))
        return 0
    for n, d in findings:
        print("  [FINDING] step %s: %s" % (n, d))
    print("%d planning finding(s) -> FAIL (fix the plan before running it)" % len(findings))
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
