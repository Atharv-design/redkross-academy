#!/usr/bin/env python3
"""scopecheck.py - offline scope-enforcement check (RedKross C19).

Decides whether a target identifier (IP or host id) is INSIDE the authorised
scope. It is the safety control that keeps emulation from ever touching an
out-of-scope system. It reads the authorised-scope file and classifies each
target; it NEVER connects to anything.

A target not provably in scope is refused (OUT-OF-SCOPE) - fail safe.

Usage:  python3 scopecheck.py data/authorized_scope.json 10.70.0.10 10.70.0.20 8.8.8.8
"""
import ipaddress
import json
import sys


def load_scope(path):
    with open(path, "r", encoding="utf-8") as fh:
        s = json.load(fh)
    nets = [ipaddress.ip_network(n, strict=False) for n in s.get("networks", [])]
    host_ips = {h["ip"] for h in s.get("hosts", []) if "ip" in h}
    host_ids = {h["id"] for h in s.get("hosts", [])}
    return nets, host_ips, host_ids


def classify(target, nets, host_ips, host_ids):
    if target in host_ids:
        return "IN-SCOPE", "listed host id"
    try:
        ip = ipaddress.ip_address(target)
    except ValueError:
        return "OUT-OF-SCOPE", "not an authorised host id and not an IP"
    if str(ip) in host_ips:
        return "IN-SCOPE", "listed host ip"
    for n in nets:
        if ip in n:
            return "IN-SCOPE", "within authorised network %s" % n
    return "OUT-OF-SCOPE", "not in any authorised network or host"


def main(argv):
    if len(argv) < 3:
        print("usage: python3 scopecheck.py <authorized_scope.json> <target> [target ...]")
        return 2
    nets, host_ips, host_ids = load_scope(argv[1])
    print("Scope enforcement check (authorised range only)")
    print("-" * 64)
    any_out = False
    for t in argv[2:]:
        verdict, why = classify(t, nets, host_ips, host_ids)
        if verdict != "IN-SCOPE":
            any_out = True
        print("  %-18s %-13s %s" % (t, verdict, why))
    print("-" * 64)
    if any_out:
        print("REFUSE: one or more targets are OUT-OF-SCOPE - do not proceed against them")
        return 1
    print("OK: all targets are in authorised scope")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
