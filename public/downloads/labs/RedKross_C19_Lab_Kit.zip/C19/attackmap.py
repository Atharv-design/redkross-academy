#!/usr/bin/env python3
"""attackmap.py - offline ATT&CK technique -> detection/containment map (C19).

Turns the emulation plan into a DEFENSIVE map: for each technique (optionally
filtered by tactic) it shows the data source that should see it, the detection
idea, and the containment/mitigation. This is the blue-team view of the plan -
the detection opportunities each emulated technique creates.

It reads only the plan file; it runs nothing.

Usage:  python3 attackmap.py data/emulation_plan.json
        python3 attackmap.py data/emulation_plan.json --tactic "Lateral Movement"
        python3 attackmap.py data/emulation_plan.json --tactic "Command and Control"
"""
import json
import sys


def main(argv):
    if len(argv) < 2:
        print("usage: python3 attackmap.py <emulation_plan.json> [--tactic <name>]")
        return 2
    path = argv[1]
    tactic = None
    if "--tactic" in argv:
        i = argv.index("--tactic")
        if i + 1 < len(argv):
            tactic = argv[i + 1]
    with open(path, "r", encoding="utf-8") as fh:
        plan = json.load(fh)
    steps = plan.get("steps", [])
    if tactic:
        steps = [s for s in steps if s.get("tactic", "").lower() == tactic.lower()]
    title = "ATT&CK detection/containment map"
    if tactic:
        title += " - tactic: %s" % tactic
    print(title)
    print("=" * 74)
    for s in steps:
        print("%-7s %-36s [%s / %s]" % (
            s.get("technique_id"), s.get("technique"),
            s.get("tactic"), s.get("tactic_id")))
        print("   data source : %s" % s.get("data_source"))
        print("   detection   : %s" % s.get("detection"))
        print("   containment : %s" % s.get("containment", "(none listed)"))
        print("-" * 74)
    print("%d technique(s) mapped to defensive telemetry and containment" % len(steps))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
