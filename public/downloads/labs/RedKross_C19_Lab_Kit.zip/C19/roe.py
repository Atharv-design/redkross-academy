#!/usr/bin/env python3
"""roe.py - offline Rules of Engagement / authorisation validator (RedKross C19).

Reviews a Rules of Engagement (RoE) file for the controls a safe, authorised
adversary-emulation engagement MUST have before any activity begins. It reads
nothing but the provided JSON file: no network, no scanning, no targets.

A missing or weak control is a FINDING. A complete RoE PASSES. This is the gate
that must pass before an engagement starts.

Usage:  python3 roe.py data/roe_incomplete.json
"""
import json
import sys


def _req(cond, sev, control, detail):
    return None if cond else {"severity": sev, "control": control, "detail": detail}


def review(roe):
    f = []
    f.append(_req(bool(roe.get("authorizing_party", "").strip()), "HIGH",
                  "authorisation", "no authorising party / signed authorisation recorded"))
    scope = roe.get("authorized_scope") or []
    f.append(_req(len(scope) > 0, "HIGH",
                  "scope", "no authorised scope defined"))
    w = roe.get("window") or {}
    f.append(_req(bool(w.get("start")) and bool(w.get("end")), "HIGH",
                  "time window", "engagement time window not fully defined"))
    f.append(_req(len(roe.get("emergency_contacts") or []) > 0, "HIGH",
                  "contacts", "no emergency contacts for deconfliction/stop"))
    dec = roe.get("deconfliction") or {}
    f.append(_req(bool(dec.get("method", "").strip()) and dec.get("operator_tags_required") is True,
                  "MEDIUM", "deconfliction", "deconfliction method / operator tagging not required"))
    f.append(_req(len(roe.get("stop_conditions") or []) > 0, "HIGH",
                  "stop conditions", "no stop conditions defined"))
    f.append(_req(len(roe.get("out_of_scope") or []) > 0, "MEDIUM",
                  "out of scope", "out-of-scope list not defined"))
    dh = roe.get("data_handling") or {}
    f.append(_req(bool(dh.get("storage", "").strip()) and dh.get("encryption") is True
                  and int(dh.get("retention_days") or 0) > 0,
                  "MEDIUM", "data handling", "data handling (storage/encryption/retention) incomplete"))
    sc = roe.get("safety_controls") or {}
    f.append(_req(sc.get("isolation_required") is True, "HIGH",
                  "isolation", "isolation not required (emulation must run in an isolated range)"))
    f.append(_req(sc.get("no_destructive_actions") is True, "HIGH",
                  "no destructive actions", "destructive actions not prohibited"))
    f.append(_req(sc.get("no_real_user_data") is True, "HIGH",
                  "no real user data", "use of real user data not prohibited"))
    f.append(_req(sc.get("simulation_only") is True, "MEDIUM",
                  "simulation only", "engagement not marked simulation-only"))
    rep = roe.get("reporting") or {}
    f.append(_req(rep.get("executive") is True and rep.get("technical") is True,
                  "LOW", "reporting", "executive and technical reporting not both committed"))
    return [x for x in f if x]


def main(argv):
    if len(argv) != 2:
        print("usage: python3 roe.py <roe.json>")
        return 2
    with open(argv[1], "r", encoding="utf-8") as fh:
        roe = json.load(fh)
    findings = review(roe)
    name = roe.get("engagement_name", "(unnamed)")
    print("Rules of Engagement review: %s" % name)
    print("-" * 64)
    if not findings:
        print("  no findings - all required controls present")
        print("RESULT: PASS (engagement may proceed within scope)")
        return 0
    highs = sum(1 for x in findings if x["severity"] == "HIGH")
    for x in findings:
        print("  [%-6s] %-22s %s" % (x["severity"], x["control"], x["detail"]))
    print("%d finding(s), %d HIGH -> FAIL (do NOT start the engagement)" % (len(findings), highs))
    print("RESULT: FAIL")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
