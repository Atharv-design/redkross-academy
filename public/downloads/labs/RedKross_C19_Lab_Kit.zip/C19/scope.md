# RedKross C19 lab - scope, authorisation and safety (READ FIRST)

This lab teaches Advanced Penetration Testing and Red Team Operations from the
DEFENDER'S and ENGAGEMENT-GOVERNANCE seat. Every tool is OFFLINE and reviews a
file you own (a Rules of Engagement, an authorised-scope list, an emulation plan,
synthetic telemetry, an evidence log). No tool scans, connects to, exploits or
collects data from any system. There are no exploit scripts, payloads or attack
commands anywhere in this lab.

## What this lab is
A governance + adversary-emulation-planning + detection toolkit for an ISOLATED,
OWNED range:
- roe.py          - validate a Rules of Engagement before any activity (FAIL/PASS)
- scopecheck.py   - decide in-scope / out-of-scope for a target; refuse out-of-scope
- emulation_plan.py - validate a threat-informed emulation plan is safe and in scope
- attackmap.py    - map each emulated ATT&CK technique to detection + containment
- evidence.py     - tamper-evident evidence log (chain of custody)
- purple.py       - detection-gap analysis (emulated vs detected) + retest list
- report.py       - assemble the executive + technical engagement report

## Authorisation (template - fill before any real engagement)
- Authorising party / signed authorisation reference: ____________________
- Authorised scope (exact hosts/networks): ____________________
- Engagement window (start / end): ____________________
- Emergency + deconfliction contacts: ____________________
- Stop conditions: ____________________
- Out of scope (everything not listed; production; any third party): ________
- Data handling (encrypted storage, retention): ____________________
- Safety controls: isolation required; no destructive actions; no real user data;
  simulation-only.

## Hard rules
- Emulation runs ONLY inside an isolated range you own, on lab accounts and
  synthetic data. Never against production, third parties, or any system you are
  not explicitly authorised and isolated to use.
- scopecheck.py fails safe: anything not provably in scope is OUT-OF-SCOPE.
- No destructive actions; no real user data; stop on any unexpected impact.
- All addresses here are RFC 1918 private (10.70.0.0/24) and exist only inside the
  owned lab. All identities and the C2 "sink" are lab-only; there is no real
  egress.

## Law (India; not legal advice)
Authorised testing of your own or a client's systems, under written agreement and
an isolated range, is legitimate security work. Unauthorised access to,
interception of, or interference with any computer resource is an offence under
the Information Technology Act, 2000 (e.g. ss.43, 43A, 66, 66C, 66D, 66F), and
personal data is governed by the Digital Personal Data Protection Act, 2023. Keep
all activity inside your authorisation and isolation.
