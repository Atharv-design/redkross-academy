#!/bin/sh
# Course 12 Module 7 - minimal build provenance: describe how the artefact was
# built (in-toto Statement layout with a SLSA-style predicate), sign it, verify
# it, and check that the artefact digest in the provenance matches the file.
# Teaching example only: a real SLSA Build L2/L3 provenance is produced by the
# hosted build platform, not by a script in the build.
set -e
export MSYS_NO_PATHCONV=1
HERE="$(pwd -W 2>/dev/null || pwd)"
cd sign
DIGEST=$(sha256sum shipments-1.0.0.tgz | cut -d' ' -f1)
cat > provenance.json <<EOF2
{
  "_type": "https://in-toto.io/Statement/v1",
  "subject": [{"name": "shipments-1.0.0.tgz", "digest": {"sha256": "$DIGEST"}}],
  "predicateType": "https://slsa.dev/provenance/v1",
  "predicate": {
    "buildDefinition": {
      "buildType": "https://tamarind.example/build/tar@v1",
      "externalParameters": {"repository": "https://git.tamarind.example/shipments",
                             "ref": "refs/tags/v1.0.0"},
      "resolvedDependencies": [{"uri": "git+https://git.tamarind.example/shipments",
                                "digest": {"gitCommit": "e935d02"}}]
    },
    "runDetails": {"builder": {"id": "https://ci.tamarind.example/runners/hosted"},
                   "metadata": {"invocationId": "build-1042"}}
  }
}
EOF2
echo "== provenance subject digest: $DIGEST"
COS="docker run --rm -e COSIGN_PASSWORD=lab-only-passphrase -v $HERE/sign:/w -w /w gcr.io/projectsigstore/cosign:latest"
rm -f cosign.key cosign.pub
$COS generate-key-pair >/dev/null 2>&1
$COS sign-blob --yes --key cosign.key --use-signing-config=false --tlog-upload=false \
  --bundle provenance.bundle provenance.json 2>&1 | tail -1
echo "== verify provenance signature"
$COS verify-blob --key cosign.pub --bundle provenance.bundle --insecure-ignore-tlog=true \
  provenance.json 2>&1 | grep -v "^WARNING" | tail -1
echo "== consumer check: artefact digest equals provenance subject?"
python ../check_provenance.py provenance.json shipments-1.0.0.tgz tampered.tgz
rm -f cosign.key
