"""Threat register scoring for the Tamarind shipment service (Course 12 Module 2).

Each entry: STRIDE category, element, threat, likelihood (1-5), impact (1-5),
mitigation and status. Risk = likelihood x impact; output is sorted so the
team works the highest risks first and can see which are still open.
Tested: CPython 3.14.4, 2026-11-07.
"""
REGISTER = [
    ("S", "login API", "credential stuffing with reused passwords", 4, 4,
     "rate limiting + MFA option + breached-password check", "planned"),
    ("T", "build pipeline", "dependency resolved from wrong package index", 2, 5,
     "single internal index, pinned hashes (Module 5)", "open"),
    ("R", "admin console", "admin changes not attributable", 3, 3,
     "audit log with user id, UTC time, before/after values", "done"),
    ("I", "shipment API", "user reads another user's shipment (IDOR)", 4, 4,
     "owner check on every read; same error for missing/forbidden", "done"),
    ("I", "logs", "tokens written to application logs", 3, 4,
     "log redaction filter + unit test", "open"),
    ("D", "tracking search", "expensive unbounded queries", 3, 3,
     "pagination, query timeout, input length limits", "planned"),
    ("E", "support role", "support staff can change delivery addresses", 2, 4,
     "separate role; dual approval for address change", "open"),
]

print(f"{'risk':>4}  {'S':1}  {'element':16} {'status':8} threat")
for stride, element, threat, lik, imp, mit, status in sorted(
        REGISTER, key=lambda r: (-(r[3] * r[4]), r[1])):
    print(f"{lik * imp:>4}  {stride:1}  {element:16} {status:8} {threat}")
open_high = [r for r in REGISTER if r[3] * r[4] >= 12 and r[6] != "done"]
print(f"open or planned with risk >= 12: {len(open_high)} -> "
      + "; ".join(f"{r[1]}" for r in open_high))
