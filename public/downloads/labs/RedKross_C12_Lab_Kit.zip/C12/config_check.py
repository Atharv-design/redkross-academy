"""Startup configuration hardening check (Course 12 Module 6).

Refuses to start in production with insecure settings, and never prints
secret values. Exit code 0 = OK, 1 = insecure configuration.
Usage: python config_check.py <env-file>     Tested: CPython 3.14.4, 2026-11-07
"""
import sys

SECRET_KEYS = {"DB_PASSWORD", "API_TOKEN", "SESSION_SECRET"}


def load(path):
    cfg = {}
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            cfg[k.strip()] = v.strip()
    return cfg


def check(cfg):
    problems = []
    if cfg.get("APP_ENV") == "production":
        if cfg.get("DEBUG", "false").lower() == "true":
            problems.append("DEBUG must be false in production")
        if cfg.get("MIN_TLS", "") not in ("1.2", "1.3"):
            problems.append("MIN_TLS must be 1.2 or 1.3")
        if cfg.get("COOKIE_SECURE", "false").lower() != "true":
            problems.append("COOKIE_SECURE must be true")
        if not cfg.get("ALLOWED_HOSTS") or cfg.get("ALLOWED_HOSTS") == "*":
            problems.append("ALLOWED_HOSTS must list explicit hosts")
    for k in SECRET_KEYS & cfg.keys():
        v = cfg[k]
        if not v.startswith("secretref:"):
            problems.append(f"{k} is a literal value; use a secrets-manager reference")
        elif len(v) <= len("secretref:"):
            problems.append(f"{k} reference is empty")
    return problems


if __name__ == "__main__":
    cfg = load(sys.argv[1])
    shown = {k: ("***" if k in SECRET_KEYS else v) for k, v in cfg.items()}
    print("config:", shown)
    issues = check(cfg)
    for p in issues:
        print("  FAIL:", p)
    print("result:", "INSECURE" if issues else "OK")
    sys.exit(1 if issues else 0)
