"""Consumer-side check: artefact digests versus a provenance subject (C12-M07).
Usage: python check_provenance.py provenance.json file [file ...]"""
import hashlib
import json
import sys

p = json.load(open(sys.argv[1]))
want = p["subject"][0]["digest"]["sha256"]
for f in sys.argv[2:]:
    got = hashlib.sha256(open(f, "rb").read()).hexdigest()
    print(f"  {f:20} {'MATCH' if got == want else 'MISMATCH'}")
print("  builder:", p["predicate"]["runDetails"]["builder"]["id"])
