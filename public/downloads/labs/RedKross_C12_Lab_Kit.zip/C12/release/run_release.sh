#!/bin/sh
# Course 12 Module 8 - local secure release pipeline for the shipment service.
set -e
export MSYS_NO_PATHCONV=1
HERE="$(cd .. && (pwd -W 2>/dev/null || pwd))"
rm -rf out && mkdir out  # created on the host so non-root containers can write
docker run --rm -v "$HERE:/lab" python:3.12-slim sh /lab/release/pipeline_in_container.sh
echo $(docker run --rm -v "$HERE:/lab" zricethezav/gitleaks:latest detect --source /lab/app --no-git --no-banner --redact >/dev/null 2>&1; echo $?) > out/secrets.rc
tar -czf out/shipments-1.0.0.tgz -C ../app shipments.py
COS="docker run --rm -e COSIGN_PASSWORD=lab-only-passphrase -v $HERE/release/out:/w -w /w gcr.io/projectsigstore/cosign:latest"
$COS generate-key-pair >/dev/null 2>&1
$COS sign-blob --yes --key cosign.key --use-signing-config=false --tlog-upload=false --bundle shipments.bundle shipments-1.0.0.tgz >/dev/null 2>&1
$COS verify-blob --key cosign.pub --bundle shipments.bundle --insecure-ignore-tlog=true shipments-1.0.0.tgz >/dev/null 2>&1; echo $? > out/sign.rc
rm -f out/cosign.key
python release_report.py out
