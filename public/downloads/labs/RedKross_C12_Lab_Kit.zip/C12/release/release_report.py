"""Release security report generator (Course 12 Module 8). Reads gate results
from a pipeline output folder and prints a plain-text report.
Usage: python release_report.py out      Tested: CPython 3.14.4, 2026-11-07"""
import hashlib
import json
import sys
from pathlib import Path

out = Path(sys.argv[1])
rc = lambda n: int((out / f"{n}.rc").read_text().strip())
gates = [("security unit tests", "tests"), ("SAST (semgrep --error)", "sast"),
         ("dependency audit (pip-audit)", "audit"), ("secret scan (gitleaks)", "secrets"),
         ("SBOM generated", "sbom"), ("signature verifies", "sign")]
print("RELEASE SECURITY REPORT - shipments 1.0.0 (Tamarind Logistics, FICTIONAL)")
print("artefact sha256:", hashlib.sha256((out / "shipments-1.0.0.tgz").read_bytes()).hexdigest())
print("tools:", " | ".join(l.strip() for l in (out / "versions.txt").read_text().splitlines()))
print("\nGATES")
for label, key in gates:
    print(f"  {'PASS' if rc(key) == 0 else 'FAIL':4}  {label}  (exit {rc(key)})")
sast = json.loads((out / "sast.json").read_text())
print(f"\nSAST findings: {len(sast['results'])}")
audit = json.loads((out / "audit.json").read_text())
vulns = {(d['name'], v['id']) for d in audit["dependencies"] for v in d["vulns"]}
print(f"Dependency advisories (unique): {len(vulns)} across "
      f"{len({d['name'] for d in audit['dependencies']})} resolved packages")
sbom = json.loads((out / "sbom.cdx.json").read_text())
comps = sorted(f"{c['name']} {c['version']}" for c in sbom.get("components", []))
print(f"SBOM: CycloneDX {sbom['specVersion']}, {len(comps)} components")
lic = json.loads((out / "licences.json").read_text())
nonperm = sorted(f"{l['Name']} ({l['License']})" for l in lic
                 if not any(k in l["License"] for k in ("MIT", "BSD", "Apache", "ISC", "PSF")))
print("Non-permissive / review-needed licences:", "; ".join(nonperm) or "none")
ok = all(rc(k) == 0 for _, k in gates)
print("\nDECISION:", "RELEASE APPROVED (all gates passed)" if ok else "RELEASE BLOCKED")
