#!/bin/sh
# Runs inside python:3.12-slim: tests, SAST, dependency audit, SBOM, licences.
# Each step writes a result file; the script never stops early so the report
# can show every gate's status.
cd /lab/release
pip install -q --root-user-action=ignore semgrep pip-audit cyclonedx-bom pip-licenses >/dev/null 2>&1
mkdir -p out
( cd ../app && python -m unittest test_shipments >/dev/null 2>&1 ); echo $? > out/tests.rc
semgrep scan --config ../sast/rules.yml --metrics=off --disable-version-check --quiet --error \
  --json -o out/sast.json ../app/shipments.py >/dev/null 2>&1; echo $? > out/sast.rc
pip-audit -r requirements.txt -f json -o out/audit.json >/dev/null 2>&1; echo $? > out/audit.rc
python -m venv /tmp/rv >/dev/null && /tmp/rv/bin/pip install -q -r requirements.txt >/dev/null 2>&1
# tools stay OUTSIDE the release environment, so they do not appear in its SBOM
cyclonedx-py environment --of JSON -o out/sbom.cdx.json /tmp/rv >/dev/null 2>&1; echo $? > out/sbom.rc
pip-licenses --python /tmp/rv/bin/python --format=json --output-file out/licences.json >/dev/null 2>&1
semgrep --version > out/versions.txt; pip-audit --version >> out/versions.txt
