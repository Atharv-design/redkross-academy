#!/bin/sh
# Course 12 Module 6 - a secret removed from code still lives in git history.
# Builds a throwaway repo, commits a FICTIONAL key (random, never issued),
# removes it, then scans working tree vs full history with gitleaks.
set -e
export MSYS_NO_PATHCONV=1
HERE="$(pwd -W 2>/dev/null || pwd)"
rm -rf secrets_repo && mkdir secrets_repo && cd secrets_repo
git init -q -b main && git config user.email lab@example.invalid && git config user.name "C12 lab"
printf 'TIMEOUT = 30\n' > settings.py && git add . && git commit -qm "initial"
printf 'TIMEOUT = 30\nAWS_ACCESS_KEY_ID = "AKIA2E0A8F3B244C9986"\nAWS_SECRET_ACCESS_KEY = "Zq3vT8xP1mR6yL0cW4nB7sK9dF2hJ5gA8eU1iO3t"\n' > settings.py
git commit -qam "add storage client config"
printf 'import os\nTIMEOUT = 30\nAWS_ACCESS_KEY_ID = os.environ["AWS_ACCESS_KEY_ID"]\n' > settings.py
git commit -qam "move credentials to environment"
echo "== git log"; git log --oneline
echo "== working tree contains key?"; grep -c AKIA settings.py || true
cd ..
echo "== gitleaks: working directory only (--no-git)"
docker run --rm -v "$HERE/secrets_repo:/repo" zricethezav/gitleaks:latest detect --source /repo --no-git --no-banner --redact -v 2>&1 | grep -E "Finding|RuleID|Commit|leaks found|no leaks" || true
echo "== gitleaks: full git history"
docker run --rm -v "$HERE/secrets_repo:/repo" zricethezav/gitleaks:latest detect --source /repo --no-banner --redact -v 2>&1 | grep -E "Finding|RuleID|Commit:|File|leaks found|no leaks" || true
docker run --rm zricethezav/gitleaks:latest version
