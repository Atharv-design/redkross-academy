import hashlib
# ruleid: rk-weak-hash-md5
hashlib.md5(b"pw")
# ok: rk-weak-hash-md5
hashlib.md5(b"partner-file", usedforsecurity=False)
