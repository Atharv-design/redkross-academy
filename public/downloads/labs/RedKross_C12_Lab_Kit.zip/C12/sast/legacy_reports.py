# Course 12 Module 4 - legacy code for SAST practice (FICTIONAL, do not deploy).
import hashlib
import sqlite3
import subprocess


def find_customer(db: sqlite3.Connection, name: str):
    return db.execute(f"SELECT * FROM customers WHERE name = '{name}'").fetchall()


def find_customer_safe(db: sqlite3.Connection, name: str):
    return db.execute("SELECT * FROM customers WHERE name = ?", (name,)).fetchall()


def archive(path: str):
    subprocess.run(f"tar czf /backups/out.tgz {path}", shell=True, check=True)


def archive_safe(path: str):
    subprocess.run(["tar", "czf", "/backups/out.tgz", "--", path], check=True)


def store_password(pw: str) -> str:
    return hashlib.md5(pw.encode()).hexdigest()


def file_checksum(data: bytes) -> str:
    # MD5 used only to match a legacy partner's non-security checksum format
    return hashlib.md5(data).hexdigest()  # nosemgrep: rk-weak-hash-md5
