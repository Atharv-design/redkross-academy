#!/bin/sh
# Course 12 Module 7 - artefact integrity: hash, sign, verify, detect tampering.
# Uses cosign with a local key pair; nothing is uploaded to a transparency log.
set -e
export MSYS_NO_PATHCONV=1
HERE="$(pwd -W 2>/dev/null || pwd)"
rm -rf sign && mkdir sign && cd sign
tar -czf shipments-1.0.0.tgz -C ../app shipments.py
sha256sum shipments-1.0.0.tgz > SHA256SUMS
COS="docker run --rm -e COSIGN_PASSWORD=lab-only-passphrase -v $HERE/sign:/w -w /w gcr.io/projectsigstore/cosign:latest"
$COS version 2>&1 | grep -E "GitVersion" || true
echo "== generate key pair (lab only; production keys belong in a KMS/HSM)"
$COS generate-key-pair >/dev/null 2>&1 && ls cosign.key cosign.pub
echo "== sign"
$COS sign-blob --yes --key cosign.key --use-signing-config=false --tlog-upload=false --bundle shipments.bundle shipments-1.0.0.tgz 2>&1 | tail -1
echo "== verify original"
$COS verify-blob --key cosign.pub --bundle shipments.bundle --insecure-ignore-tlog=true shipments-1.0.0.tgz 2>&1 | grep -v "^WARNING" | tail -1 || true
echo "== tamper: append one byte to a copy and verify"
cp shipments-1.0.0.tgz tampered.tgz && printf 'X' >> tampered.tgz
$COS verify-blob --key cosign.pub --bundle shipments.bundle --insecure-ignore-tlog=true tampered.tgz 2>&1 | grep -vi warning | tail -2 || true
echo "== hashes"; sha256sum shipments-1.0.0.tgz tampered.tgz
rm -f cosign.key
