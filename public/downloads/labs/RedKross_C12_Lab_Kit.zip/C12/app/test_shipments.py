"""Security unit tests for shipments.py (Course 12 Module 3).
Run: python -m unittest test_shipments -v     Tested: CPython 3.14.4, 2026-11-07
"""
import unittest

import shipments as s


class Validation(unittest.TestCase):
    def test_valid_id_accepted(self):
        self.assertEqual(s.validate_tracking_id("TL-00000001"), "TL-00000001")

    def test_malformed_ids_rejected(self):
        for bad in ["", "TL-1", "tl-00000001", "TL-00000001 ", "TL-00000001'--", None, 42]:
            with self.subTest(bad=bad), self.assertRaises(s.ValidationError):
                s.validate_tracking_id(bad)


class Authorisation(unittest.TestCase):
    def setUp(self):
        self.db = s.connect()

    def test_owner_can_read(self):
        self.assertEqual(s.get_shipment(self.db, "TL-00000001", "asha")["owner"], "asha")

    def test_other_user_denied(self):
        with self.assertRaises(s.AccessDenied):
            s.get_shipment(self.db, "TL-00000001", "ben")

    def test_missing_and_forbidden_look_the_same(self):
        msgs = []
        for tid, user in (("TL-99999999", "asha"), ("TL-00000002", "asha")):
            with self.assertRaises(s.AccessDenied) as cm:
                s.get_shipment(self.db, tid, user)
            msgs.append(str(cm.exception))
        self.assertEqual(msgs[0], msgs[1])


class Encoding(unittest.TestCase):
    def test_note_is_html_escaped(self):
        out = s.render_note_html({"note": "Fragile <glass> & \"quoted\""})
        self.assertEqual(out, "<p class='note'>Fragile &lt;glass&gt; &amp; &quot;quoted&quot;</p>")


class Passwords(unittest.TestCase):
    def test_verify_and_reject(self):
        salt, digest = s.hash_password("correct horse battery staple")
        self.assertTrue(s.verify_password("correct horse battery staple", salt, digest))
        self.assertFalse(s.verify_password("Correct horse battery staple", salt, digest))

    def test_same_password_different_salt(self):
        self.assertNotEqual(s.hash_password("pw")[1], s.hash_password("pw")[1])


if __name__ == "__main__":
    unittest.main()
