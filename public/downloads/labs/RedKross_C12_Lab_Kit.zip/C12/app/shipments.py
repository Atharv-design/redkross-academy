"""Tamarind shipment service - secure coding reference (Course 12 Module 3).

Demonstrates: allowlist input validation, parameterised SQL, contextual
output encoding, salted password hashing (scrypt), constant-time comparison
and deny-by-default object-level authorisation. Standard library only.
Tested: CPython 3.14.4, 2026-11-07. All data fictional.
"""
import hashlib
import hmac
import html
import os
import re
import sqlite3

TRACKING_RE = re.compile(r"TL-\d{8}")          # allowlist: exact format
SCRYPT = dict(n=2**14, r=8, p=1, dklen=32)


class ValidationError(ValueError):
    pass


class AccessDenied(PermissionError):
    pass


def validate_tracking_id(value: str) -> str:
    if not isinstance(value, str) or not TRACKING_RE.fullmatch(value):
        raise ValidationError("tracking id must look like TL-12345678")
    return value


def hash_password(password: str, salt: bytes | None = None) -> tuple[bytes, bytes]:
    salt = salt or os.urandom(16)
    return salt, hashlib.scrypt(password.encode(), salt=salt, **SCRYPT)


def verify_password(password: str, salt: bytes, expected: bytes) -> bool:
    return hmac.compare_digest(hashlib.scrypt(password.encode(), salt=salt, **SCRYPT), expected)


def connect():
    db = sqlite3.connect(":memory:")
    db.execute("CREATE TABLE shipments (tracking TEXT PRIMARY KEY, owner TEXT, note TEXT)")
    db.executemany("INSERT INTO shipments VALUES (?, ?, ?)", [
        ("TL-00000001", "asha", "Fragile <glass>"),
        ("TL-00000002", "ben", "Leave at gate"),
    ])
    return db


def get_shipment(db, tracking: str, user: str) -> dict:
    tracking = validate_tracking_id(tracking)
    row = db.execute("SELECT tracking, owner, note FROM shipments WHERE tracking = ?",
                     (tracking,)).fetchone()
    if row is None or row[1] != user:          # same error for missing and not-yours
        raise AccessDenied("not found")
    return {"tracking": row[0], "owner": row[1], "note": row[2]}


def render_note_html(shipment: dict) -> str:
    return f"<p class='note'>{html.escape(shipment['note'], quote=True)}</p>"
