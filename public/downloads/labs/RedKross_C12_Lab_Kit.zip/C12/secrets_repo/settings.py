import os
TIMEOUT = 30
AWS_ACCESS_KEY_ID = os.environ["AWS_ACCESS_KEY_ID"]
