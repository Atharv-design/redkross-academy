C13 - ACTIVE DIRECTORY AND ENTERPRISE SECURITY : LAB ASSETS
===========================================================
All assets are DEFENDER-ONLY and run against a self-contained lab domain
controller you build yourself. Nothing here scans, exploits, or touches any
system you do not own. Every company, user, and password is fictional.

Lab domain:  AD.SAHYADRI.EXAMPLE  (NetBIOS SAHYADRI)  -- "Sahyadri Logistics"
Built with:  Samba 4.22.11 (Active Directory Domain Controller role) in Docker

CONTENTS
  dc/Dockerfile          Debian + Samba AD DC image
  dc/provision.sh        provisions the domain on first start, runs samba -i
  setup_domain.sh        populates the tiered org (OUs, users, groups, an SPN
                         service account, a fine-grained password policy, a GPO)
  auth_monitor.py        parses JSON authentication audit events for failed-logon
                         bursts, weak Kerberos enctypes, and Tier 0 logon sources
  dir_review.py          offline AD hygiene review from an LDIF export
                         (Kerberoastable SPNs, never-expire, delegation, stale)
  data/                  captured telemetry and tool output (see below)

BUILD AND RUN  (Docker required; from this directory)
  docker build -t rk-dc ./dc
  docker run -d --name rk-dc --privileged -h dc1 \
      -e ADMIN_PASS='Lab-Only-Adm1n!' -p 127.0.0.1:1389:389 rk-dc
  # wait ~20s for first-boot provisioning, then:
  docker cp setup_domain.sh rk-dc:/setup.sh && docker exec rk-dc sh /setup.sh

VERIFIED OUTPUTS (produced on this build, Samba 4.22.11)
  * domain info        Forest/Domain ad.sahyadri.example, DC dc1, role DC
  * Kerberos           kinit asha@AD.SAHYADRI.EXAMPLE -> TGT (AES256) issued
  * LDAP over GSSAPI   ldapwhoami -Y GSSAPI -> u:SAHYADRI\asha
  * audit telemetry    JSON "Authentication" events, eventId 4624, logonType,
                       status, passwordType=aes256-cts-hmac-sha1-96
  * auth_monitor.py    flags asha failed-logon burst at --fail-threshold 4
  * dir_review.py      5 findings; legacy-svc = SPN + never-expire + dormant;
                       exit code 1 because a HIGH finding is present

data/auth_audit.jsonl        57 captured JSON auth events (one per line)
data/directory_export.ldif   read-only LDIF snapshot of user objects
data/auth_monitor_output.txt saved monitor run
data/dir_review_output.txt   saved hygiene-review run

NOTE: all Kerberos/LDAP tooling is used only to AUTHENTICATE AS, QUERY, and
AUDIT the learner's own lab domain. No attack tooling is included or required.
