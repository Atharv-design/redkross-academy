#!/usr/bin/env python3
"""C13 lab: authentication-telemetry monitor (defensive, read-only).

Parses Samba's JSON authentication audit stream (eventId 4624-style records,
one JSON object per line) and surfaces the signals a blue team watches for:

  * failed-logon bursts per account      (password-guessing / lockout risk)
  * weak Kerberos encryption types        (RC4/DES -> downgrade & roasting risk)
  * service-ticket requests for SPN users  (Kerberoasting reconnaissance)
  * privileged (Tier 0) logons by source   (where do admin logons originate?)

It reads telemetry only. It does not authenticate, scan or change anything.

  python3 auth_monitor.py data/auth_audit.jsonl
  python3 auth_monitor.py data/auth_audit.jsonl --fail-threshold 5
"""
import argparse, json, sys
from collections import defaultdict, Counter

WEAK_ENCTYPES = {"rc4-hmac", "rc4-hmac-md5", "arcfour-hmac-md5",
                 "des-cbc-crc", "des-cbc-md5"}
# accounts that should hold Tier 0 (domain-wide) privilege in this lab org
TIER0 = {"t0-admin", "administrator"}

def load(path):
    rows = []
    with open(path, encoding="utf-8") as fh:
        for ln in fh:
            ln = ln.strip()
            if not ln:
                continue
            try:
                obj = json.loads(ln)
            except json.JSONDecodeError:
                continue
            a = obj.get("Authentication")
            if a:
                rows.append(a)
    return rows

def acct(a):
    return (a.get("becameAccount") or a.get("mappedAccount")
            or a.get("clientAccount") or "?").split("@")[0].lower()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("logfile")
    ap.add_argument("--fail-threshold", type=int, default=5,
                    help="failed logons per account before it is flagged")
    args = ap.parse_args()

    rows = load(args.logfile)
    if not rows:
        print("no authentication events found", file=sys.stderr); return 2

    fails = defaultdict(int)
    oks = defaultdict(int)
    sources = defaultdict(Counter)
    weak = []
    tier0_logons = []
    for a in rows:
        name = acct(a)
        status = a.get("status", "")
        src = (a.get("remoteAddress") or "").replace("ipv4:", "").rsplit(":", 1)[0]
        if status == "NT_STATUS_OK":
            oks[name] += 1
            if src:
                sources[name][src] += 1
            if name in TIER0:
                tier0_logons.append((name, src, a.get("authDescription")))
        elif status in ("NT_STATUS_WRONG_PASSWORD", "NT_STATUS_PREAUTH_FAILED"):
            fails[name] += 1
        enc = (a.get("passwordType") or "").lower()
        if enc in WEAK_ENCTYPES:
            weak.append((name, enc, src))

    print("=" * 66)
    print("AUTHENTICATION TELEMETRY SUMMARY  (events: %d)" % len(rows))
    print("=" * 66)
    print("\n%-16s %6s %6s  top source" % ("account", "ok", "fail"))
    print("-" * 50)
    for name in sorted(set(list(oks) + list(fails))):
        top = sources[name].most_common(1)
        tops = top[0][0] if top else "-"
        print("%-16s %6d %6d  %s" % (name, oks[name], fails[name], tops))

    print("\n[ FINDINGS ]")
    n = 0
    for name, c in sorted(fails.items(), key=lambda x: -x[1]):
        if c >= args.fail_threshold:
            n += 1
            print("  ! %d failed logons for '%s' (>= threshold %d): "
                  "possible guessing; check lockout policy" % (c, name, args.fail_threshold))
    if weak:
        n += 1
        wc = Counter(e for _, e, _ in weak)
        print("  ! weak Kerberos enctype in use: %s -> enforce AES, retire RC4/DES"
              % ", ".join("%s(%d)" % (k, v) for k, v in wc.items()))
    else:
        print("  . all observed Kerberos auth used AES (no RC4/DES) - good")
    if tier0_logons:
        srcs = sorted({s for _, s, _ in tier0_logons if s})
        print("  i Tier 0 logons observed from: %s" % (", ".join(srcs) or "local"))
        print("    (confirm these originate only from privileged access workstations)")
    if n == 0:
        print("  . no threshold findings in this window")
    return 0

if __name__ == "__main__":
    sys.exit(main())
