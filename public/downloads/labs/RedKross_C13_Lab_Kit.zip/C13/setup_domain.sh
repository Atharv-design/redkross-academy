#!/bin/sh
# C13 lab: populate the Sahyadri Logistics domain with a tiered structure,
# users, groups, a service account with an SPN, Group Policy objects and a
# fine-grained password policy. Run INSIDE the rk-dc container:
#   docker cp setup_domain.sh rk-dc:/setup.sh && docker exec rk-dc sh /setup.sh
# Every name and password here is a fictional lab value.
set -e
# GPO/DNS tools need the DC's own internal DNS (SRV records):
printf "nameserver 127.0.0.1
search ad.sahyadri.example
" > /etc/resolv.conf
st() { echo; echo "### $*"; }
P='Lab-Only-P@ssw0rd-2026'          # ordinary user password (lab only)
WEAK='Summer2026'                    # deliberately weak, for the audit lab

st "Organisational units (tiered administration model)"
for ou in "OU=Tier0" "OU=Tier1" "OU=Tier2" "OU=ServiceAccounts" "OU=Workstations" "OU=Servers"; do
  samba-tool ou create "$ou,DC=ad,DC=sahyadri,DC=example" 2>/dev/null || echo "  $ou exists"
done

st "Users"
# Tier 0: domain admins; Tier 1: server admins; Tier 2: workstation/helpdesk; plus ordinary staff
samba-tool user create t0-admin "$P"  --given-name=Tier0 --surname=Admin --userou="OU=Tier0" 2>/dev/null || true
samba-tool user create t1-srvadm "$P" --given-name=Tier1 --surname=SrvAdmin --userou="OU=Tier1" 2>/dev/null || true
samba-tool user create t2-help "$P"   --given-name=Tier2 --surname=Helpdesk --userou="OU=Tier2" 2>/dev/null || true
samba-tool user create asha "$P"      --given-name=Asha --surname=Kulkarni --userou="OU=Tier2" 2>/dev/null || true
samba-tool user create rohan "$WEAK"  --given-name=Rohan --surname=Deshpande --userou="OU=Tier2" 2>/dev/null || true
samba-tool user create legacy-svc "$WEAK" --given-name=Legacy --surname=Service \
  --userou="OU=ServiceAccounts" --description="app pool account (SPN set below)" 2>/dev/null || true

st "Groups and memberships"
samba-tool group add Tier0-Admins 2>/dev/null || true
samba-tool group add Server-Admins 2>/dev/null || true
samba-tool group add Helpdesk 2>/dev/null || true
samba-tool group addmembers "Domain Admins" t0-admin 2>/dev/null || true
samba-tool group addmembers Tier0-Admins t0-admin 2>/dev/null || true
samba-tool group addmembers Server-Admins t1-srvadm 2>/dev/null || true
samba-tool group addmembers Helpdesk t2-help,asha 2>/dev/null || true

st "A service account with a Service Principal Name (SPN)"
# An SPN on a normal user account is what makes Kerberoasting possible; the
# lab uses it only to teach detection and the AES/gMSA defences.
samba-tool spn add HTTP/app1.ad.sahyadri.example legacy-svc 2>/dev/null || echo "  SPN exists"

st "A fine-grained password policy for service accounts (longer, no expiry pressure)"
samba-tool domain passwordsettings pso create ServiceAccountPSO 50 \
  --min-pwd-length=25 --history-length=24 --complexity=on 2>/dev/null || echo "  PSO exists"
samba-tool domain passwordsettings pso apply ServiceAccountPSO legacy-svc 2>/dev/null || true

st "Group Policy objects"
samba-tool gpo create "RK Workstation Baseline" 2>/dev/null || echo "  GPO exists"
samba-tool gpo listall | grep -A1 "RK Workstation Baseline" || true

st "Mark one account with 'password never expires' (a finding for the audit lab)"
samba-tool user setexpiry legacy-svc --noexpiry 2>/dev/null || true

st "Summary"
echo "users:"; samba-tool user list | sort | tr '\n' ' '; echo
echo "SPNs on legacy-svc:"; samba-tool spn list legacy-svc 2>/dev/null | grep HTTP || true
echo "done"
