#!/usr/bin/env python3
"""C13 lab: Active Directory hygiene reviewer (defensive, offline).

Parses an LDIF snapshot of user objects (exported read-only from the domain)
and reports common identity-security weaknesses, the same checks a posture
review or a tool such as PingCastle looks for, explained from first
principles so learners understand WHY each is a risk:

  * user accounts carrying an SPN        -> Kerberoastable service accounts
  * DONT_EXPIRE_PASSWD (UAC 0x10000)     -> passwords that never rotate
  * DONT_REQ_PREAUTH  (UAC 0x400000)     -> AS-REP roastable accounts
  * TRUSTED_FOR_DELEGATION (UAC 0x80000) -> unconstrained delegation
  * ACCOUNTDISABLE not set + never used  -> stale / dormant enabled accounts
  * pwdLastSet == 0                      -> password not set / change-at-logon

Offline analysis only: it reads an exported file, never the live directory.

  python3 dir_review.py data/directory_export.ldif
"""
import argparse, sys, datetime

UAC = {
    "ACCOUNTDISABLE": 0x0002,
    "DONT_EXPIRE_PASSWD": 0x10000,
    "DONT_REQ_PREAUTH": 0x400000,
    "TRUSTED_FOR_DELEGATION": 0x80000,
    "SMARTCARD_REQUIRED": 0x40000,
}
# FILETIME epoch (1601-01-01) -> Unix; 100ns ticks
def filetime_to_dt(ticks):
    try:
        ticks = int(ticks)
    except (TypeError, ValueError):
        return None
    if ticks == 0:
        return None
    return datetime.datetime(1601, 1, 1) + datetime.timedelta(microseconds=ticks / 10)

def parse_ldif(path):
    objs, cur = [], {}
    with open(path, encoding="utf-8") as fh:
        for raw in fh:
            line = raw.rstrip("\n")
            if not line.strip():
                if cur:
                    objs.append(cur); cur = {}
                continue
            if line.startswith("#"):
                continue
            if ":" not in line:
                continue
            key, _, val = line.partition(":")
            key = key.strip(); val = val.strip()
            cur.setdefault(key, []).append(val)
    if cur:
        objs.append(cur)
    return objs

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("ldif")
    ap.add_argument("--stale-days", type=int, default=90)
    args = ap.parse_args()

    objs = parse_ldif(args.ldif)
    findings = []
    users = 0
    now = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
    for o in objs:
        sam = (o.get("sAMAccountName") or [""])[0]
        if not sam:
            continue
        users += 1
        try:
            uac = int((o.get("userAccountControl") or ["0"])[0])
        except ValueError:
            uac = 0
        disabled = bool(uac & UAC["ACCOUNTDISABLE"])
        spns = o.get("servicePrincipalName") or []

        if spns and not sam.endswith("$") and sam.lower() != "krbtgt":
            findings.append(("HIGH", sam,
                "user account carries SPN(s) %s -> Kerberoastable; "
                "use a gMSA or a 25+ char random password and AES only" % ",".join(spns)))
        if uac & UAC["DONT_EXPIRE_PASSWD"]:
            findings.append(("MEDIUM", sam,
                "password set to never expire (UAC 0x10000) -> ensure a long "
                "random secret and compensating rotation"))
        if uac & UAC["DONT_REQ_PREAUTH"]:
            findings.append(("HIGH", sam,
                "Kerberos pre-auth not required (UAC 0x400000) -> AS-REP roastable"))
        if (uac & UAC["TRUSTED_FOR_DELEGATION"]) and not sam.endswith("$"):
            findings.append(("HIGH", sam,
                "unconstrained delegation (UAC 0x80000) -> can impersonate any "
                "user that authenticates to it; use constrained/RBCD instead"))
        pls = (o.get("pwdLastSet") or ["0"])[0]
        if pls == "0" and not disabled and sam.lower() not in ("guest", "krbtgt"):
            findings.append(("LOW", sam,
                "pwdLastSet=0 (no password set / must change at next logon)"))
        last = filetime_to_dt((o.get("lastLogon") or ["0"])[0])
        if not disabled and not sam.endswith("$") and sam.lower() not in ("guest",):
            if last is None:
                findings.append(("LOW", sam, "enabled but never logged on (dormant?)"))
            elif (now - last).days > args.stale_days:
                findings.append(("LOW", sam,
                    "no logon in %d days (stale, review for disable)" % (now - last).days))

    order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    findings.sort(key=lambda f: (order[f[0]], f[1]))
    print("=" * 70)
    print("AD HYGIENE REVIEW  (user objects: %d, findings: %d)" % (users, len(findings)))
    print("=" * 70)
    for sev, sam, msg in findings:
        print("[%-6s] %-14s %s" % (sev, sam, msg))
    if not findings:
        print("no hygiene findings")
    # exit non-zero if any HIGH, so it can gate a pipeline
    return 1 if any(f[0] == "HIGH" for f in findings) else 0

if __name__ == "__main__":
    sys.exit(main())
