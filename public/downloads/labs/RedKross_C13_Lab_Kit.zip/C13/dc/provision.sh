#!/bin/sh
# Provision the domain on first start, then run samba in the foreground.
set -e
if [ ! -f /var/lib/samba/private/sam.ldb ]; then
  rm -f /etc/samba/smb.conf
  samba-tool domain provision --use-rfc2307 --realm=AD.SAHYADRI.EXAMPLE --domain=SAHYADRI \
    --server-role=dc --dns-backend=SAMBA_INTERNAL --adminpass="${ADMIN_PASS:-Lab-Only-Adm1n!}" \
    --option="log level = 1 auth_audit:3 auth_json_audit:3 dsdb_json_audit:3 dsdb_group_json_audit:3" \
    --option="dns forwarder = 127.0.0.11"
  cp /var/lib/samba/private/krb5.conf /etc/krb5.conf
fi
exec samba -i --no-process-group
