r"""Decode UserAssist-style ROT13 value names (Course 09 Module 5).

UserAssist stores program paths ROT13-encoded under the user's NTUSER.DAT:
Software\Microsoft\Windows\CurrentVersion\Explorer\UserAssist\{GUID}\Count
The samples below are synthetic, not read from any real registry.
Tested: CPython 3.14.4, 2026-11-07.
"""
import codecs

BS = chr(92)  # backslash, kept out of string literals on purpose
SAMPLE = [BS.join(["P:", "Hfref", "qrzb", "Qbjaybnqf", "vaibvpr_ivrjre.rkr"]),
          "{1NP14R77-02R7-4R5Q-O744-2RO1NR5198O7}" + BS + "abgrcnq.rkr"]
for s in SAMPLE:
    print(f"{s}\n  -> {codecs.decode(s, 'rot_13')}")
