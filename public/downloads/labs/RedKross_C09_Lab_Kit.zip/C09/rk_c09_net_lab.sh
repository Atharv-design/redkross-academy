#!/bin/sh
# Course 09 network forensics lab. Creates an isolated Docker network with a
# web server and a client, captures the client's download of a fictional file,
# then carves the file from the pcap and proves it matches by SHA-256.
# All traffic stays on a private Docker bridge. Cleanup at the end.
set -e
export MSYS_NO_PATHCONV=1
NET=rk-c09-net
OUT="$(pwd -W 2>/dev/null || pwd)"
docker network create --subnet 172.31.0.0/24 "$NET" >/dev/null
docker run -d --rm --name rk9-web --network "$NET" --ip 172.31.0.10 python:3.12-slim \
  sh -c "mkdir -p /srv/backup && printf 'id,name\n1,FICTIONAL A\n2,FICTIONAL B\n' > /srv/backup/customers.csv && cd /srv && python -m http.server 80" >/dev/null
docker run -d --name rk9-cap --network container:rk9-web alpine:3.20 sh -c \
  "apk add --no-cache tcpdump >/dev/null 2>&1; touch /tmp/ready; tcpdump -i eth0 -w /tmp/c09.pcap -U port 80 2>/dev/null & sleep infinity" >/dev/null
until docker exec rk9-cap test -f /tmp/ready 2>/dev/null; do sleep 1; done
sleep 2
docker run --rm --network "$NET" --ip 172.31.0.20 curlimages/curl:latest -s -o /dev/null \
  -A "rk-backup-agent/1.0" http://172.31.0.10/backup/customers.csv
docker run --rm --network "$NET" --ip 172.31.0.20 curlimages/curl:latest -s -o /dev/null \
  http://172.31.0.10/backup/missing.zip
sleep 2
docker exec rk9-cap pkill tcpdump || true
sleep 1
docker cp rk9-cap:/tmp/c09.pcap ./rk_c09_lab.pcap >/dev/null
echo "== original file hash (on server)"
docker exec rk9-web sha256sum /srv/backup/customers.csv
docker rm -f rk9-cap rk9-web >/dev/null; docker network rm "$NET" >/dev/null
echo "== analysis (tshark in throwaway container)"
docker run --rm -v "$OUT":/data alpine:3.20 sh -c '
 apk add --no-cache tshark >/dev/null 2>&1
 cd /data; tshark -v | head -1
 echo "-- capture summary"; capinfos -c -a -e rk_c09_lab.pcap 2>/dev/null | sed -n "2,4p"
 echo "-- HTTP requests and responses"
 tshark -r rk_c09_lab.pcap -Y "http.request or http.response" -T fields \
   -e frame.time_utc -e ip.src -e ip.dst -e http.request.method -e http.request.uri \
   -e http.user_agent -e http.response.code
 echo "-- export HTTP objects"
 rm -rf /tmp/obj; tshark -r rk_c09_lab.pcap -q --export-objects http,/tmp/obj
 ls /tmp/obj; sha256sum /tmp/obj/customers.csv
 echo "-- pcap file hash"; sha256sum rk_c09_lab.pcap'
