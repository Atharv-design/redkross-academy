#!/bin/sh
# Course 09 file-system forensics lab (run inside a disposable Debian container).
# Builds small FAT and ext4 images containing fictional files, deletes one file
# in each, then examines them with The Sleuth Kit. Nothing is mounted; no host
# devices are touched.
set -e
apt-get update -qq >/dev/null && apt-get install -y -qq sleuthkit mtools e2fsprogs >/dev/null 2>&1
echo "== tool versions"; fls -V | head -1; mke2fs -V 2>&1 | head -1; mtools --version | head -1
mkdir -p /lab/src && cd /lab
printf 'Q3 payroll summary - FICTIONAL\nTotal: 1,234,567 INR\n' > src/payroll_q3.txt
printf 'meeting notes - FICTIONAL\n' > src/notes.txt
printf 'export of customer list - FICTIONAL\n' > src/customers.csv

echo "== FAT16 image"
dd if=/dev/zero of=fat.img bs=1M count=16 status=none
mformat -i fat.img -v RKEVID ::
mcopy -i fat.img src/payroll_q3.txt src/notes.txt src/customers.csv ::
mdel -i fat.img ::customers.csv
sha256sum fat.img
fsstat fat.img | sed -n '1,12p'
echo "-- fls (deleted entries marked *)"; fls -r fat.img
INODE=$(fls -d fat.img | sed -n 's/.* \([0-9]*\):.*customers.*/\1/p' | head -1)
echo "-- istat $INODE"; istat fat.img "$INODE" | sed -n '1,20p'
echo "-- icat $INODE (recovered content)"; icat fat.img "$INODE"

echo "== ext4 image"
mke2fs -q -t ext4 -d src -L RKEXT ext4.img 16M
debugfs -w -R "rm customers.csv" ext4.img 2>/dev/null
sha256sum ext4.img
echo "-- fls"; fls -r ext4.img
EINODE=$(fls -d ext4.img | sed -n 's/.* \([0-9]*\):.*customers.*/\1/p' | head -1)
echo "-- deleted inode: $EINODE"
if [ -n "$EINODE" ]; then istat ext4.img "$EINODE" | sed -n '1,25p'; echo "-- icat:"; icat ext4.img "$EINODE" | head -3; echo "(end icat)"; fi
echo "-- timeline (fls -m | mactime)"
fls -r -m / ext4.img > body.txt
mactime -b body.txt -d -z UTC | head -12
echo "== verify image hash unchanged by analysis"
sha256sum fat.img ext4.img
