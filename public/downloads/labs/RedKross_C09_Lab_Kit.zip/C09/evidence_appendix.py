"""Generate a forensic report evidence appendix (Course 09 Module 8).

Lists each evidence item with size, SHA-256 and description, so the report
can cite items by ID (E1, E2, ...). Usage: python evidence_appendix.py
Tested: CPython 3.14.4, 2026-11-07.
"""
import hashlib
from pathlib import Path

ITEMS = [  # (file, description) - lab artefacts standing in for case evidence
    ("rk_c09_lab.pcap", "Packet capture, web01 interface, port 80 (lab)"),
    ("rk_c09_net_lab_output.txt", "tshark analysis output incl. carved file hash"),
    ("timeline_output.txt", "Merged UTC timeline (auth.log, access.log, pcap)"),
    ("rk_c09_live_lab_output.txt", "Live-response output (processes, sockets)"),
]


def sha256(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


print(f"{'ID':3} {'Size':>7}  {'SHA-256':64}  Item / description")
for n, (name, desc) in enumerate(ITEMS, 1):
    p = Path(name)
    if not p.exists():
        print(f"E{n:<2} {'-':>7}  {'MISSING':64}  {name}")
        continue
    print(f"E{n:<2} {p.stat().st_size:>7}  {sha256(p)}  {name}\n{'':77}{desc}")
