#!/bin/sh
# Course 09 acquisition and integrity lab (disposable Debian container).
# A 16 MB file stands in for a "suspect device". We image it with dd while
# hashing in one pass, verify, then show that a one-byte change is detected.
set -e
apt-get update -qq >/dev/null && apt-get install -y -qq mtools >/dev/null 2>&1
cd /tmp
dd if=/dev/zero of=suspect.dev bs=1M count=16 status=none
mformat -i suspect.dev -v SUSPECT ::
printf 'FICTIONAL evidence file\n' > e.txt && mcopy -i suspect.dev e.txt ::
echo "== 1. hash source before acquisition"
sha256sum suspect.dev | tee source.sha256
echo "== 2. acquire: dd -> tee -> image file and hash in one pass"
dd if=suspect.dev bs=4M conv=noerror,sync status=none | tee evidence.dd | sha256sum | sed 's/-$/evidence.dd (stream)/'
echo "== 3. verify image file"
sha256sum evidence.dd
ls -l evidence.dd | awk '{print "size", $5, "bytes"}'
echo "== 4. working copy for analysis; verify"
cp evidence.dd working.dd && sha256sum working.dd
echo "== 5. one-byte change in working copy at offset 100000"
printf 'X' | dd of=working.dd bs=1 seek=100000 conv=notrunc status=none
sha256sum working.dd
cmp evidence.dd working.dd || true
echo "== 6. md5 alongside sha256 (legacy compatibility only)"
md5sum evidence.dd
