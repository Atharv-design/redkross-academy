"""Super-timeline builder (Course 09 Modules 6 and 8).

Merges three sources into one UTC timeline:
  auth.log     classic syslog (no year, host clock UTC)  - synthetic
  access.log   web server log with explicit +0000 offset - synthetic
  pcap         HTTP requests from rk_c09_lab.pcap (tshark fields, real capture)
Usage: python timeline.py
Tested: CPython 3.14.4, 2026-11-07.
"""
import re
from datetime import datetime, timezone

YEAR = 2026  # syslog omits the year: documented assumption

AUTH = """Nov  7 05:49:12 web01 sshd[2211]: Accepted publickey for deploy from 172.31.0.20 port 50122 ssh2
Nov  7 05:50:03 web01 sudo:   deploy : TTY=pts/0 ; PWD=/home/deploy ; USER=root ; COMMAND=/usr/bin/cp /var/lib/app/customers.csv /srv/backup/
Nov  7 05:52:30 web01 sshd[2211]: Disconnected from user deploy 172.31.0.20 port 50122"""

ACCESS = """172.31.0.20 - - [07/Nov/2026:05:51:40 +0000] "GET /backup/customers.csv HTTP/1.1" 200 -
172.31.0.20 - - [07/Nov/2026:05:51:40 +0000] "GET /backup/missing.zip HTTP/1.1" 404 -"""

# From rk_c09_net_lab_output.txt (tshark -T fields, frame.time_utc)
PCAP = [("2026-11-07T05:51:40.339854", "GET /backup/customers.csv UA=rk-backup-agent/1.0"),
        ("2026-11-07T05:51:40.965463", "GET /backup/missing.zip UA=curl/8.23.0")]


def events():
    for line in AUTH.splitlines():
        ts = datetime.strptime(f"{YEAR} {line[:15]}", "%Y %b %d %H:%M:%S").replace(tzinfo=timezone.utc)
        yield ts, "auth.log", line[16:].split(": ", 1)[1].strip()[:78]
    for line in ACCESS.splitlines():
        m = re.search(r"\[(.+?)\] \"(.+?)\" (\d+)", line)
        ts = datetime.strptime(m.group(1), "%d/%b/%Y:%H:%M:%S %z")
        yield ts, "access.log", f"{m.group(2)} -> {m.group(3)}"
    for t, desc in PCAP:
        yield datetime.fromisoformat(t).replace(tzinfo=timezone.utc), "pcap", desc


for ts, src, desc in sorted(events()):
    print(f"{ts.strftime('%Y-%m-%dT%H:%M:%S.%f')[:23]}Z  {src:10}  {desc}")
