"""Eradication check: compare a directory against a known-good hash baseline
(Course 09 Module 7).

Usage:
  python baseline_diff.py demo            builds a fictional web root, a
                                          baseline, then simulates attacker
                                          changes and reports differences
  python baseline_diff.py baseline DIR OUT.json
  python baseline_diff.py compare  DIR OUT.json
Tested: CPython 3.14.4, 2026-11-07. Files are synthetic.
"""
import hashlib
import json
import sys
import tempfile
from pathlib import Path


def snapshot(root):
    root = Path(root)
    return {str(p.relative_to(root)).replace(chr(92), "/"):
            hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob("*")) if p.is_file()}


def compare(old, new):
    added = sorted(set(new) - set(old))
    removed = sorted(set(old) - set(new))
    changed = sorted(k for k in set(old) & set(new) if old[k] != new[k])
    return added, removed, changed


def report(added, removed, changed):
    for label, items in (("ADDED", added), ("REMOVED", removed), ("CHANGED", changed)):
        for i in items:
            print(f"{label:8} {i}")
    print(f"summary: {len(added)} added, {len(removed)} removed, {len(changed)} changed")


def demo():
    with tempfile.TemporaryDirectory() as d:
        web = Path(d) / "www"
        (web / "js").mkdir(parents=True)
        (web / "index.html").write_text("<h1>Tamarind Logistics (FICTIONAL)</h1>\n")
        (web / "js" / "app.js").write_text("console.log('track');\n")
        (web / "robots.txt").write_text("User-agent: *\n")
        base = snapshot(web)
        print(f"baseline: {len(base)} files")
        # simulated attacker activity
        (web / "js" / "app.js").write_text("console.log('track');\n/* injected */\n")
        (web / "uploads").mkdir()
        (web / "uploads" / "shell.php").write_text("<?php /* FICTIONAL web shell marker */ ?>\n")
        (web / "robots.txt").unlink()
        report(*compare(base, snapshot(web)))


if __name__ == "__main__":
    if sys.argv[1:] == ["demo"]:
        demo()
    elif len(sys.argv) == 4 and sys.argv[1] == "baseline":
        Path(sys.argv[3]).write_text(json.dumps(snapshot(sys.argv[2]), indent=1))
    elif len(sys.argv) == 4 and sys.argv[1] == "compare":
        report(*compare(json.loads(Path(sys.argv[3]).read_text()), snapshot(sys.argv[2])))
    else:
        print(__doc__)
