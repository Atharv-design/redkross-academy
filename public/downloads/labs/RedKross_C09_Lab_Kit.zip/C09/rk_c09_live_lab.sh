#!/bin/sh
# Course 09 live-response lab (disposable python:3.12-slim container).
# Starts a fictional "suspicious" listener and a masqueraded sleep process,
# then collects process and connection artefacts from /proc - the same
# structures memory-forensics tools reconstruct from RAM images.
python3 -m http.server 8443 --bind 127.0.0.1 >/dev/null 2>&1 &
cp /bin/sleep /tmp/kworker && /tmp/kworker 600 &
sleep 2
echo "== processes from /proc (pid, ppid, comm, exe, cmdline)"
for p in /proc/[0-9]*; do
  pid=${p#/proc/}
  [ -r "$p/stat" ] || continue
  ppid=$(awk '{print $4}' "$p/stat"); comm=$(cat "$p/comm")
  exe=$(readlink "$p/exe" 2>/dev/null); cmd=$(tr '\0' ' ' < "$p/cmdline")
  echo "$pid $ppid $comm exe=$exe cmd=$cmd"
done
echo "== listening TCP sockets from /proc/net/tcp (state 0A = LISTEN)"
awk 'NR>1 && $4=="0A" {print $2, "inode="$10}' /proc/net/tcp
echo "== decode 0100007F:20FB"
python3 -c "import socket,struct;print(socket.inet_ntoa(struct.pack('<I',0x0100007F)), 0x20FB)"
echo "== map socket inode to process"
for fd in /proc/[0-9]*/fd/*; do l=$(readlink "$fd" 2>/dev/null); case "$l" in socket:*) echo "${fd%/fd/*} -> $l";; esac; done
echo "== deleted-but-running check"
rm /tmp/kworker; ls -l /proc/*/exe 2>/dev/null | grep deleted
