"""Course 11 Module 8 lab: first-hour response to a compromised identity and
instance (moto mock - same boto3 calls as real AWS; no real account used).

Steps: (1) inventory the compromised user's keys; (2) deactivate (not delete)
the key; (3) attach an inline deny for sessions issued before now, the
pattern behind the IAM console's "revoke active sessions" action;
(4) quarantine an instance by swapping to an empty security group;
(5) snapshot its volume and tag everything with the case ID.
Run: sh run_lab.sh response_lab.py     Tested 2026-11-07 (boto3 1.43.126, moto 5.2.5)
"""
import json
from datetime import datetime, timezone

import boto3
from moto import mock_aws

CASE = "CASE-C11-0001"

with mock_aws():
    iam, ec2 = boto3.client("iam"), boto3.client("ec2")
    iam.create_user(UserName="old-integration")
    key = iam.create_access_key(UserName="old-integration")["AccessKey"]["AccessKeyId"]

    print("== 1. inventory keys")
    for k in iam.list_access_keys(UserName="old-integration")["AccessKeyMetadata"]:
        print(f"  {k['AccessKeyId'][:4]}...{k['AccessKeyId'][-4:]} status={k['Status']}")

    print("== 2. deactivate key (keep it for evidence and correlation)")
    iam.update_access_key(UserName="old-integration", AccessKeyId=key, Status="Inactive")
    print("  status now:", iam.list_access_keys(UserName="old-integration")
          ["AccessKeyMetadata"][0]["Status"])

    print("== 3. deny sessions issued before now")
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    revoke = {"Version": "2012-10-17", "Statement": [{"Effect": "Deny", "Action": "*",
              "Resource": "*", "Condition": {"DateLessThan": {"aws:TokenIssueTime": now}}}]}
    iam.put_user_policy(UserName="old-integration", PolicyName="ir-revoke-older-sessions",
                        PolicyDocument=json.dumps(revoke))
    print("  inline policies:", iam.list_user_policies(UserName="old-integration")["PolicyNames"])

    print("== 4. quarantine instance")
    vpc = ec2.create_vpc(CidrBlock="10.40.0.0/16")["Vpc"]["VpcId"]
    sub = ec2.create_subnet(VpcId=vpc, CidrBlock="10.40.1.0/24")["Subnet"]["SubnetId"]
    web = ec2.create_security_group(GroupName="tl-web", Description="web", VpcId=vpc)["GroupId"]
    inst = ec2.run_instances(ImageId="ami-12c6146b", MinCount=1, MaxCount=1, SubnetId=sub,
                             SecurityGroupIds=[web])["Instances"][0]["InstanceId"]
    q = ec2.create_security_group(GroupName="ir-quarantine", Description="no rules",
                                  VpcId=vpc)["GroupId"]
    ec2.revoke_security_group_egress(GroupId=q, IpPermissions=[
        {"IpProtocol": "-1", "IpRanges": [{"CidrIp": "0.0.0.0/0"}]}])
    ec2.modify_instance_attribute(InstanceId=inst, Groups=[q])
    sg = ec2.describe_instances(InstanceIds=[inst])["Reservations"][0]["Instances"][0]["SecurityGroups"]
    qg = ec2.describe_security_groups(GroupIds=[q])["SecurityGroups"][0]
    print(f"  instance SGs: {[g['GroupName'] for g in sg]}  quarantine ingress="
          f"{len(qg['IpPermissions'])} egress={len(qg['IpPermissionsEgress'])}")

    print("== 5. snapshot volumes and tag with case ID")
    vols = ec2.describe_volumes(Filters=[{"Name": "attachment.instance-id", "Values": [inst]}])["Volumes"]
    for v in vols:
        snap = ec2.create_snapshot(VolumeId=v["VolumeId"], Description=f"{CASE} evidence",
                                   TagSpecifications=[{"ResourceType": "snapshot", "Tags": [
                                       {"Key": "case", "Value": CASE}]}])
        print(f"  {v['VolumeId']} -> {snap['SnapshotId']} state={snap['State']}")
    ec2.create_tags(Resources=[inst], Tags=[{"Key": "case", "Value": CASE},
                                            {"Key": "ir-status", "Value": "quarantined"}])
    tags = ec2.describe_tags(Filters=[{"Name": "resource-id", "Values": [inst]}])["Tags"]
    print("  instance tags:", sorted((t["Key"], t["Value"]) for t in tags))
