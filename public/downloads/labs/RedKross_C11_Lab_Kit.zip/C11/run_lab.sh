#!/bin/sh
# Course 11 lab runner: executes a lab script inside python:3.12-slim with
# boto3 + moto (local AWS mock - no real AWS account or network calls to AWS).
# Usage (Git bash / Linux): sh run_lab.sh <script.py>
export MSYS_NO_PATHCONV=1
HERE="$(pwd -W 2>/dev/null || pwd)"
docker run --rm -v "$HERE":/lab -w /lab -e AWS_ACCESS_KEY_ID=testing \
  -e AWS_SECRET_ACCESS_KEY=testing -e AWS_DEFAULT_REGION=ap-south-1 python:3.12-slim \
  sh -c "pip install -q --root-user-action=ignore boto3 'moto[s3,iam,ec2,sts,kms,cloudtrail]' >/dev/null 2>&1 && python -c 'import boto3,moto;print(\"boto3\",boto3.__version__,\"moto\",moto.__version__)' && python $1"
