"""CT1 model solution: per-identity timeline and risk summary over the
synthetic CloudTrail-format records of cloudtrail_lab.py.
Run from LAB_ASSETS/C11: python solutions/ct1_identity_timeline.py
Tested: CPython 3.14.4, 2026-11-08 (reads synthetic records only)."""
import contextlib
import io
import os
import sys
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
with contextlib.redirect_stdout(io.StringIO()):
    import cloudtrail_lab as ct  # noqa: E402  (module prints its own report on import)

HIGH = {"StopLogging", "DeleteTrail", "CreateAccessKey", "PutBucketPolicy", "ConsoleLogin"}
by_user = defaultdict(list)
for r in ct.RECORDS:
    by_user[r["userIdentity"]["userName"]].append(r)
for user, recs in sorted(by_user.items()):
    recs.sort(key=lambda r: r["eventTime"])
    ips = sorted({r["sourceIPAddress"] for r in recs})
    denied = sum(1 for r in recs if r.get("errorCode") == "AccessDenied")
    hits = sorted({f.__name__ for r in recs for f in ct.RULES if f(r)})
    print(f"{user}: {len(recs)} events {recs[0]['eventTime']} -> {recs[-1]['eventTime']} "
          f"ips={ips} denied={denied}")
    print(f"   detections={hits or '-'}")
    for r in recs:
        if r["eventName"] in HIGH or r.get("errorCode"):
            print(f"   {r['eventTime']} {r['eventSource'].split('.')[0]}:{r['eventName']}"
                  f"{' [' + r['errorCode'] + ']' if r.get('errorCode') else ''}")
    verdict = "INCIDENT" if len(hits) >= 2 else ("REVIEW" if hits or denied else "normal")
    print(f"   verdict: {verdict}")
