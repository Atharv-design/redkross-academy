"""CT2 model solution: offline IAM policy linter (no AWS calls).
Flags: Allow with Action "*"; Allow on Resource "*" for sensitive actions;
iam:PassRole on "*" or without iam:PassedToService; trust policies with
Principal "*" or a third-party account without sts:ExternalId; MFA deny
statements using Bool instead of BoolIfExists.
Run from LAB_ASSETS/C11: python solutions/ct2_policy_lint.py solutions/policies.json
Tested: CPython 3.14.4, 2026-11-08."""
import json
import sys

SENSITIVE = {"iam:passrole", "iam:createaccesskey", "iam:attachuserpolicy", "iam:putuserpolicy",
             "iam:createpolicyversion", "sts:assumerole"}


def as_list(x):
    return x if isinstance(x, list) else [x]


def lint(name, pol):
    out = []
    for i, st in enumerate(pol["Statement"]):
        acts = [a.lower() for a in as_list(st.get("Action", []))]
        res = as_list(st.get("Resource", []))
        cond = st.get("Condition", {})
        if st["Effect"] == "Allow" and "*" in acts:
            out.append(f"HIGH  stmt {i}: Allow Action '*'")
        for a in acts:
            if a in SENSITIVE and st["Effect"] == "Allow" and "Principal" not in st:
                if "*" in res:
                    out.append(f"HIGH  stmt {i}: {a} on Resource '*'")
                if a == "iam:passrole" and "iam:PassedToService" not in json.dumps(cond):
                    out.append(f"MED   stmt {i}: iam:PassRole without iam:PassedToService")
        p = st.get("Principal")
        if p is not None:
            aws = as_list(p.get("AWS", [])) if isinstance(p, dict) else as_list(p)
            if "*" in aws:
                out.append(f"HIGH  stmt {i}: trust policy allows any principal")
            elif "sts:ExternalId" not in json.dumps(cond):
                out.append(f"MED   stmt {i}: cross-account trust without sts:ExternalId")
        if st["Effect"] == "Deny" and "aws:MultiFactorAuthPresent" in json.dumps(cond.get("Bool", {})):
            out.append(f"MED   stmt {i}: MFA deny uses Bool (access keys escape); use BoolIfExists")
    return out


pols = json.load(open(sys.argv[1]))
total = 0
for name, pol in pols.items():
    f = lint(name, pol)
    total += len(f)
    print(f"{name:24s} {'OK' if not f else ''}")
    for x in f:
        print(f"    {x}")
print(f"summary: {total} findings across {len(pols)} documents")
