"""Course 11 Module 4 lab: S3 exposure, encryption, versioning and KMS (moto mock).

Creates two buckets - one deliberately misconfigured with a public-read
bucket policy - audits them with read-only boto3 calls, remediates, and
verifies. Also shows that an object deleted from a versioned bucket can be
recovered.
Run: sh run_lab.sh data_lab.py     Tested 2026-11-07 (boto3 1.43.126, moto 5.2.5)
Note: moto emulates API behaviour; it does not enforce every AWS default (for
example, real new buckets have Block Public Access on and SSE-S3 by default).
"""
import json

import boto3
from botocore.exceptions import ClientError
from moto import mock_aws

REGION = "ap-south-1"


def audit(s3, b):
    out = {}
    try:
        cfg = s3.get_public_access_block(Bucket=b)["PublicAccessBlockConfiguration"]
        out["block_public"] = all(cfg.values())
    except ClientError:
        out["block_public"] = "not set"
    try:
        pol = json.loads(s3.get_bucket_policy(Bucket=b)["Policy"])
        out["public_policy"] = any(st.get("Principal") in ("*", {"AWS": "*"}) and st["Effect"] == "Allow"
                                   for st in pol["Statement"])
    except ClientError:
        out["public_policy"] = False
    try:
        rule = s3.get_bucket_encryption(Bucket=b)["ServerSideEncryptionConfiguration"]["Rules"][0]
        out["encryption"] = rule["ApplyServerSideEncryptionByDefault"]["SSEAlgorithm"]
    except ClientError:
        out["encryption"] = "none reported"
    out["versioning"] = s3.get_bucket_versioning(Bucket=b).get("Status", "Disabled")
    return out


with mock_aws():
    s3 = boto3.client("s3", region_name=REGION)
    kms = boto3.client("kms", region_name=REGION)
    loc = {"LocationConstraint": REGION}
    s3.create_bucket(Bucket="tl-public-assets", CreateBucketConfiguration=loc)
    s3.create_bucket(Bucket="tl-customer-exports", CreateBucketConfiguration=loc)
    s3.put_bucket_policy(Bucket="tl-customer-exports", Policy=json.dumps({
        "Version": "2012-10-17", "Statement": [{"Sid": "TempShare", "Effect": "Allow",
        "Principal": "*", "Action": "s3:GetObject",
        "Resource": "arn:aws:s3:::tl-customer-exports/*"}]}))

    print("== audit (before)")
    for b in ("tl-public-assets", "tl-customer-exports"):
        print(f"  {b:20} {audit(s3, b)}")

    print("== remediate tl-customer-exports")
    key = kms.create_key(Description="tl-customer-exports CMK")["KeyMetadata"]
    kms.enable_key_rotation(KeyId=key["KeyId"])
    s3.delete_bucket_policy(Bucket="tl-customer-exports")
    s3.put_public_access_block(Bucket="tl-customer-exports", PublicAccessBlockConfiguration={
        "BlockPublicAcls": True, "IgnorePublicAcls": True,
        "BlockPublicPolicy": True, "RestrictPublicBuckets": True})
    s3.put_bucket_encryption(Bucket="tl-customer-exports", ServerSideEncryptionConfiguration={
        "Rules": [{"ApplyServerSideEncryptionByDefault": {
            "SSEAlgorithm": "aws:kms", "KMSMasterKeyID": key["Arn"]}, "BucketKeyEnabled": True}]})
    s3.put_bucket_versioning(Bucket="tl-customer-exports", VersioningConfiguration={"Status": "Enabled"})
    print(f"  KMS key rotation enabled: {kms.get_key_rotation_status(KeyId=key['KeyId'])['KeyRotationEnabled']}")
    print("== audit (after)")
    print(f"  tl-customer-exports  {audit(s3, 'tl-customer-exports')}")

    print("== versioning: recover a deleted object")
    s3.put_object(Bucket="tl-customer-exports", Key="export.csv", Body=b"id,name\n1,FICTIONAL\n")
    s3.delete_object(Bucket="tl-customer-exports", Key="export.csv")
    try:
        s3.get_object(Bucket="tl-customer-exports", Key="export.csv")
    except ClientError as e:
        print("  get after delete:", e.response["Error"]["Code"])
    vers = s3.list_object_versions(Bucket="tl-customer-exports", Prefix="export.csv")
    marker = vers["DeleteMarkers"][0]["VersionId"]
    print(f"  versions={len(vers['Versions'])} delete_markers={len(vers['DeleteMarkers'])}")
    s3.delete_object(Bucket="tl-customer-exports", Key="export.csv", VersionId=marker)
    body = s3.get_object(Bucket="tl-customer-exports", Key="export.csv")["Body"].read()
    print("  after removing delete marker:", body)
