# Course 11 Module 7 - deliberately bad config for secret scanning (FICTIONAL).
# The key below is AWS's published documentation example key, not a real key.
AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE"
AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
DB_PASSWORD = "ChangeMe123!"
