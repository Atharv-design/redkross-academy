# Course 11 Module 6 - remediated version of ../iac/main.tf (key findings only).
variable "db_password" {
  type      = string
  sensitive = true # supplied from a secrets manager at deploy time, never committed
}

resource "aws_s3_bucket" "exports" {
  bucket = "tl-customer-exports"
}

resource "aws_s3_bucket_public_access_block" "exports" {
  bucket                  = aws_s3_bucket.exports.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_versioning" "exports" {
  bucket = aws_s3_bucket.exports.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_security_group" "web" {
  name        = "tl-web"
  description = "web tier"
  ingress {
    description = "ssh from admin bastion subnet only"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["10.40.9.0/28"]
  }
}

resource "aws_db_instance" "orders" {
  identifier                          = "tl-orders"
  engine                              = "postgres"
  instance_class                      = "db.t3.micro"
  allocated_storage                   = 20
  username                            = "tladmin"
  password                            = var.db_password
  publicly_accessible                 = false
  storage_encrypted                   = true
  deletion_protection                 = true
  iam_database_authentication_enabled = true
  skip_final_snapshot                 = false
}

resource "azurerm_storage_account" "logs" {
  name                            = "tllogsfictional"
  resource_group_name             = "rg-tl"
  location                        = "centralindia"
  account_tier                    = "Standard"
  account_replication_type        = "GRS"
  min_tls_version                 = "TLS1_2"
  allow_nested_items_to_be_public = false
  public_network_access_enabled   = false
}

resource "azurerm_network_security_rule" "rdp" {
  name                        = "allow-rdp-bastion"
  priority                    = 100
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "3389"
  source_address_prefix       = "10.50.9.0/28"
  destination_address_prefix  = "*"
  resource_group_name         = "rg-tl"
  network_security_group_name = "nsg-tl"
}
