"""Course 11 Module 5 lab: detections over CloudTrail-format records.

The records are SYNTHETIC (fictional account 111122223333, documentation IP
ranges; the AccessDenied calls represent Organizations API calls blocked by a
service control policy in this member account) but use field names from the CloudTrail record format (eventTime,
eventSource, eventName, userIdentity, sourceIPAddress, errorCode,
additionalEventData.MFAUsed, requestParameters).
Run: python cloudtrail_lab.py     Tested: CPython 3.14.4, 2026-11-07
"""
import json
from collections import Counter

ACCT = "111122223333"


def ev(t, src, name, user, ip, **kw):
    r = {"eventVersion": "1.10", "eventTime": t, "eventSource": src, "eventName": name,
         "awsRegion": "ap-south-1", "sourceIPAddress": ip,
         "userIdentity": {"type": "IAMUser", "userName": user,
                          "arn": f"arn:aws:iam::{ACCT}:user/{user}", "accountId": ACCT}}
    r.update(kw)
    return r


RECORDS = [
    ev("2026-11-03T04:10:02Z", "signin.amazonaws.com", "ConsoleLogin", "asha", "198.51.100.23",
       responseElements={"ConsoleLogin": "Success"}, additionalEventData={"MFAUsed": "Yes"}),
    ev("2026-11-03T06:41:10Z", "signin.amazonaws.com", "ConsoleLogin", "old-integration",
       "203.0.113.77", responseElements={"ConsoleLogin": "Success"},
       additionalEventData={"MFAUsed": "No"}),
] + [
    ev(f"2026-11-03T06:4{2 + i // 6}:{(i * 9) % 60:02d}Z", "s3.amazonaws.com", "ListBuckets",
       "old-integration", "203.0.113.77") for i in range(3)
] + [
    ev(f"2026-11-03T06:44:{i:02d}Z", "organizations.amazonaws.com", "ListAccounts",
       "old-integration", "203.0.113.77", errorCode="AccessDenied") for i in range(0, 50, 7)
] + [
    ev("2026-11-03T06:46:30Z", "iam.amazonaws.com", "CreateAccessKey", "old-integration",
       "203.0.113.77", requestParameters={"userName": "ci-bot"}),
    ev("2026-11-03T06:48:05Z", "s3.amazonaws.com", "PutBucketPolicy", "old-integration",
       "203.0.113.77", requestParameters={"bucketName": "tl-customer-exports", "bucketPolicy": {
           "Statement": [{"Effect": "Allow", "Principal": "*", "Action": "s3:GetObject"}]}}),
    ev("2026-11-03T06:52:40Z", "cloudtrail.amazonaws.com", "StopLogging", "old-integration",
       "203.0.113.77", requestParameters={"name": "tl-org-trail"}),
    ev("2026-11-03T07:15:00Z", "ec2.amazonaws.com", "DescribeInstances", "ci-bot", "198.51.100.40"),
]

RULES = []


def rule(f):
    RULES.append(f)
    return f


@rule
def console_login_without_mfa(r):
    return r["eventName"] == "ConsoleLogin" and r.get("additionalEventData", {}).get("MFAUsed") == "No"


@rule
def access_key_for_other_user(r):
    return r["eventName"] == "CreateAccessKey" and \
        r.get("requestParameters", {}).get("userName") not in (None, r["userIdentity"]["userName"])


@rule
def public_bucket_policy(r):
    pol = r.get("requestParameters", {}).get("bucketPolicy", {})
    return r["eventName"] == "PutBucketPolicy" and any(
        s.get("Principal") in ("*", {"AWS": "*"}) and s.get("Effect") == "Allow"
        for s in pol.get("Statement", []))


@rule
def logging_disabled(r):
    return r["eventName"] in ("StopLogging", "DeleteTrail", "UpdateTrail", "PutEventSelectors")


print(f"records: {len(RECORDS)}  (format sample: {json.dumps(RECORDS[1])[:110]}...)")
print("== single-event detections")
for r in RECORDS:
    for f in RULES:
        if f(r):
            print(f"  {r['eventTime']} {f.__name__:28} user={r['userIdentity']['userName']} "
                  f"ip={r['sourceIPAddress']}")
print("== aggregate: AccessDenied bursts (>=5 per user per source IP)")
denied = Counter((r["userIdentity"]["userName"], r["sourceIPAddress"])
                 for r in RECORDS if r.get("errorCode") == "AccessDenied")
for (u, ip), n in denied.items():
    if n >= 5:
        print(f"  {u} from {ip}: {n} AccessDenied -> enumeration / permission probing")
print("== new source IP per user (baseline: first IP seen)")
first = {}
for r in sorted(RECORDS, key=lambda x: x["eventTime"]):
    u, ip = r["userIdentity"]["userName"], r["sourceIPAddress"]
    first.setdefault(u, ip)
print("  ", first)
