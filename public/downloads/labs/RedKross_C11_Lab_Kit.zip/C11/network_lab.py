"""Course 11 Module 3 lab: VPC layout and security-group review (moto mock).

Builds a small VPC (public + private subnet, internet gateway, NAT-less
private route table, two security groups), then audits it with read-only
boto3 calls: which subnets are public (route 0.0.0.0/0 -> igw-*) and which
security-group rules expose admin ports to the internet.
Run: sh run_lab.sh network_lab.py     Tested 2026-11-07 (boto3 1.43.126, moto 5.2.5)
"""
import boto3
from moto import mock_aws

ADMIN_PORTS = {22: "SSH", 3389: "RDP", 3306: "MySQL", 5432: "PostgreSQL"}

with mock_aws():
    ec2 = boto3.client("ec2")
    vpc = ec2.create_vpc(CidrBlock="10.40.0.0/16")["Vpc"]["VpcId"]
    pub = ec2.create_subnet(VpcId=vpc, CidrBlock="10.40.1.0/24")["Subnet"]["SubnetId"]
    prv = ec2.create_subnet(VpcId=vpc, CidrBlock="10.40.2.0/24")["Subnet"]["SubnetId"]
    igw = ec2.create_internet_gateway()["InternetGateway"]["InternetGatewayId"]
    ec2.attach_internet_gateway(InternetGatewayId=igw, VpcId=vpc)
    rt_pub = ec2.create_route_table(VpcId=vpc)["RouteTable"]["RouteTableId"]
    ec2.create_route(RouteTableId=rt_pub, DestinationCidrBlock="0.0.0.0/0", GatewayId=igw)
    ec2.associate_route_table(RouteTableId=rt_pub, SubnetId=pub)
    rt_prv = ec2.create_route_table(VpcId=vpc)["RouteTable"]["RouteTableId"]
    ec2.associate_route_table(RouteTableId=rt_prv, SubnetId=prv)

    web = ec2.create_security_group(GroupName="tl-web", Description="web tier", VpcId=vpc)["GroupId"]
    ec2.authorize_security_group_ingress(GroupId=web, IpPermissions=[
        {"IpProtocol": "tcp", "FromPort": 443, "ToPort": 443, "IpRanges": [{"CidrIp": "0.0.0.0/0"}]},
        {"IpProtocol": "tcp", "FromPort": 22, "ToPort": 22, "IpRanges": [{"CidrIp": "0.0.0.0/0"}]}])
    db = ec2.create_security_group(GroupName="tl-db", Description="db tier", VpcId=vpc)["GroupId"]
    ec2.authorize_security_group_ingress(GroupId=db, IpPermissions=[
        {"IpProtocol": "tcp", "FromPort": 5432, "ToPort": 5432,
         "UserIdGroupPairs": [{"GroupId": web}]}])

    print("== subnets")
    tables = ec2.describe_route_tables(Filters=[{"Name": "vpc-id", "Values": [vpc]}])["RouteTables"]
    for t in tables:
        public = any(r.get("DestinationCidrBlock") == "0.0.0.0/0" and
                     r.get("GatewayId", "").startswith("igw-") for r in t["Routes"])
        for a in t.get("Associations", []):
            if a.get("SubnetId"):
                cidr = ec2.describe_subnets(SubnetIds=[a["SubnetId"]])["Subnets"][0]["CidrBlock"]
                print(f"  {cidr:14} {'PUBLIC (0.0.0.0/0 -> igw)' if public else 'private (no igw route)'}")

    print("== security group ingress review")
    for g in ec2.describe_security_groups(Filters=[{"Name": "vpc-id", "Values": [vpc]}])["SecurityGroups"]:
        for p in g["IpPermissions"]:
            port = p.get("FromPort")
            srcs = [r["CidrIp"] for r in p.get("IpRanges", [])] + \
                   [pair["GroupId"] for pair in p.get("UserIdGroupPairs", [])]
            for s in srcs:
                verdict = "ok"
                if s == "0.0.0.0/0" and port in ADMIN_PORTS:
                    verdict = f"FINDING: {ADMIN_PORTS[port]} open to the internet"
                elif s == "0.0.0.0/0":
                    verdict = "internet-facing (expected for 443 on web tier?)"
                elif s.startswith("sg-"):
                    verdict = "source is a security group (least privilege)"
                print(f"  {g['GroupName']:7} tcp/{port:<5} from {s if not s.startswith('sg-') else 'sg:tl-web'}"
                      f"  -> {verdict}")

    print("== remediate: revoke SSH from 0.0.0.0/0, verify")
    ec2.revoke_security_group_ingress(GroupId=web, IpPermissions=[
        {"IpProtocol": "tcp", "FromPort": 22, "ToPort": 22, "IpRanges": [{"CidrIp": "0.0.0.0/0"}]}])
    left = [(p["FromPort"], [r["CidrIp"] for r in p["IpRanges"]])
            for p in ec2.describe_security_groups(GroupIds=[web])["SecurityGroups"][0]["IpPermissions"]]
    print("  tl-web ingress now:", left)
