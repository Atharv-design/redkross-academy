"""Course 11 Module 2 lab: IAM policy logic and risky-policy review.

Part A - a small teaching evaluator that follows the core of AWS's documented
identity-policy logic: explicit Deny wins, then any Allow, otherwise implicit
deny. Supports wildcards in Action/Resource and two condition operators
(Bool, IpAddress). It is NOT the full AWS engine (no SCPs, boundaries,
resource policies, NotAction, etc.).
Part B - creates IAM users/roles/policies in moto (local mock) and flags
risky permissions with boto3 calls that work the same against real AWS.
Run: sh run_lab.sh iam_lab.py      Tested 2026-11-07 (boto3 1.43.126, moto 5.2.5)
"""
import fnmatch
import ipaddress
import json

import boto3
from moto import mock_aws


def matches(patterns, value):
    pats = patterns if isinstance(patterns, list) else [patterns]
    return any(fnmatch.fnmatchcase(value.lower(), p.lower()) for p in pats)


def cond_ok(cond, ctx):
    for op, kv in (cond or {}).items():
        for key, want in kv.items():
            have = ctx.get(key)
            if op == "Bool" and str(have).lower() != str(want).lower():
                return False  # absent key never matches Bool
            if op == "BoolIfExists" and have is not None and str(have).lower() != str(want).lower():
                return False  # absent key counts as a match
            if op == "IpAddress" and (have is None or not any(
                    ipaddress.ip_address(have) in ipaddress.ip_network(w)
                    for w in (want if isinstance(want, list) else [want]))):
                return False
    return True


def evaluate(policies, action, resource, ctx):
    allowed = False
    for pol in policies:
        for st in pol["Statement"]:
            if matches(st["Action"], action) and matches(st["Resource"], resource) \
                    and cond_ok(st.get("Condition"), ctx):
                if st["Effect"] == "Deny":
                    return "DENY (explicit)"
                allowed = True
    return "ALLOW" if allowed else "DENY (implicit)"


READ_REPORTS = {"Version": "2012-10-17", "Statement": [
    {"Effect": "Allow", "Action": ["s3:GetObject", "s3:ListBucket"],
     "Resource": ["arn:aws:s3:::tl-reports", "arn:aws:s3:::tl-reports/*"]}]}
REQUIRE_MFA = {"Version": "2012-10-17", "Statement": [
    {"Effect": "Deny", "Action": "*", "Resource": "*",
     "Condition": {"Bool": {"aws:MultiFactorAuthPresent": "false"}}}]}
REQUIRE_MFA_IFEXISTS = {"Version": "2012-10-17", "Statement": [
    {"Effect": "Deny", "Action": "*", "Resource": "*",
     "Condition": {"BoolIfExists": {"aws:MultiFactorAuthPresent": "false"}}}]}
OFFICE_ONLY_DELETE = {"Version": "2012-10-17", "Statement": [
    {"Effect": "Allow", "Action": "s3:DeleteObject", "Resource": "arn:aws:s3:::tl-reports/*",
     "Condition": {"IpAddress": {"aws:SourceIp": "198.51.100.0/24"}}}]}

print("== Part A: evaluation")
cases = [
    ("read, MFA", [READ_REPORTS, REQUIRE_MFA], "s3:GetObject", "arn:aws:s3:::tl-reports/q3.pdf",
     {"aws:MultiFactorAuthPresent": "true"}),
    ("read, no MFA", [READ_REPORTS, REQUIRE_MFA], "s3:GetObject", "arn:aws:s3:::tl-reports/q3.pdf",
     {"aws:MultiFactorAuthPresent": "false"}),
    ("read, access key", [READ_REPORTS, REQUIRE_MFA], "s3:GetObject",
     "arn:aws:s3:::tl-reports/q3.pdf", {}),
    ("read, key, IfExists", [READ_REPORTS, REQUIRE_MFA_IFEXISTS], "s3:GetObject",
     "arn:aws:s3:::tl-reports/q3.pdf", {}),
    ("put, MFA",[READ_REPORTS, REQUIRE_MFA], "s3:PutObject", "arn:aws:s3:::tl-reports/x",
     {"aws:MultiFactorAuthPresent": "true"}),
    ("other bucket", [READ_REPORTS], "s3:GetObject", "arn:aws:s3:::tl-payroll/p.csv", {}),
    ("delete from office", [OFFICE_ONLY_DELETE], "s3:DeleteObject", "arn:aws:s3:::tl-reports/x",
     {"aws:SourceIp": "198.51.100.23"}),
    ("delete from cafe", [OFFICE_ONLY_DELETE], "s3:DeleteObject", "arn:aws:s3:::tl-reports/x",
     {"aws:SourceIp": "203.0.113.50"}),
]
for name, pols, act, res, ctx in cases:
    print(f"  {name:20} {act:16} -> {evaluate(pols, act, res, ctx)}")

RISKY = {"iam:PassRole", "iam:CreateAccessKey", "iam:AttachUserPolicy", "iam:PutUserPolicy",
         "iam:CreatePolicyVersion", "sts:AssumeRole", "*"}

print("== Part B: review policies in the (mock) account")
with mock_aws():
    iam = boto3.client("iam")
    admin_like = {"Version": "2012-10-17", "Statement": [
        {"Effect": "Allow", "Action": "*", "Resource": "*"}]}
    deployer = {"Version": "2012-10-17", "Statement": [
        {"Effect": "Allow", "Action": ["ec2:RunInstances", "iam:PassRole"], "Resource": "*"}]}
    for name, doc in (("tl-read-reports", READ_REPORTS), ("tl-legacy-full", admin_like),
                      ("tl-ci-deployer", deployer)):
        iam.create_policy(PolicyName=name, PolicyDocument=json.dumps(doc))
    acct = boto3.client("sts").get_caller_identity()["Account"]
    for user, pol in (("asha", "tl-read-reports"), ("old-integration", "tl-legacy-full"),
                      ("ci-bot", "tl-ci-deployer")):
        iam.create_user(UserName=user)
        iam.attach_user_policy(UserName=user, PolicyArn=f"arn:aws:iam::{acct}:policy/{pol}")
    iam.create_access_key(UserName="old-integration")
    trust = {"Version": "2012-10-17", "Statement": [{"Effect": "Allow",
             "Principal": {"AWS": "*"}, "Action": "sts:AssumeRole"}]}
    iam.create_role(RoleName="tl-vendor-access", AssumeRolePolicyDocument=json.dumps(trust))

    for u in iam.list_users()["Users"]:
        name = u["UserName"]
        keys = len(iam.list_access_keys(UserName=name)["AccessKeyMetadata"])
        mfa = len(iam.list_mfa_devices(UserName=name)["MFADevices"])
        for ap in iam.list_attached_user_policies(UserName=name)["AttachedPolicies"]:
            p = iam.get_policy(PolicyArn=ap["PolicyArn"])["Policy"]
            doc = iam.get_policy_version(PolicyArn=ap["PolicyArn"],
                                         VersionId=p["DefaultVersionId"])["PolicyVersion"]["Document"]
            if isinstance(doc, str):
                doc = json.loads(doc)
            acts = set()
            for st in doc["Statement"]:
                if st["Effect"] == "Allow":
                    acts |= set(st["Action"] if isinstance(st["Action"], list) else [st["Action"]])
            flags = sorted(acts & RISKY)
            print(f"  user={name:16} policy={ap['PolicyName']:16} keys={keys} mfa={mfa} "
                  f"risky={flags or '-'}")
    for r in iam.list_roles()["Roles"]:
        doc = r["AssumeRolePolicyDocument"]
        doc = json.loads(doc) if isinstance(doc, str) else doc
        for st in doc["Statement"]:
            if st.get("Principal", {}).get("AWS") == "*":
                print(f"  role={r['RoleName']} trust policy allows ANY AWS principal "
                      f"(no ExternalId/Condition) -> confused-deputy / takeover risk")
