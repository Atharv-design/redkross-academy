# FICTIONAL key in AWS format (random, never issued) for scanner testing
AWS_ACCESS_KEY_ID = "AKIA2E0A8F3B244C9986"
aws_secret_access_key = "Zq3vT8xP1mR6yL0cW4nB7sK9dF2hJ5gA8eU1iO3t"
