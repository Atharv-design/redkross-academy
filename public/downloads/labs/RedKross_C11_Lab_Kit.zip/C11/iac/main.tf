# Course 11 Module 6 - deliberately weak Terraform for posture scanning.
# NOT for deployment. Fictional names. Scanned offline with checkov.
resource "aws_s3_bucket" "exports" {
  bucket = "tl-customer-exports"
}

resource "aws_security_group" "web" {
  name        = "tl-web"
  description = "web tier"
  ingress {
    description = "ssh from anywhere"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_db_instance" "orders" {
  identifier          = "tl-orders"
  engine              = "postgres"
  instance_class      = "db.t3.micro"
  allocated_storage   = 20
  username            = "tladmin"
  password            = "ChangeMe123!"
  publicly_accessible = true
  storage_encrypted   = false
  skip_final_snapshot = true
}

resource "azurerm_storage_account" "logs" {
  name                            = "tllogsfictional"
  resource_group_name             = "rg-tl"
  location                        = "centralindia"
  account_tier                    = "Standard"
  account_replication_type        = "LRS"
  min_tls_version                 = "TLS1_0"
  allow_nested_items_to_be_public = true
}

resource "azurerm_network_security_rule" "rdp" {
  name                        = "allow-rdp-any"
  priority                    = 100
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "3389"
  source_address_prefix       = "*"
  destination_address_prefix  = "*"
  resource_group_name         = "rg-tl"
  network_security_group_name = "nsg-tl"
}
