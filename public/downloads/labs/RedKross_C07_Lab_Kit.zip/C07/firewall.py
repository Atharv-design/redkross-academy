#!/usr/bin/env python3
"""
firewall.py - offline firewall policy evaluator and linter (Course 07).

A DEFENSIVE, entirely offline tool. It reads a declarative firewall ruleset
(data/rk_firewall.json) for the fictional "Himalaya Retail" network and does
two things:
  1. EVALUATE: given a flow (src zone, dst zone, protocol, destination port),
     report which rule decides it under first-match semantics.
  2. LINT: check the ruleset against firewall best practice (NIST SP 800-41r1):
     - an explicit default-deny must end the policy
     - no "any/any allow" rules
     - no rule shadowed (made unreachable) by an earlier broader rule
     - egress (outbound) filtering should exist, not just ingress
     - flag overly broad destination port ranges

It makes NO network connections and scans nothing. It reasons about a policy
document you own. Use it to review and harden a design, never to probe a live
system.

Tested: CPython 3.14.4, Windows 11, standard library only, 2026-11-08.
"""
import argparse
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))


def load_rules(path):
    return json.load(open(path))["rules"]


def match(rule, src, dst, proto, dport):
    """Does this rule match the flow? 'any' matches anything."""
    def ok(field, value):
        return field == "any" or field == value
    if not (ok(rule["src"], src) and ok(rule["dst"], dst)
            and ok(rule["proto"], proto)):
        return False
    ports = rule["dport"]
    if ports == "any":
        return True
    # ports is [lo, hi] inclusive
    return ports[0] <= dport <= ports[1]


def evaluate(rules, src, dst, proto, dport):
    for i, r in enumerate(rules):
        if match(r, src, dst, proto, dport):
            return i, r
    return None, None


def lint(rules):
    findings = []
    # 1. explicit default-deny at the end
    last = rules[-1] if rules else None
    if not last or last["action"] != "deny" or not all(
            last[f] == "any" for f in ("src", "dst", "proto")) or last["dport"] != "any":
        findings.append(("HIGH", "no explicit default-deny rule ends the policy",
                         "Add a final 'deny any any any any' so anything not "
                         "explicitly allowed is denied (NIST SP 800-41r1)."))
    # 2. any/any allow rules
    for i, r in enumerate(rules):
        if r["action"] == "allow" and r["src"] == "any" and r["dst"] == "any" \
                and r["proto"] == "any" and r["dport"] == "any":
            findings.append(("HIGH", "rule %d is an allow-any-any (permit all)" % i,
                             "Remove or tightly scope; allow only required flows."))
    # 3. shadowed rules (an earlier rule fully covers a later one's matches)
    for j in range(len(rules)):
        for i in range(j):
            if covers(rules[i], rules[j]):
                findings.append(("MEDIUM",
                                 "rule %d is shadowed by earlier rule %d" % (j, i),
                                 "Reorder or remove; shadowed rules never fire "
                                 "and hide intent."))
                break
    # 4. egress filtering present?
    has_egress = any(r["src"] in ("app", "db", "user", "dmz", "mgmt")
                     and r["dst"] in ("internet",) and r["action"] in ("allow", "deny")
                     for r in rules)
    if not has_egress:
        findings.append(("MEDIUM", "no outbound (egress) rules found",
                         "Filter egress too; restrict what internal zones may "
                         "reach on the internet."))
    # 5. broad destination port ranges on allow rules
    for i, r in enumerate(rules):
        if r["action"] == "allow" and isinstance(r["dport"], list):
            lo, hi = r["dport"]
            if hi - lo > 1024:
                findings.append(("LOW",
                                 "rule %d allows a wide port range %d-%d" % (i, lo, hi),
                                 "Narrow to the specific service ports needed."))
    return findings


def covers(a, b):
    """Rule a 'covers' rule b if every flow matching b also matches a and a
    comes first (so b can never fire). Same action required to call it shadow."""
    if a["action"] != b["action"]:
        return False

    def field_covers(fa, fb):
        return fa == "any" or fa == fb

    if not (field_covers(a["src"], b["src"]) and field_covers(a["dst"], b["dst"])
            and field_covers(a["proto"], b["proto"])):
        return False
    if a["dport"] == "any":
        return True
    if b["dport"] == "any":
        return False
    return a["dport"][0] <= b["dport"][0] and b["dport"][1] <= a["dport"][1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rules", default=os.path.join(HERE, "data", "rk_firewall.json"))
    ap.add_argument("--eval", nargs=4, metavar=("SRC", "DST", "PROTO", "DPORT"),
                    help="evaluate a flow, e.g. --eval user db tcp 5432")
    ap.add_argument("--lint", action="store_true")
    args = ap.parse_args()
    rules = load_rules(args.rules)

    if args.eval:
        src, dst, proto, dport = args.eval
        i, r = evaluate(rules, src, dst, proto, int(dport))
        if r is None:
            print("no rule matched (implicit deny) for %s->%s %s/%s"
                  % (src, dst, proto, dport))
        else:
            print("flow %s->%s %s/%s : rule %d -> %s (%s)"
                  % (src, dst, proto, dport, i, r["action"].upper(),
                     r.get("comment", "")))
        return

    # default: lint
    findings = lint(rules)
    print("Firewall policy lint: %s (%d rules)" % (args.rules, len(rules)))
    if not findings:
        print("  no issues found.")
    for sev, title, fix in findings:
        print("  [%-6s] %s" % (sev, title))
        print("           fix: %s" % fix)
    highs = sum(1 for s, _, _ in findings if s == "HIGH")
    print("\n%d findings (%d HIGH). Exit nonzero if any HIGH." % (len(findings), highs))
    raise SystemExit(1 if highs else 0)


if __name__ == "__main__":
    main()
