#!/usr/bin/env python3
"""
segmentation.py - validate network flows against a zero-trust segmentation
policy (Course 07). DEFENSIVE, entirely offline.

A segmentation policy says which zone-to-zone flows are permitted; everything
else is denied by default (zero trust, NIST SP 800-207). This tool loads the
allowed-flow matrix (data/rk_segmentation.json) and a list of observed/intended
connections (data/connections.json) and reports which connections VIOLATE the
segmentation policy (cross a trust boundary that should be closed).

It makes no network connections. It compares a policy and a connection list,
both of which you own, to validate a design.

Tested: CPython 3.14.4, Windows 11, standard library only, 2026-11-08.
"""
import argparse
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))


def load(path):
    return json.load(open(path))


def allowed(policy, src, dst, port):
    for flow in policy["allowed"]:
        if flow["src"] == src and flow["dst"] == dst and port in flow["ports"]:
            return True
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--policy", default=os.path.join(HERE, "data", "rk_segmentation.json"))
    ap.add_argument("--connections", default=os.path.join(HERE, "data", "connections.json"))
    args = ap.parse_args()
    policy = load(args.policy)
    conns = load(args.connections)["connections"]

    print("Segmentation check (zero-trust default-deny)")
    print("policy: %d allowed flows; connections: %d" % (len(policy["allowed"]), len(conns)))
    violations = []
    for c in conns:
        ok = allowed(policy, c["src"], c["dst"], c["port"])
        tag = "OK " if ok else "VIOLATION"
        if not ok:
            violations.append(c)
        print("  [%-9s] %-6s -> %-6s :%-5d  %s"
              % (tag, c["src"], c["dst"], c["port"], c.get("note", "")))
    print("\n%d of %d connections violate the segmentation policy."
          % (len(violations), len(conns)))
    if violations:
        print("Violations cross a trust boundary that should be denied by default:")
        for v in violations:
            print("  - %s -> %s :%d  (%s)"
                  % (v["src"], v["dst"], v["port"], v.get("note", "")))
    raise SystemExit(1 if violations else 0)


if __name__ == "__main__":
    main()
