RedKross Academy - Course 07: Network Security
AUTHORISED, ENTIRELY OFFLINE DEFENSIVE LAB. No network activity of any kind.
================================================================================

WHAT THIS IS
A network-defence lab for the fictional "Himalaya Retail" network. Every tool
is DEFENSIVE and works offline on local design documents and provided
telemetry that you own. Nothing here connects to a network, scans a host, or
sends a packet. You review and harden a design, and detect signals in provided
flow telemetry - the work of a network defender and architect.

SAFETY AND LAW
These tools never touch a live system. They read JSON policy/config documents
and a synthetic flow log and report findings. Network scanning, probing or
attacking a system you do not own and are not authorised to test is unlawful
(in India, e.g. the Information Technology Act, 2000, sections 43 and 66) - and
this lab deliberately requires none of it. Keep it that way.

FILES
  firewall.py          evaluate a flow against a ruleset and lint the policy  M02
  segmentation.py      validate connections against a zero-trust zone matrix  M04
  make_flows.py        generate the deterministic synthetic flow telemetry    M07
  flowcheck.py         detect scans, beaconing and segmentation breaches      M07
  tlscheck.py          offline review of a TLS/certificate configuration      M05
  review.py            one-page control-validation summary (capstone aid)     M08
  data/                policies, configs, telemetry and saved tool output

DATA
  rk_firewall.json / rk_firewall_fixed.json   pre-hardening and hardened policy
  rk_segmentation.json                         zero-trust allowed-flow matrix
  connections.json                             connections to validate
  flows.jsonl                                  synthetic NetFlow/IPFIX records
  tls_config.json / tls_config_fixed.json      pre/post TLS configuration
  *_output.txt, firewall_lint*.txt, ...        saved, execution-tested output

HOW TO RUN
  python firewall.py --lint                         # finds policy weaknesses
  python firewall.py --eval user db tcp 5432        # evaluate one flow
  python firewall.py --lint --rules data/rk_firewall_fixed.json   # 0 HIGH
  python segmentation.py                            # lists policy violations
  python make_flows.py                              # (re)build telemetry
  python flowcheck.py                               # scans/beacons/violations
  python tlscheck.py                                # pre-hardening TLS review
  python tlscheck.py --config data/tls_config_fixed.json          # 0 HIGH
  python review.py                                  # capstone control summary

WHAT THE LAB DEMONSTRATES (execution-tested 2026-11-08, CPython 3.14.4)
  - Firewall lint: the pre-hardening policy has 4 findings (1 HIGH: no default-
    deny); the hardened policy has 0. First-match evaluation shows user->db
    wrongly allowed by a too-broad rule in the vuln policy and explicitly
    denied in the hardened one.
  - Segmentation: 3 of 7 connections violate the zero-trust matrix (user->db,
    internet->db, user->mgmt).
  - Flow telemetry: 1 port scan, 1 beaconing host (~60s interval to the
    internet) and 3 aggregated segmentation breaches detected in 186 records.
  - TLS review: the pre-hardening config has 5 HIGH (TLS 1.0/1.1, RC4, 3DES,
    1024-bit key) and a near-expiry cert; the hardened config (TLS 1.2/1.3,
    AEAD suites, 2048-bit key) has 0.
  - review.py: firewall, segmentation and TLS all move from FAIL to PASS.

STANDARDS REFERENCED
NIST SP 800-41r1 (firewalls), SP 800-207 (zero trust), SP 800-94 (IDS/IPS),
SP 800-52r2 and RFC 8996/8446 (TLS), SP 800-153 (wireless LAN), RFC 7011
(IPFIX/flow). Verified at source 2026-11-08.
