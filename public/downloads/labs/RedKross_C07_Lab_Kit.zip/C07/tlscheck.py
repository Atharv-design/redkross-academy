#!/usr/bin/env python3
"""
tlscheck.py - offline review of a TLS/certificate CONFIGURATION (Course 07).

Entirely offline. It does NOT connect to any server. It reads a declarative
description of a TLS endpoint's configuration (data/tls_config.json) - the
protocol versions enabled, the cipher list, the certificate key size and
validity dates - and flags weaknesses against current guidance:
  - deprecated protocols enabled (SSLv3, TLS 1.0, TLS 1.1 - RFC 8996)
  - weak ciphers (RC4, 3DES/DES, EXPORT, NULL, anonymous)
  - weak certificate key (RSA < 2048 bits)
  - certificate expired or expiring soon
  - missing TLS 1.2/1.3 support (NIST SP 800-52r2 requires TLS 1.2+)

Use it to review a configuration you own before deployment. It replaces live
scanning with a document review, so it is safe and deterministic.

Tested: CPython 3.14.4, Windows 11, standard library only, 2026-11-08.
"""
import argparse
import datetime
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))

DEPRECATED_PROTOCOLS = {"SSLv2", "SSLv3", "TLS1.0", "TLS1.1"}
REQUIRED_MODERN = {"TLS1.2", "TLS1.3"}
WEAK_CIPHER_TOKENS = ["RC4", "3DES", "DES", "EXPORT", "NULL", "ANON", "MD5"]
# A fixed "today" so the lab result is reproducible; override with --today.
DEFAULT_TODAY = "2026-11-08"


def review(cfg, today):
    findings = []
    protos = set(cfg.get("protocols", []))
    for p in sorted(protos & DEPRECATED_PROTOCOLS):
        findings.append(("HIGH", "deprecated protocol enabled: %s" % p,
                         "Disable %s; it is formally deprecated (RFC 8996)." % p))
    if not (protos & REQUIRED_MODERN):
        findings.append(("HIGH", "no modern TLS (1.2/1.3) enabled",
                         "Enable TLS 1.2 and 1.3 (NIST SP 800-52r2)."))
    for cipher in cfg.get("ciphers", []):
        up = cipher.upper()
        for tok in WEAK_CIPHER_TOKENS:
            if tok in up:
                findings.append(("HIGH", "weak cipher offered: %s" % cipher,
                                 "Remove %s; prefer AEAD suites (AES-GCM, "
                                 "ChaCha20-Poly1305)." % tok))
                break
    key = cfg.get("cert", {}).get("rsa_key_bits")
    if key is not None and key < 2048:
        findings.append(("HIGH", "certificate RSA key too small: %d bits" % key,
                         "Use RSA >= 2048 or an ECDSA P-256 key."))
    not_after = cfg.get("cert", {}).get("not_after")
    if not_after:
        d_today = datetime.date.fromisoformat(today)
        d_exp = datetime.date.fromisoformat(not_after)
        days = (d_exp - d_today).days
        if days < 0:
            findings.append(("HIGH", "certificate expired %d days ago" % -days,
                             "Renew the certificate immediately."))
        elif days <= 30:
            findings.append(("MEDIUM", "certificate expires in %d days" % days,
                             "Renew soon and automate renewal."))
    return findings


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(HERE, "data", "tls_config.json"))
    ap.add_argument("--today", default=DEFAULT_TODAY)
    args = ap.parse_args()
    cfg = json.load(open(args.config))
    findings = review(cfg, args.today)

    print("TLS configuration review: %s (as of %s)" % (cfg.get("name", "?"), args.today))
    print("  protocols: %s" % ", ".join(cfg.get("protocols", [])))
    for sev, title, fix in findings:
        print("  [%-6s] %s" % (sev, title))
        print("           fix: %s" % fix)
    highs = sum(1 for s, _, _ in findings if s == "HIGH")
    print("\n%d findings (%d HIGH)." % (len(findings), highs))
    raise SystemExit(1 if highs else 0)


if __name__ == "__main__":
    main()
