#!/usr/bin/env python3
"""
make_flows.py - generate a deterministic synthetic network flow log (Course 07).

Writes data/flows.jsonl: NetFlow/IPFIX-style records (RFC 7011 concepts) for
the fictional Himalaya Retail network. The data is SYNTHETIC and fixed (seeded),
so the analyzer's results are reproducible. It contains normal traffic plus a
few embedded patterns for flowcheck.py to detect defensively: a port scan, a
beaconing host, and a segmentation-violating flow.

No network activity of any kind - this only writes a local JSON lines file.

Tested: CPython 3.14.4, Windows 11, standard library only, 2026-11-08.
"""
import json
import os
import random

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "data", "flows.jsonl")

# zone per subnet for the analyzer to map
HOSTS = {
    "203.0.113.10": "internet", "203.0.113.50": "internet",
    "10.1.0.10": "dmz", "10.2.0.10": "app", "10.2.0.11": "app",
    "10.3.0.10": "db", "10.4.0.20": "user", "10.4.0.21": "user",
    "10.9.0.5": "mgmt",
}


def rec(ts, src, dst, proto, dport, bytes_):
    return {"ts": ts, "src": src, "dst": dst, "proto": proto,
            "dport": dport, "bytes": bytes_}


def main():
    random.seed(7)
    flows = []
    # normal web traffic internet -> dmz:443 (irregular human browsing: wide
    # jitter so it is NOT mistaken for beaconing)
    t = 1000
    for _ in range(40):
        flows.append(rec(t, "203.0.113.10", "10.1.0.10", "tcp", 443,
                         random.randint(400, 9000)))
        t += random.randint(3, 45)
    # normal dmz -> app:8080 and app -> db:5432 (irregular, wide jitter)
    ta = 1000
    for _ in range(25):
        flows.append(rec(ta, "10.1.0.10", "10.2.0.10", "tcp", 8080,
                         random.randint(300, 4000)))
        ta += random.randint(4, 40)
        flows.append(rec(ta, "10.2.0.10", "10.3.0.10", "tcp", 5432,
                         random.randint(200, 3000)))
        ta += random.randint(4, 40)
    t = max(t, ta) + 20
    # PORT SCAN: one internet host hits many ports on the dmz host quickly
    scan_t = t
    for port in range(20, 20 + 60):
        flows.append(rec(scan_t, "203.0.113.50", "10.1.0.10", "tcp", port, 40))
        scan_t += 1
    t = scan_t + 10
    # BEACONING: a user host talks to one internet host at a fixed 60s interval
    bt = t
    for _ in range(15):
        flows.append(rec(bt, "10.4.0.21", "203.0.113.50", "tcp", 443, 512))
        bt += 60
    t = bt + 5
    # SEGMENTATION VIOLATION: a user host connects directly to the db
    flows.append(rec(t, "10.4.0.20", "10.3.0.10", "tcp", 5432, 800))
    t += 3
    # more normal noise
    for _ in range(20):
        flows.append(rec(t, "203.0.113.10", "10.1.0.10", "tcp", 443,
                         random.randint(400, 9000)))
        t += random.randint(1, 5)

    flows.sort(key=lambda f: f["ts"])
    with open(OUT, "w") as fh:
        for f in flows:
            fh.write(json.dumps(f) + "\n")
    print("wrote %d flow records to %s" % (len(flows), OUT))


if __name__ == "__main__":
    main()
