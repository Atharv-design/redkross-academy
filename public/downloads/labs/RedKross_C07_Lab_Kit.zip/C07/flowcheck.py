#!/usr/bin/env python3
"""
flowcheck.py - defensive analysis of network flow telemetry (Course 07).

Entirely offline. Reads data/flows.jsonl (NetFlow/IPFIX-style records written
by make_flows.py) and reports defensive signals a network monitoring team would
triage:
  - top talkers (busiest source hosts)
  - PORT SCAN: a source contacting many distinct destination ports on one host
    in a short window
  - BEACONING: a source contacting one destination at a near-constant interval
    (a common command-and-control pattern)
  - SEGMENTATION VIOLATION: a flow that crosses a zone boundary the policy
    denies (reuses data/rk_segmentation.json)

This reads provided telemetry; it does not capture live traffic or touch any
network. It is a review and detection aid for data you own.

Tested: CPython 3.14.4, Windows 11, standard library only, 2026-11-08.
"""
import argparse
import json
import os
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))

ZONE = {
    "203.0.113.10": "internet", "203.0.113.50": "internet",
    "10.1.0.10": "dmz", "10.2.0.10": "app", "10.2.0.11": "app",
    "10.3.0.10": "db", "10.4.0.20": "user", "10.4.0.21": "user",
    "10.9.0.5": "mgmt",
}

SCAN_PORT_THRESHOLD = 20      # distinct ports to one dst -> scan
SCAN_WINDOW = 120             # seconds
BEACON_MIN_HITS = 8           # repeated contacts
BEACON_JITTER = 5             # seconds tolerance on the interval


def load_flows(path):
    rows = []
    with open(path) as fh:
        for line in fh:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def top_talkers(flows, n=5):
    by_src = defaultdict(lambda: [0, 0])
    for f in flows:
        by_src[f["src"]][0] += 1
        by_src[f["src"]][1] += f["bytes"]
    ranked = sorted(by_src.items(), key=lambda kv: kv[1][1], reverse=True)
    return ranked[:n]


def detect_scans(flows):
    # group by (src, dst) and collect ports and timestamps
    groups = defaultdict(list)
    for f in flows:
        groups[(f["src"], f["dst"])].append((f["ts"], f["dport"]))
    hits = []
    for (src, dst), events in groups.items():
        events.sort()
        ports = {p for _, p in events}
        span = events[-1][0] - events[0][0]
        if len(ports) >= SCAN_PORT_THRESHOLD and span <= SCAN_WINDOW:
            hits.append((src, dst, len(ports), span))
    return hits


def detect_beacons(flows, exclude_pairs=None):
    exclude_pairs = exclude_pairs or set()
    groups = defaultdict(list)
    for f in flows:
        groups[(f["src"], f["dst"])].append(f["ts"])
    hits = []
    for (src, dst), times in groups.items():
        if (src, dst) in exclude_pairs:
            continue  # already reported as a scan; do not double-label
        if len(times) < BEACON_MIN_HITS:
            continue
        times.sort()
        gaps = [b - a for a, b in zip(times, times[1:])]
        if not gaps:
            continue
        avg = sum(gaps) / len(gaps)
        if avg <= 0:
            continue
        # near-constant interval = beaconing
        if all(abs(g - avg) <= BEACON_JITTER for g in gaps):
            hits.append((src, dst, len(times), round(avg, 1)))
    return hits


def detect_seg_violations(flows, policy):
    """Aggregate per host-pair so a port sweep is one line, not hundreds."""
    allowed = {(a["src"], a["dst"], p) for a in policy["allowed"] for p in a["ports"]}
    agg = defaultdict(set)
    for f in flows:
        s, d = ZONE.get(f["src"]), ZONE.get(f["dst"])
        if s is None or d is None or s == d:
            continue
        if (s, d, f["dport"]) not in allowed:
            agg[(f["src"], s, f["dst"], d)].add(f["dport"])
    out = []
    for (sip, sz, dip, dz), ports in sorted(agg.items()):
        out.append((sip, sz, dip, dz, sorted(ports)))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--flows", default=os.path.join(HERE, "data", "flows.jsonl"))
    ap.add_argument("--policy", default=os.path.join(HERE, "data", "rk_segmentation.json"))
    args = ap.parse_args()
    flows = load_flows(args.flows)
    policy = json.load(open(args.policy))

    print("Flow telemetry analysis: %d records" % len(flows))
    print("\nTop talkers (by bytes):")
    for src, (count, byts) in top_talkers(flows):
        print("  %-14s %5d flows  %8d bytes  (%s)"
              % (src, count, byts, ZONE.get(src, "?")))

    scans = detect_scans(flows)
    print("\nPort scans (>= %d ports to one host within %ds):"
          % (SCAN_PORT_THRESHOLD, SCAN_WINDOW))
    for src, dst, nports, span in scans:
        print("  SCAN %s -> %s : %d ports in %ds" % (src, dst, nports, span))
    if not scans:
        print("  none")

    scan_pairs = {(s, d) for s, d, _, _ in scans}
    beacons = detect_beacons(flows, exclude_pairs=scan_pairs)
    print("\nBeaconing (>= %d contacts at near-constant interval):" % BEACON_MIN_HITS)
    for src, dst, n, avg in beacons:
        print("  BEACON %s -> %s : %d contacts, ~%ss interval" % (src, dst, n, avg))
    if not beacons:
        print("  none")

    viol = detect_seg_violations(flows, policy)
    print("\nSegmentation violations in telemetry (aggregated per host-pair):")
    for sip, sz, dip, dz, ports in viol:
        if len(ports) > 6:
            pstr = "%d ports incl %s..." % (len(ports), ",".join(map(str, ports[:5])))
        else:
            pstr = ",".join(map(str, ports))
        print("  VIOLATION %s(%s) -> %s(%s) : %s" % (sip, sz, dip, dz, pstr))
    if not viol:
        print("  none")

    total = len(scans) + len(beacons) + len(viol)
    print("\n%d defensive signal(s) to triage (%d scan, %d beacon, %d "
          "segmentation)." % (total, len(scans), len(beacons), len(viol)))


if __name__ == "__main__":
    main()
