#!/usr/bin/env python3
"""disasm.py - RedKross C10 reverse engineering: a tiny x86-64 linear
disassembler for a TEACHING SUBSET of opcodes.

It decodes the handful of instructions used by the lab specimens' .text stubs
(mov r32,imm32; mov r/m,r via 0x89; xor r64,r64; syscall; ret; int3; nop;
push/pop r64; call rel32; jmp rel32). It is NOT a full disassembler - it exists
so the RE module can show how bytes become instructions and how control flow is
read. For real work use a proper disassembler/decompiler (e.g. Ghidra) inside an
isolated lab. Reads bytes only.

  python disasm.py --pe specimen/rkspecimen.exe     # disassemble .text
  python disasm.py --elf specimen/rkspecimen.elf
  python disasm.py --hex 4831c0c3                    # disassemble raw hex
"""
import struct
import sys

REG64 = ["rax", "rcx", "rdx", "rbx", "rsp", "rbp", "rsi", "rdi"]
REG32 = ["eax", "ecx", "edx", "ebx", "esp", "ebp", "esi", "edi"]


def decode(code, base=0):
    out = []
    i = 0
    n = len(code)
    while i < n:
        start = i
        addr = base + i
        b = code[i]
        rex_w = False
        rex = 0
        if 0x40 <= b <= 0x4F:
            rex = b
            rex_w = bool(b & 0x08)
            i += 1
            if i >= n:
                out.append((addr, code[start:i], "db 0x%02X" % b))
                break
            b = code[i]
        if b == 0x90:
            out.append((addr, code[start:i + 1], "nop")); i += 1
        elif b == 0xC3:
            out.append((addr, code[start:i + 1], "ret")); i += 1
        elif b == 0xCC:
            out.append((addr, code[start:i + 1], "int3")); i += 1
        elif b == 0x0F and i + 1 < n and code[i + 1] == 0x05:
            out.append((addr, code[start:i + 2], "syscall")); i += 2
        elif b == 0x31 and i + 1 < n:              # xor r/m,r (32/64)
            modrm = code[i + 1]
            reg = (modrm >> 3) & 7
            rm = modrm & 7
            regs = REG64 if rex_w else REG32
            out.append((addr, code[start:i + 2],
                        "xor %s, %s" % (regs[rm], regs[reg]))); i += 2
        elif b == 0x89 and i + 1 < n:              # mov r/m,r
            modrm = code[i + 1]
            reg = (modrm >> 3) & 7
            rm = modrm & 7
            regs = REG64 if rex_w else REG32
            out.append((addr, code[start:i + 2],
                        "mov %s, %s" % (regs[rm], regs[reg]))); i += 2
        elif 0xB8 <= b <= 0xBF and i + 4 < n:      # mov r32, imm32
            reg = b - 0xB8
            imm = struct.unpack_from("<I", code, i + 1)[0]
            out.append((addr, code[start:i + 5],
                        "mov %s, 0x%X" % (REG32[reg], imm))); i += 5
        elif 0x50 <= b <= 0x57:                    # push r64
            out.append((addr, code[start:i + 1],
                        "push %s" % REG64[b - 0x50])); i += 1
        elif 0x58 <= b <= 0x5F:                    # pop r64
            out.append((addr, code[start:i + 1],
                        "pop %s" % REG64[b - 0x58])); i += 1
        elif b == 0xE8 and i + 4 < n:              # call rel32
            rel = struct.unpack_from("<i", code, i + 1)[0]
            tgt = base + i + 5 + rel
            out.append((addr, code[start:i + 5], "call 0x%X" % tgt)); i += 5
        elif b == 0xE9 and i + 4 < n:              # jmp rel32
            rel = struct.unpack_from("<i", code, i + 1)[0]
            tgt = base + i + 5 + rel
            out.append((addr, code[start:i + 5], "jmp 0x%X" % tgt)); i += 5
        else:
            out.append((addr, code[start:i + 1], "db 0x%02X  ; (not in subset)" % b))
            i += 1
    return out


def get_pe_text(path):
    import peinfo
    info = peinfo.parse(path)
    with open(path, "rb") as f:
        data = f.read()
    for s in info["sections"]:
        if s["name"] == ".text":
            code = data[s["rawoff"]:s["rawoff"] + s["vsize"]]
            return code, info["image_base"] + s["vrva"]
    raise ValueError("no .text section")


def get_elf_text(path):
    import elfinfo
    info = elfinfo.parse(path)
    with open(path, "rb") as f:
        data = f.read()
    # entry stub sits right after ehdr+phdrs in the lab ELF
    entry = info["e_entry"]
    load = info["phdrs"][0]["vaddr"]
    off = entry - load
    return data[off:off + 12], entry


def main(argv):
    if len(argv) == 3 and argv[1] == "--pe":
        code, base = get_pe_text(argv[2])
    elif len(argv) == 3 and argv[1] == "--elf":
        code, base = get_elf_text(argv[2])
    elif len(argv) == 3 and argv[1] == "--hex":
        code, base = bytes.fromhex(argv[2]), 0
    else:
        print("usage: python disasm.py --pe <f> | --elf <f> | --hex <bytes>")
        return 2
    print("Disassembly (teaching subset) base=0x%X:" % base)
    for addr, raw, text in decode(code, base):
        print("  0x%08X  %-14s %s" % (addr, raw.hex(), text))
    print("Note: decodes a limited opcode subset for teaching. Unknown bytes "
          "show as 'db'. Use a full disassembler for real analysis.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
