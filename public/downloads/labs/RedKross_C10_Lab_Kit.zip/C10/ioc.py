#!/usr/bin/env python3
"""ioc.py - RedKross C10: extract indicators of compromise (IOCs) from a
specimen and its behaviour log, for DEFENSIVE use (blocklists, hunts).

Collects file hashes, network indicators (URLs, IPs, host:port), file-path and
registry indicators, and mutex names from the static strings and the dynamic
behaviour log, and writes an IOC list to data/iocs.json. These IOCs are for
detecting and blocking the specimen in your own environment - they are not
instructions to contact anything.

  python ioc.py specimen/rkspecimen.exe data/behaviour_run.json
"""
import hashlib
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

URL_RE = re.compile(rb"https?://[\x21-\x7e]+")
IP_RE = re.compile(rb"\b(?:\d{1,3}\.){3}\d{1,3}\b")
HOSTPORT_RE = re.compile(rb"\b(?:\d{1,3}\.){3}\d{1,3}:\d{1,5}\b")
WINPATH_RE = re.compile(rb"[A-Za-z]:\\\\?[\w\\.\- ]+\.\w+")
REG_RE = re.compile(rb"HK(?:LM|CU|CR|U|CC)\\[\w\\]+")
MUTEX_RE = re.compile(rb"RK-LAB-[A-Z0-9\-]+")


def valid_ip(s):
    return all(0 <= int(p) <= 255 for p in s.split("."))


def extract_static(path):
    with open(path, "rb") as f:
        data = f.read()
    iocs = {
        "hashes": {
            "md5": hashlib.md5(data).hexdigest(),
            "sha1": hashlib.sha1(data).hexdigest(),
            "sha256": hashlib.sha256(data).hexdigest(),
        },
        "urls": sorted({m.decode("latin1") for m in URL_RE.findall(data)}),
        "ips": sorted({m.decode() for m in IP_RE.findall(data)
                       if valid_ip(m.decode())}),
        "host_ports": sorted({m.decode() for m in HOSTPORT_RE.findall(data)}),
        "file_paths": sorted({m.decode("latin1") for m in
                              WINPATH_RE.findall(data)}),
        "registry_keys": sorted({m.decode() for m in REG_RE.findall(data)}),
        "mutexes": sorted({m.decode() for m in MUTEX_RE.findall(data)}),
    }
    return iocs


def extract_dynamic(path, iocs):
    with open(path) as f:
        log = json.load(f)
    for e in log.get("events", []):
        d = e.get("detail", "")
        for m in IP_RE.findall(d.encode()):
            ip = m.decode()
            if valid_ip(ip) and ip not in iocs["ips"]:
                iocs["ips"].append(ip)
        for m in REG_RE.findall(d.encode()):
            k = m.decode()
            if k not in iocs["registry_keys"]:
                iocs["registry_keys"].append(k)
    iocs["ips"].sort()
    iocs["registry_keys"].sort()
    return iocs


def main(argv):
    if len(argv) < 2:
        print("usage: python ioc.py <specimen> [behaviour_log.json]")
        return 2
    iocs = extract_static(argv[1])
    if len(argv) >= 3:
        iocs = extract_dynamic(argv[2], iocs)
    iocs["note"] = ("IOCs from the inert RedKross teaching specimen. Network "
                    "indicators use documentation ranges (RFC 5737/2606) and "
                    "point at nothing real. Use for detection/blocking only.")
    out = os.path.join(HERE, "data", "iocs.json")
    with open(out, "w") as f:
        json.dump(iocs, f, indent=2)
    print("IOCs extracted (defensive use only):")
    print("  sha256        : %s" % iocs["hashes"]["sha256"])
    print("  urls          : %s" % (iocs["urls"] or "-"))
    print("  ips           : %s" % (iocs["ips"] or "-"))
    print("  host:port     : %s" % (iocs["host_ports"] or "-"))
    print("  file paths    : %s" % (iocs["file_paths"] or "-"))
    print("  registry keys : %s" % (iocs["registry_keys"] or "-"))
    print("  mutexes       : %s" % (iocs["mutexes"] or "-"))
    print("  written to    : %s" % out)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
