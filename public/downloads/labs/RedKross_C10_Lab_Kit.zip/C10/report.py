#!/usr/bin/env python3
"""report.py - RedKross C10: assemble a malware-analysis report.

Runs the static, dynamic and detection tools over the lab specimen and produces
a structured analyst report: classification with a CONFIDENCE level and stated
LIMITATIONS, key static/dynamic findings, IOCs, detection coverage, and
DEFENSIVE recommendations. This models the deliverable of a real engagement.

  python report.py
"""
import io
import json
import os
import sys
from contextlib import redirect_stdout

HERE = os.path.dirname(os.path.abspath(__file__))
SPEC = os.path.join(HERE, "specimen", "rkspecimen.exe")


def capture(func, *args):
    buf = io.StringIO()
    with redirect_stdout(buf):
        func(*args)
    return buf.getvalue()


def main(argv):
    import triage
    import peinfo
    import ioc

    # gather data
    with open(SPEC, "rb") as f:
        data = f.read()
    pe = peinfo.parse(SPEC)
    iocs = ioc.extract_static(SPEC)
    beh_path = os.path.join(HERE, "data", "behaviour_run.json")
    with open(beh_path) as f:
        beh = json.load(f)

    caps = []
    for funcs in pe["imports"].values():
        for fn in funcs:
            if fn in peinfo.SUSPICIOUS:
                caps.append(fn)

    print("=" * 70)
    print("MALWARE ANALYSIS REPORT - RedKross C10 lab specimen")
    print("=" * 70)
    print("1. SUBJECT AND PROVENANCE")
    print("   file   : specimen/rkspecimen.exe")
    print("   size   : %d bytes" % len(data))
    print("   sha256 : %s" % iocs["hashes"]["sha256"])
    print("   source : authored in-lab as an INERT teaching artifact")
    print()
    print("2. CLASSIFICATION (with confidence and limitations)")
    print("   verdict    : benign teaching specimen that EXHIBITS a dropper/")
    print("                beacon PATTERN (file drop + autorun + network beacon")
    print("                + mutex) for analysis practice.")
    print("   confidence : high - the sample is lab-authored and its behaviour")
    print("                was observed in a sandbox.")
    print("   limitations: static imports show capability, not intent; the")
    print("                dynamic run shows one path; a real unknown would need")
    print("                multiple runs and deeper RE before a firm verdict.")
    print()
    print("3. STATIC FINDINGS")
    print("   format     : %s x86-64; entry RVA 0x%X" % (
        "PE32+" if pe["pe_plus"] else "PE32", pe["entry"]))
    print("   sections   : %s" % ", ".join(s["name"] for s in pe["sections"]))
    print("   capability imports: %s" % ", ".join(sorted(set(caps))))
    print("   notable strings   : rk-lab URL, host:port, mutex, dropped path")
    print()
    print("4. DYNAMIC FINDINGS (sandboxed, loopback-only)")
    for e in beh["events"]:
        print("   - %-14s %s" % (e["action"], e["detail"]))
    print()
    print("5. IOCs (defensive use only)")
    print("   sha256     : %s" % iocs["hashes"]["sha256"])
    print("   urls       : %s" % (", ".join(iocs["urls"]) or "-"))
    print("   host:port  : %s" % (", ".join(iocs["host_ports"]) or "-"))
    print("   mutex      : %s" % (", ".join(iocs["mutexes"]) or "-"))
    print("   dropped    : %s" % (", ".join(iocs["file_paths"]) or "-"))
    print()
    print("6. DETECTION COVERAGE")
    print("   YARA rules : rules/rkspecimen.rkyar (3 rules) - validated to fire")
    print("                on the specimen and not on a clean file.")
    print("   host IOCs  : mutex name and dropped-file path for EDR/hunt.")
    print("   network    : block the host:port/URL at the proxy/firewall.")
    print()
    print("7. DEFENSIVE RECOMMENDATIONS")
    print("   - deploy the YARA rules to the mail/endpoint/file gateways;")
    print("   - alert on creation of the mutex and the dropped file path;")
    print("   - block the C2 indicators and hunt historical proxy/DNS logs;")
    print("   - ensure autorun-key creation under HKCU\\...\\Run is monitored.")
    print()
    print("8. HANDLING STATEMENT")
    print("   Analysis was performed on a lab-authored, inert specimen inside an")
    print("   isolated sandbox with no internet egress. No third-party or live")
    print("   malware was handled, and nothing was executed outside the sandbox.")
    print("=" * 70)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
