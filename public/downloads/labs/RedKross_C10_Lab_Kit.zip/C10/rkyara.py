#!/usr/bin/env python3
"""rkyara.py - RedKross C10 detection engineering: a minimal YARA-like matcher.

A tiny, original rule engine that reads rules in a small subset of YARA-like
syntax and scans files for them. It is NOT YARA; it teaches how string- and
byte-signatures plus a simple condition become a detection, and how to VALIDATE
a rule (it should fire on the specimen and NOT on clean files).

Rule file format (see rules/rkspecimen.rkyar):
  rule NAME {
    meta:
      author = "..."
      description = "..."
    strings:
      $a = "ascii text"
      $b = { DE AD BE EF }        // hex bytes
      $c = "wide text" wide       // UTF-16LE
    condition:
      all of them                 // or: any of them / N of them
  }

Usage:
  python rkyara.py rules/rkspecimen.rkyar specimen/rkspecimen.exe
  python rkyara.py rules/ specimen/rkspecimen.exe clean.bin   # dir of rules
"""
import os
import re
import sys


def parse_rules(text):
    rules = []
    for m in re.finditer(r"rule\s+(\w+)\s*\{(.*?)\n\}", text, re.S):
        name, body = m.group(1), m.group(2)
        meta = dict(re.findall(r'(\w+)\s*=\s*"([^"]*)"',
                               _section(body, "meta")))
        strings = {}
        for sm in re.finditer(r'(\$\w+)\s*=\s*(.+)', _section(body, "strings")):
            ident, val = sm.group(1), sm.group(2).strip()
            strings[ident] = _parse_string(val)
        cond = _section(body, "condition").strip()
        rules.append({"name": name, "meta": meta, "strings": strings,
                      "condition": cond})
    return rules


def _section(body, name):
    m = re.search(name + r"\s*:(.*?)(?:\n\s*(?:meta|strings|condition)\s*:|\Z)",
                  body, re.S)
    return m.group(1) if m else ""


def _parse_string(val):
    val = val.strip()
    if val.startswith('"'):
        # take content between the first and the matching closing quote; only
        # material AFTER the closing quote may be a 'wide' keyword or comment.
        end = val.index('"', 1)
        s = val[1:end]
        trailer = val[end + 1:]
        wide = "wide" in re.sub(r"//.*$", "", trailer)
        enc = s.encode("utf-16-le") if wide else s.encode()
        return ("wide" if wide else "text", enc)
    if val.startswith("{"):
        hx = val[1:val.index("}")].replace(" ", "")
        return ("bytes", bytes.fromhex(hx))
    raise ValueError("cannot parse string literal: %r" % val)


def eval_condition(cond, hits):
    n_total = len(hits)
    n_hit = sum(1 for v in hits.values() if v)
    cond = cond.strip()
    if cond == "all of them":
        return n_hit == n_total and n_total > 0
    if cond == "any of them":
        return n_hit >= 1
    m = re.match(r"(\d+)\s+of\s+them", cond)
    if m:
        return n_hit >= int(m.group(1))
    # fallback: single identifier reference
    if cond in hits:
        return hits[cond]
    return False


def scan_file(rules, path):
    with open(path, "rb") as f:
        data = f.read()
    results = []
    for rule in rules:
        hits = {}
        for ident, (_kind, needle) in rule["strings"].items():
            hits[ident] = needle in data
        matched = eval_condition(rule["condition"], hits)
        results.append((rule, matched, hits))
    return results


def load_rule_path(p):
    text = ""
    if os.path.isdir(p):
        for fn in sorted(os.listdir(p)):
            if fn.endswith((".rkyar", ".yar")):
                with open(os.path.join(p, fn)) as f:
                    text += f.read() + "\n"
    else:
        with open(p) as f:
            text = f.read()
    return parse_rules(text)


def main(argv):
    if len(argv) < 3:
        print("usage: python rkyara.py <rules file|dir> <file> [file...]")
        return 2
    rules = load_rule_path(argv[1])
    print("Loaded %d rule(s) from %s" % (len(rules), argv[1]))
    any_match = False
    for path in argv[2:]:
        print("Scanning %s" % path)
        for rule, matched, hits in scan_file(rules, path):
            if matched:
                any_match = True
                hitlist = ",".join(k for k, v in hits.items() if v)
                print("  MATCH  %-24s [%s]  (%s)" % (
                    rule["name"], hitlist,
                    rule["meta"].get("description", "")))
            else:
                print("  -      %-24s (no match; %d/%d strings)" % (
                    rule["name"], sum(hits.values()), len(hits)))
    return 0 if any_match else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
