#!/usr/bin/env python3
"""make_specimen.py - RedKross C10 Malware Analysis lab.

Deterministically authors INERT teaching specimens for static analysis and
reverse engineering:
  specimen/rkspecimen.exe  - a minimal, valid PE32+ file (static-analysis
                             target). It is NOT malware: its .text is a tiny
                             stub that returns immediately. The import names and
                             strings are present only so learners can practise
                             reading a PE's structure, imports and strings.
  specimen/rkspecimen.elf  - a minimal, valid ELF64 file with a tiny .text and
                             strings, for the reverse-engineering module.
  data/behaviour_run.json  - a RECORDED behaviour log of the benign simulator
                             (rksim.py) run in a sandbox, for dynamic analysis.

Everything here is original, offline and harmless. No real malware is created,
downloaded or executed. The specimens do nothing to the host; they exist to be
examined. Run:  python make_specimen.py
"""
import json
import os
import struct

HERE = os.path.dirname(os.path.abspath(__file__))
SPEC = os.path.join(HERE, "specimen")
DATA = os.path.join(HERE, "data")

# Teaching indicators embedded in the specimens. These are FICTIONAL values in
# documentation ranges (RFC 5737 / RFC 2606) so they can never point at a real
# host. They are here to be found by strings/IOC extraction, not to be used.
C2_HOST = "198.51.100.23"          # RFC 5737 TEST-NET-2 (documentation only)
C2_PORT = 8443
C2_URL = "https://update.rk-lab.example/beacon"   # RFC 2606 .example
MUTEX = "RK-LAB-SPECIMEN-7F3A"
DROP_PATH = "C:\\ProgramData\\rk_lab\\marker.bin"
VERSION = "rkspecimen v1.0 (RedKross teaching artifact - inert)"

# Recognisable Win32 API names, grouped by DLL, used ONLY as import-table names
# so the PE has a realistic import directory to analyse. The specimen never
# calls them.
IMPORTS = {
    "KERNEL32.dll": ["CreateFileA", "WriteFile", "CloseHandle",
                     "CreateMutexA", "Sleep", "VirtualAlloc"],
    "ADVAPI32.dll": ["RegOpenKeyExA", "RegSetValueExA", "RegCloseKey"],
    "WS2_32.dll": ["WSAStartup", "socket", "connect", "send"],
}

ASCII_STRINGS = [VERSION, C2_URL, "%s:%d" % (C2_HOST, C2_PORT), MUTEX,
                 DROP_PATH, "config:%s:%d", "User-Agent: rk-lab/1.0",
                 "unable to open config", "ok"]


def _align(n, a):
    return (n + a - 1) // a * a


def build_pe():
    """Build a minimal but structurally valid PE32+ (x86-64) file.

    Layout: DOS header + stub, NT headers (file + optional + data dirs),
    section table for .text and .rdata, then the two sections. .rdata holds the
    import directory, import-name strings and the ASCII teaching strings. .text
    is a 16-byte stub: xor eax,eax ; ret ; padded with int3.
    """
    FILE_ALIGN = 0x200
    SECT_ALIGN = 0x1000
    IMAGE_BASE = 0x140000000

    # ---- .text: inert stub (does nothing, returns 0) ----
    text = bytes([
        0x48, 0x31, 0xC0,              # xor rax, rax
        0xC3,                          # ret
    ])
    text += b"\xCC" * (16 - len(text))  # int3 padding

    # ---- Build .rdata: import strings, IAT/INT, import descriptors, strings ----
    # We lay out .rdata in a bytearray and record RVAs. .rdata is section index
    # 2, placed at SECT_ALIGN*2 in memory.
    rdata_rva = SECT_ALIGN * 2
    rd = bytearray()

    def cur_rva():
        return rdata_rva + len(rd)

    # Hint/Name tables for each imported function: WORD hint + name + NUL (even).
    name_rvas = {}
    for dll, funcs in IMPORTS.items():
        for fn in funcs:
            name_rvas[(dll, fn)] = cur_rva()
            rd.extend(struct.pack("<H", 0))      # hint
            b = fn.encode() + b"\x00"
            if len(b) % 2:
                b += b"\x00"
            rd.extend(b)

    # DLL name strings
    dll_name_rva = {}
    for dll in IMPORTS:
        dll_name_rva[dll] = cur_rva()
        b = dll.encode() + b"\x00"
        if len(b) % 2:
            b += b"\x00"
        rd.extend(b)

    # For each DLL: an Import Lookup Table (ILT) and Import Address Table (IAT),
    # each an array of 64-bit RVAs to hint/name, NULL-terminated.
    ilt_rva = {}
    iat_rva = {}
    for dll, funcs in IMPORTS.items():
        ilt_rva[dll] = cur_rva()
        for fn in funcs:
            rd.extend(struct.pack("<Q", name_rvas[(dll, fn)]))
        rd.extend(struct.pack("<Q", 0))
    for dll, funcs in IMPORTS.items():
        iat_rva[dll] = cur_rva()
        for fn in funcs:
            rd.extend(struct.pack("<Q", name_rvas[(dll, fn)]))
        rd.extend(struct.pack("<Q", 0))

    # Import Directory Table: one IMAGE_IMPORT_DESCRIPTOR (20 bytes) per DLL,
    # terminated by a zeroed descriptor.
    import_dir_rva = cur_rva()
    for dll in IMPORTS:
        rd.extend(struct.pack("<IIIII",
                              ilt_rva[dll],   # OriginalFirstThunk (ILT)
                              0,              # TimeDateStamp
                              0,              # ForwarderChain
                              dll_name_rva[dll],
                              iat_rva[dll]))  # FirstThunk (IAT)
    import_dir_size = len(rd) - (import_dir_rva - rdata_rva) + 20
    rd.extend(struct.pack("<IIIII", 0, 0, 0, 0, 0))  # null terminator

    # ASCII teaching strings
    for s in ASCII_STRINGS:
        rd.extend(s.encode() + b"\x00")

    rdata = bytes(rd)

    # ---- Section table geometry ----
    # Headers size: DOS(0x40)+stub(0x40)+PE sig(4)+COFF(20)+optional(240)+2*40
    size_of_headers = _align(0x80 + 4 + 20 + 240 + 2 * 40, FILE_ALIGN)

    text_vrva = SECT_ALIGN * 1
    text_fileoff = size_of_headers
    text_rawsize = _align(len(text), FILE_ALIGN)

    rdata_vrva = SECT_ALIGN * 2
    rdata_fileoff = text_fileoff + text_rawsize
    rdata_rawsize = _align(len(rdata), FILE_ALIGN)

    size_of_image = _align(rdata_vrva + len(rdata), SECT_ALIGN)
    entry_rva = text_vrva  # entry at start of .text

    # ---- DOS header + stub ----
    dos = bytearray(0x80)
    dos[0:2] = b"MZ"
    struct.pack_into("<H", dos, 0x3C - 0x3C + 0x3C, 0)  # placeholder
    struct.pack_into("<I", dos, 0x3C, 0x80)  # e_lfanew -> PE at 0x80
    dos[0x40:0x4E] = b"RedKross inert"       # friendly stub marker

    # ---- COFF file header ----
    NUM_SECT = 2
    coff = struct.pack("<HHIIIHH",
                       0x8664,     # Machine = AMD64
                       NUM_SECT,
                       0,          # TimeDateStamp (0 = teaching)
                       0, 0,       # ptr to symbols, num symbols
                       240,        # SizeOfOptionalHeader
                       0x0022)     # Characteristics: EXECUTABLE | LARGE_ADDR

    # ---- Optional header (PE32+) ----
    opt = bytearray()
    opt += struct.pack("<HBB", 0x020B, 14, 0)   # Magic PE32+, linker ver
    opt += struct.pack("<I", text_rawsize)       # SizeOfCode
    opt += struct.pack("<I", rdata_rawsize)      # SizeOfInitializedData
    opt += struct.pack("<I", 0)                  # SizeOfUninitializedData
    opt += struct.pack("<I", entry_rva)          # AddressOfEntryPoint
    opt += struct.pack("<I", text_vrva)          # BaseOfCode
    opt += struct.pack("<Q", IMAGE_BASE)         # ImageBase
    opt += struct.pack("<I", SECT_ALIGN)         # SectionAlignment
    opt += struct.pack("<I", FILE_ALIGN)         # FileAlignment
    opt += struct.pack("<HH", 6, 0)              # OS ver
    opt += struct.pack("<HH", 0, 0)              # Image ver
    opt += struct.pack("<HH", 6, 0)              # Subsystem ver
    opt += struct.pack("<I", 0)                  # Win32VersionValue
    opt += struct.pack("<I", size_of_image)      # SizeOfImage
    opt += struct.pack("<I", size_of_headers)    # SizeOfHeaders
    opt += struct.pack("<I", 0)                  # CheckSum
    opt += struct.pack("<HH", 3, 0x8160)         # Subsystem=CUI, DllCharacts
    opt += struct.pack("<QQQQ", 0x100000, 0x1000, 0x100000, 0x1000)  # stack/heap
    opt += struct.pack("<I", 0)                  # LoaderFlags
    opt += struct.pack("<I", 16)                 # NumberOfRvaAndSizes
    data_dirs = [(0, 0)] * 16
    data_dirs[1] = (import_dir_rva, import_dir_size)   # Import directory
    # IAT directory (index 12) - point at first IAT for realism
    first_iat = iat_rva[next(iter(IMPORTS))]
    iat_total = sum((len(f) + 1) * 8 for f in IMPORTS.values())
    data_dirs[12] = (first_iat, iat_total)
    for rva, size in data_dirs:
        opt += struct.pack("<II", rva, size)
    assert len(opt) == 240, len(opt)

    # ---- Section headers ----
    def sect_hdr(name, vsize, vrva, rawsize, rawoff, chars):
        nm = name.encode()[:8].ljust(8, b"\x00")
        return struct.pack("<8sIIIIIIHHI", nm, vsize, vrva, rawsize, rawoff,
                           0, 0, 0, 0, chars)

    sects = b""
    sects += sect_hdr(".text", len(text), text_vrva, text_rawsize, text_fileoff,
                      0x60000020)   # CODE | EXECUTE | READ
    sects += sect_hdr(".rdata", len(rdata), rdata_vrva, rdata_rawsize,
                      rdata_fileoff, 0x40000040)  # INITIALIZED_DATA | READ

    # ---- Assemble ----
    out = bytearray(rdata_fileoff + rdata_rawsize)
    out[0:0x80] = dos
    off = 0x80
    out[off:off + 4] = b"PE\x00\x00"
    off += 4
    out[off:off + 20] = coff
    off += 20
    out[off:off + 240] = opt
    off += 240
    out[off:off + len(sects)] = sects
    out[text_fileoff:text_fileoff + len(text)] = text
    out[rdata_fileoff:rdata_fileoff + len(rdata)] = rdata

    path = os.path.join(SPEC, "rkspecimen.exe")
    with open(path, "wb") as f:
        f.write(out)
    return path, len(out)


def build_elf():
    """Build a minimal ELF64 (x86-64) with a .text stub and a strings blob.

    One PT_LOAD program header covering the file; a tiny entry stub that calls
    exit(0) via syscall; the teaching strings appended after the code so the RE
    and strings modules have an ELF target too. Inert.
    """
    base = 0x400000
    ehsize = 64
    phentsize = 56
    phnum = 1
    code_off = ehsize + phentsize * phnum
    entry_vaddr = base + code_off

    # exit(0): mov edi,0 ; mov eax,60 ; syscall
    code = bytes([
        0xBF, 0x00, 0x00, 0x00, 0x00,   # mov edi, 0
        0xB8, 0x3C, 0x00, 0x00, 0x00,   # mov eax, 60 (sys_exit)
        0x0F, 0x05,                     # syscall
    ])
    blob = b"\x00".join(s.encode() for s in ASCII_STRINGS) + b"\x00"
    body = code + blob
    filesz = code_off + len(body)

    e_ident = b"\x7fELF" + bytes([2, 1, 1, 0]) + b"\x00" * 8
    ehdr = e_ident
    ehdr += struct.pack("<HHIQQQIHHHHHH",
                        2,            # e_type = ET_EXEC
                        0x3E,         # e_machine = x86-64
                        1,            # e_version
                        entry_vaddr,  # e_entry
                        ehsize,       # e_phoff
                        0,            # e_shoff (no section headers)
                        0,            # e_flags
                        ehsize,       # e_ehsize
                        phentsize, phnum,
                        0, 0, 0)      # shentsize, shnum, shstrndx
    phdr = struct.pack("<IIQQQQQQ",
                       1,             # p_type = PT_LOAD
                       5,             # p_flags = R+X
                       0,             # p_offset
                       base,          # p_vaddr
                       base,          # p_paddr
                       filesz,        # p_filesz
                       filesz,        # p_memsz
                       0x1000)        # p_align
    out = ehdr + phdr + body
    path = os.path.join(SPEC, "rkspecimen.elf")
    with open(path, "wb") as f:
        f.write(out)
    return path, len(out)


def build_behaviour_log():
    """Write a recorded, benign dynamic-analysis log for the dynamic module.

    This is what behaviour.py produces when it runs the inert simulator rksim.py
    inside a sandbox. Recorded here so the dynamic lesson has a reference even
    without running the harness. All activity is confined to the sandbox; the
    network entry is an ATTEMPT to a documentation-range host that the lab's
    local sink refuses - nothing leaves the host.
    """
    log = {
        "specimen": "rksim.py (inert benign simulator)",
        "sandbox": "isolated temp dir; local sink on 127.0.0.1; no internet",
        "events": [
            {"seq": 1, "type": "process", "action": "start",
             "detail": "rksim.py launched in sandbox"},
            {"seq": 2, "type": "mutex", "action": "create",
             "detail": MUTEX},
            {"seq": 3, "type": "file", "action": "write",
             "detail": "<sandbox>/ProgramData/rk_lab/marker.bin (12 bytes)"},
            {"seq": 4, "type": "registry_sim", "action": "set",
             "detail": "HKCU\\Software\\rk_lab\\Run = rksim (simulated, "
                       "written to sandbox registry.json)"},
            {"seq": 5, "type": "network", "action": "connect_attempt",
             "detail": "%s:%d (documentation range; refused by local sink)"
                       % (C2_HOST, C2_PORT)},
            {"seq": 6, "type": "network", "action": "send_blocked",
             "detail": "beacon payload not sent (no route; sink closed)"},
            {"seq": 7, "type": "process", "action": "sleep",
             "detail": "Sleep(60000) then exit 0"},
        ],
        "note": "Benign teaching simulator. The behaviours mimic a dropper/"
                "beacon pattern for analysis practice but cause no harm: all "
                "writes are inside the sandbox and no network egress occurs.",
    }
    path = os.path.join(DATA, "behaviour_run.json")
    with open(path, "w") as f:
        json.dump(log, f, indent=2)
    return path


def main():
    os.makedirs(SPEC, exist_ok=True)
    os.makedirs(DATA, exist_ok=True)
    pe, pesz = build_pe()
    elf, elfsz = build_elf()
    beh = build_behaviour_log()
    print("Built INERT teaching specimens (original, offline, harmless):")
    print("  %s (%d bytes)" % (pe, pesz))
    print("  %s (%d bytes)" % (elf, elfsz))
    print("  %s" % beh)
    print("These files do nothing to the host; they exist only to be analysed.")


if __name__ == "__main__":
    main()
