#!/usr/bin/env python3
"""strx.py - RedKross C10: extract printable strings from a binary.

Finds ASCII and UTF-16LE strings of a minimum length and prints them with file
offsets, then highlights interesting ones (URLs, IPs, paths, registry keys,
possible API names). Strings are a fast, high-value static indicator. Reads
bytes only.

  python strx.py specimen/rkspecimen.exe
  python strx.py specimen/rkspecimen.exe --min 6
"""
import re
import sys

ASCII_RE = rb"[\x20-\x7e]{%d,}"
INTERESTING = [
    (re.compile(r"https?://[^\s\"']+"), "URL"),
    (re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"), "IPv4"),
    (re.compile(r"[A-Za-z]:\\\\?[\w\\.\- ]+"), "Windows path"),
    (re.compile(r"HK(?:LM|CU|CR|U|CC)\\[\w\\]+"), "registry key"),
    (re.compile(r"\b[A-Za-z_][A-Za-z0-9_]{3,}(?:A|W|Ex)?\b"
                r"(?=.*(?:File|Reg|Virtual|Thread|Socket|Mutex))"), "api-like"),
]


def ascii_strings(data, minlen):
    out = []
    for m in re.finditer(ASCII_RE % minlen, data):
        out.append((m.start(), "A", m.group().decode("latin1")))
    return out


def utf16_strings(data, minlen):
    out = []
    pat = re.compile((rb"(?:[\x20-\x7e]\x00){%d,}" % minlen))
    for m in re.finditer(pat, data):
        s = m.group().decode("utf-16-le", "replace")
        out.append((m.start(), "U", s))
    return out


def classify(s):
    for rx, label in INTERESTING:
        if rx.search(s):
            return label
    return None


def main(argv):
    minlen = 4
    if "--min" in argv:
        i = argv.index("--min")
        minlen = int(argv[i + 1])
        del argv[i:i + 2]
    if len(argv) != 2:
        print("usage: python strx.py <file> [--min N]")
        return 2
    with open(argv[1], "rb") as f:
        data = f.read()
    strings = ascii_strings(data, minlen) + utf16_strings(data, minlen)
    strings.sort()
    print("Strings (min length %d): %s" % (minlen, argv[1]))
    interesting = []
    for off, enc, s in strings:
        label = classify(s)
        tag = "  <= %s" % label if label else ""
        print("  0x%06X [%s] %s%s" % (off, enc, s, tag))
        if label:
            interesting.append((label, s))
    print("  ---")
    print("  %d strings; %d interesting" % (len(strings), len(interesting)))
    if interesting:
        print("  interesting indicators:")
        for label, s in interesting:
            print("    %-13s %s" % (label, s))
    print("Note: strings suggest capability and indicators; confirm meaning in "
          "context. Treat any host/path as a lead, not a confirmed IOC.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
