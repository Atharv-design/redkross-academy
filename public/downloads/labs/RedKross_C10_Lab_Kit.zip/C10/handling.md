# RedKross C10 - Safe malware-handling standard operating procedure (SOP)

This SOP governs how the lab specimens are handled. Although the RedKross
specimens are INERT and benign, you must practise the same discipline you would
use for real malware, because the habits are what keep you safe when a sample is
genuinely dangerous.

## Golden rules
1. Analyse samples only inside a dedicated, isolated analysis environment -
   never on your normal workstation, a production machine, or anything holding
   real data.
2. Treat every unknown sample as live and dangerous until proven otherwise.
3. Only handle samples you are AUTHORISED to handle. Do not download malware
   from the internet onto an unmanaged machine, and do not analyse third-party
   samples without permission and a safe environment.
4. Never let a sample reach a real network. Use an isolated/host-only network
   or simulated internet (a local sink), as the lab's behaviour.py does.
5. Keep analysis notes, hashes and provenance for everything you touch.

## Environment design
- Use a virtual machine with a clean snapshot you can revert to after each run.
- Disconnect from the internet, or use a host-only network with a fake-internet
  simulator; never bridge to production or the real internet.
- Disable shared folders and clipboard sharing during detonation.
- Keep the analysis VM separate from any domain or credential store.

## Sample storage and provenance
- Record md5/sha1/sha256 of every sample (triage.py) before anything else.
- Store samples in a password-protected archive (commonly the password
  `infected`) so they are not executed by accident or scanned/quarantined.
- Note where a sample came from, when, and under what authorisation.

## Lab-specific notes
- The RedKross specimens (specimen/rkspecimen.exe, .elf) are authored in-lab and
  do nothing to the host; even so, run the static tools (which never execute
  the file) first, and use behaviour.py (which sandboxes and uses a loopback
  sink) for the dynamic step.
- The simulator rksim.py writes only inside a throwaway sandbox directory and
  attempts a beacon only to the local sink the harness provides.
- Network indicators in the specimens use documentation ranges
  (RFC 5737: 198.51.100.0/24; RFC 2606: .example) and point at nothing real.

## Legal note (India)
Possessing and analysing malware for legitimate defensive research, within an
authorised environment, is a normal part of security work. Deploying malware,
or accessing or damaging computers you are not authorised to, is an offence
under the Information Technology Act, 2000 (for example ss.43, 43A, 66, 66F).
Keep your work inside systems you own or are authorised to use. This is not
legal advice; follow your organisation's policy and seek advice for specific
situations.
