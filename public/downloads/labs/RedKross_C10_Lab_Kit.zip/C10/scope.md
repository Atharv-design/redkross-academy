# RedKross C10 - Analysis authorisation and scope

Complete this before any analysis. The lab ships it filled for the in-lab
specimen; adapt it for any authorised engagement.

## Authorisation
- Analyst: <your name>
- Authorised by: self (lab owner) / <authorising manager for a real engagement>
- Date/time window: <when analysis is permitted>
- Purpose: defensive malware analysis for learning and detection engineering.

## In scope
- specimen/rkspecimen.exe  (inert PE32+ teaching specimen)
- specimen/rkspecimen.elf  (inert ELF64 teaching specimen)
- rksim.py run ONLY via behaviour.py inside its sandbox
- The analyst's own isolated lab environment.

## Out of scope (hard limits)
- Any machine other than the isolated analysis environment.
- Any production system, real user data, or real credential store.
- The real internet and any real third-party host. The specimen's network
  indicators are documentation ranges and must never be contacted.
- Any third-party or externally sourced malware sample (not provided here and
  not to be introduced without separate written authorisation and a safe VM).

## Rules of engagement
- Static tools first (they never execute the sample); dynamic analysis only via
  the sandboxing harness with a loopback sink.
- Revert the VM snapshot after dynamic runs.
- Record hashes and provenance for everything handled.
- Stop and consult if a sample behaves unexpectedly or appears to attempt real
  network egress.

## Deliverable
- A malware-analysis report (report.py format): classification with confidence
  and limitations, static/dynamic findings, IOCs, detection coverage, and
  defensive recommendations.
