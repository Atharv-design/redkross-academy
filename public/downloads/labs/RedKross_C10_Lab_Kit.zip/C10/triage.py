#!/usr/bin/env python3
"""triage.py - RedKross C10: first-look triage of a specimen.

Computes cryptographic hashes, identifies the file type by magic bytes, and
measures Shannon entropy (a packing indicator). Reads bytes only; never runs
the file. Hashing a sample is the first step of provenance and lets you look it
up in a threat-intel service you are authorised to use.

  python triage.py specimen/rkspecimen.exe
"""
import hashlib
import math
import os
import sys

MAGIC = [
    (b"MZ", "PE/DOS executable (Windows)"),
    (b"\x7fELF", "ELF executable (Linux/Unix)"),
    (b"\xca\xfe\xba\xbe", "Mach-O fat / Java class"),
    (b"PK\x03\x04", "ZIP / Office / JAR archive"),
    (b"%PDF", "PDF document"),
    (b"\xd0\xcf\x11\xe0", "OLE / legacy Office document"),
    (b"\x1f\x8b", "gzip compressed"),
    (b"Rar!", "RAR archive"),
]


def shannon_entropy(b):
    if not b:
        return 0.0
    counts = [0] * 256
    for x in b:
        counts[x] += 1
    n = len(b)
    e = 0.0
    for c in counts:
        if c:
            p = c / n
            e -= p * math.log2(p)
    return e


def identify(b):
    for sig, desc in MAGIC:
        if b.startswith(sig):
            return desc
    return "unknown (no known magic bytes)"


def main(argv):
    if len(argv) != 2:
        print("usage: python triage.py <file>")
        return 2
    path = argv[1]
    with open(path, "rb") as f:
        data = f.read()
    ent = shannon_entropy(data)
    print("Triage: %s" % path)
    print("  size        : %d bytes" % len(data))
    print("  type (magic): %s" % identify(data))
    print("  md5         : %s" % hashlib.md5(data).hexdigest())
    print("  sha1        : %s" % hashlib.sha1(data).hexdigest())
    print("  sha256      : %s" % hashlib.sha256(data).hexdigest())
    print("  entropy     : %.3f bits/byte  (%s)" % (
        ent,
        "high - possibly packed/encrypted/compressed" if ent >= 7.2 else
        "moderate" if ent >= 6.0 else "low - likely plain code/data"))
    print("Next: record these hashes as provenance; look the sample up only in "
          "services you are authorised to use; do not upload third-party or "
          "sensitive samples to public services without approval.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
