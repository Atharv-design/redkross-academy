The inert teaching specimens (rkspecimen.exe / rkspecimen.elf) are not shipped in the download.
Rebuild them locally, offline, with: python make_specimen.py
