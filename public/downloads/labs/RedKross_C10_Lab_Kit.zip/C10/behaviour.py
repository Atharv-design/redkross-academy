#!/usr/bin/env python3
"""behaviour.py - RedKross C10 dynamic analysis harness (SAFE).

Demonstrates controlled dynamic analysis: it builds a throwaway SANDBOX
directory, stands up a local network SINK on 127.0.0.1 (so any "beacon" is
captured on loopback and nothing leaves the host), runs the INERT simulator
rksim.py inside the sandbox, and summarises the observed behaviour. This models
how a real analyst detonates a sample inside an isolated VM with simulated
internet - but here the sample is our harmless simulator.

  python behaviour.py            # run the simulator and summarise
  python behaviour.py --show     # just pretty-print data/behaviour_run.json

IMPORTANT: this harness is for the lab's own benign simulator. NEVER point it at
real malware on a normal machine; real dynamic analysis needs a dedicated,
isolated, snapshotted VM with no path to production or the internet.
"""
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading

HERE = os.path.dirname(os.path.abspath(__file__))


def start_sink():
    """Bind a loopback TCP sink; return (host, port, stop_fn, received_list)."""
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    srv.settimeout(3.0)
    host, port = srv.getsockname()
    received = []

    def serve():
        try:
            conn, _ = srv.accept()
            conn.settimeout(1.0)
            data = conn.recv(256)
            if data:
                received.append(data)
            conn.close()
        except OSError:
            pass
        finally:
            srv.close()

    t = threading.Thread(target=serve, daemon=True)
    t.start()
    return host, port, t, received


def summarise(events, received):
    print("Dynamic analysis summary (sandboxed, loopback-only):")
    buckets = {}
    for e in events:
        buckets.setdefault(e["type"], []).append(e)
    order = ["process", "mutex", "file", "registry_sim", "network"]
    for typ in order + [k for k in buckets if k not in order]:
        if typ not in buckets:
            continue
        print("  [%s]" % typ)
        for e in buckets[typ]:
            print("    %2d %-16s %s" % (e["seq"], e["action"], e["detail"]))
    print("  sink captured   : %s" % (
        received[0].decode("latin1").strip() if received else
        "nothing (beacon not delivered)"))
    # Behavioural verdict (benign simulator, but we describe the PATTERN)
    patterns = []
    if any(e["type"] == "file" and e["action"] == "write" for e in events):
        patterns.append("drops a file")
    if any(e["type"] == "registry_sim" for e in events):
        patterns.append("writes an autorun key (persistence pattern)")
    if any(e["type"] == "network" for e in events):
        patterns.append("attempts network beacon")
    if any(e["type"] == "mutex" for e in events):
        patterns.append("creates a single-instance mutex")
    print("  observed pattern: %s" % "; ".join(patterns))
    print("  verdict         : benign simulator exhibiting a dropper/beacon "
          "PATTERN for teaching; no harm done (all activity in sandbox).")


def main(argv):
    if "--show" in argv:
        with open(os.path.join(HERE, "data", "behaviour_run.json")) as f:
            log = json.load(f)
        summarise(log["events"], [])
        return 0

    with tempfile.TemporaryDirectory(prefix="rk_c10_sandbox_") as sb:
        host, port, t, received = start_sink()
        out = os.path.join(sb, "events.json")
        rc = subprocess.run(
            [sys.executable, os.path.join(HERE, "rksim.py"),
             "--sandbox", sb, "--sink-host", host,
             "--sink-port", str(port), "--out", out],
            capture_output=True, text=True)
        t.join(timeout=3.0)
        if rc.returncode != 0:
            print("simulator error:", rc.stderr, file=sys.stderr)
            return 1
        with open(out) as f:
            events = json.load(f)
        summarise(events, received)
        # Persist a copy of this run for the report/record
        with open(os.path.join(HERE, "data", "behaviour_live.json"), "w") as f:
            json.dump({"events": events,
                       "sink_received": received[0].decode("latin1")
                       if received else None}, f, indent=2)
    print("Sandbox auto-removed. A copy of this run saved to "
          "data/behaviour_live.json.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
