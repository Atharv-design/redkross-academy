#!/usr/bin/env python3
"""rksim.py - RedKross C10: an INERT benign simulator for dynamic analysis.

This program imitates a dropper/beacon pattern so learners can observe malware-
like behaviour SAFELY. It is not malware and does nothing harmful:
  - every file it writes goes under the sandbox directory passed as --sandbox;
  - "persistence" is written to a sandbox registry.json, not the real registry;
  - the "beacon" is a single connection attempt to a caller-supplied sink
    address (the harness points it at 127.0.0.1); nothing leaves the host and
    no payload is sent if the sink refuses.
It must be launched by behaviour.py, which creates the sandbox and the local
sink. Do not run it against anything outside the sandbox.

  (invoked by behaviour.py; not meant to be run directly)
"""
import argparse
import json
import os
import socket
import sys

MUTEX = "RK-LAB-SPECIMEN-7F3A"
C2_HOST = "198.51.100.23"      # RFC 5737 documentation range (never routed)
C2_PORT = 8443


def log(events, typ, action, detail):
    events.append({"seq": len(events) + 1, "type": typ,
                   "action": action, "detail": detail})


def run(sandbox, sink_host, sink_port):
    events = []
    log(events, "process", "start", "rksim.py launched in sandbox")

    # "mutex" - just a marker file; real malware would use a named kernel object
    mtx = os.path.join(sandbox, "mutex_%s.lock" % MUTEX)
    with open(mtx, "w") as f:
        f.write("held")
    log(events, "mutex", "create", MUTEX)

    # "drop" a marker file under a sandboxed ProgramData path
    drop_dir = os.path.join(sandbox, "ProgramData", "rk_lab")
    os.makedirs(drop_dir, exist_ok=True)
    drop = os.path.join(drop_dir, "marker.bin")
    with open(drop, "wb") as f:
        f.write(b"RKLABMARKER\x00")
    log(events, "file", "write", "%s (12 bytes)" % drop)

    # "persistence" - written to a sandbox registry.json, NOT the real registry
    reg_path = os.path.join(sandbox, "registry.json")
    reg = {}
    if os.path.exists(reg_path):
        with open(reg_path) as f:
            reg = json.load(f)
    reg.setdefault("HKCU\\Software\\rk_lab", {})["Run"] = "rksim"
    with open(reg_path, "w") as f:
        json.dump(reg, f, indent=2)
    log(events, "registry_sim", "set",
        "HKCU\\Software\\rk_lab\\Run = rksim (sandbox registry.json)")

    # "beacon" - a single connect attempt to the harness sink on loopback.
    # The intended C2 (documentation range) is only logged, never contacted.
    log(events, "network", "intended_c2",
        "config target %s:%d (documentation range; not contacted)"
        % (C2_HOST, C2_PORT))
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1.0)
        s.connect((sink_host, sink_port))
        s.sendall(b"BEACON rk-lab/1.0\n")
        s.close()
        log(events, "network", "beacon_to_sink",
            "sent benign beacon to local sink %s:%d" % (sink_host, sink_port))
    except OSError as exc:
        log(events, "network", "beacon_failed",
            "no sink available (%s); nothing sent" % exc.__class__.__name__)

    log(events, "process", "exit", "exit 0 (no Sleep in sim)")
    return events


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument("--sandbox", required=True)
    ap.add_argument("--sink-host", default="127.0.0.1")
    ap.add_argument("--sink-port", type=int, required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args(argv[1:])
    sb = os.path.abspath(args.sandbox)
    if not os.path.isdir(sb):
        print("sandbox dir missing", file=sys.stderr)
        return 2
    events = run(sb, args.sink_host, args.sink_port)
    with open(args.out, "w") as f:
        json.dump(events, f, indent=2)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
