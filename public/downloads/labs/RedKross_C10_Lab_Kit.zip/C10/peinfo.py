#!/usr/bin/env python3
"""peinfo.py - RedKross C10 static analysis: parse a PE file's structure.

Reads a PE (Portable Executable) header, section table and import directory and
prints them. Pure stdlib struct parsing; it never executes the file. Use it on
the lab's inert specimen or on any file you are AUTHORISED to analyse.

  python peinfo.py specimen/rkspecimen.exe

Safe-handling reminder: analyse unknown binaries only inside an isolated lab
(see handling.md). This tool only reads bytes; it does not run anything.
"""
import struct
import sys


def rva_to_off(rva, sections):
    for s in sections:
        if s["vrva"] <= rva < s["vrva"] + max(s["rawsize"], s["vsize"]):
            return s["rawoff"] + (rva - s["vrva"])
    return None


def read_cstr(data, off):
    end = data.find(b"\x00", off)
    return data[off:end].decode("latin1", "replace")


def parse(path):
    with open(path, "rb") as f:
        data = f.read()
    if data[:2] != b"MZ":
        raise ValueError("not a PE (no MZ magic)")
    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    if data[e_lfanew:e_lfanew + 4] != b"PE\x00\x00":
        raise ValueError("not a PE (no PE signature)")
    coff_off = e_lfanew + 4
    (machine, num_sect, timestamp, _p, _n, opt_size,
     characteristics) = struct.unpack_from("<HHIIIHH", data, coff_off)
    opt_off = coff_off + 20
    magic = struct.unpack_from("<H", data, opt_off)[0]
    pe_plus = magic == 0x020B
    # AddressOfEntryPoint at opt+16; ImageBase at opt+24 (PE32+) / +28 (PE32)
    entry = struct.unpack_from("<I", data, opt_off + 16)[0]
    if pe_plus:
        image_base = struct.unpack_from("<Q", data, opt_off + 24)[0]
        ddir_off = opt_off + 112
    else:
        image_base = struct.unpack_from("<I", data, opt_off + 28)[0]
        ddir_off = opt_off + 96
    num_dd = struct.unpack_from("<I", data, ddir_off - 4)[0]
    data_dirs = []
    for i in range(num_dd):
        rva, size = struct.unpack_from("<II", data, ddir_off + i * 8)
        data_dirs.append((rva, size))

    sect_off = opt_off + opt_size
    sections = []
    for i in range(num_sect):
        o = sect_off + i * 40
        name = data[o:o + 8].rstrip(b"\x00").decode("latin1", "replace")
        vsize, vrva, rawsize, rawoff = struct.unpack_from("<IIII", data, o + 8)
        chars = struct.unpack_from("<I", data, o + 36)[0]
        sections.append({"name": name, "vsize": vsize, "vrva": vrva,
                         "rawsize": rawsize, "rawoff": rawoff, "chars": chars})

    imports = parse_imports(data, data_dirs, sections)
    return {
        "machine": machine, "pe_plus": pe_plus, "timestamp": timestamp,
        "characteristics": characteristics, "entry": entry,
        "image_base": image_base, "sections": sections, "imports": imports,
    }


def parse_imports(data, data_dirs, sections):
    out = {}
    if len(data_dirs) < 2:
        return out
    imp_rva, imp_size = data_dirs[1]
    if not imp_rva:
        return out
    off = rva_to_off(imp_rva, sections)
    if off is None:
        return out
    while True:
        desc = struct.unpack_from("<IIIII", data, off)
        ilt, _ts, _fc, name_rva, _iat = desc
        if ilt == 0 and name_rva == 0:
            break
        dll = read_cstr(data, rva_to_off(name_rva, sections))
        funcs = []
        thunk_off = rva_to_off(ilt, sections)
        while thunk_off is not None:
            val = struct.unpack_from("<Q", data, thunk_off)[0]
            if val == 0:
                break
            if val & (1 << 63):         # import by ordinal
                funcs.append("Ordinal#%d" % (val & 0xFFFF))
            else:
                nm_off = rva_to_off(val & 0x7FFFFFFF, sections)
                funcs.append(read_cstr(data, nm_off + 2))  # skip 2-byte hint
            thunk_off += 8
        out[dll] = funcs
        off += 20
    return out


SUSPICIOUS = {
    "VirtualAlloc": "allocates executable memory (common in unpackers/loaders)",
    "WriteProcessMemory": "writes into another process (injection)",
    "CreateRemoteThread": "runs code in another process (injection)",
    "CreateMutexA": "single-instance mutex (often a specimen fingerprint)",
    "RegSetValueExA": "writes a registry value (possible persistence)",
    "connect": "opens a network connection (possible C2)",
    "send": "sends network data (possible C2/exfil)",
    "WSAStartup": "initialises Winsock (network capability)",
}


def main(argv):
    if len(argv) != 2:
        print("usage: python peinfo.py <file.exe>")
        return 2
    info = parse(argv[1])
    print("PE structure: %s" % argv[1])
    print("  machine        : 0x%04X (%s)" % (
        info["machine"], "x86-64" if info["machine"] == 0x8664 else
        "x86" if info["machine"] == 0x14C else "other"))
    print("  format         : %s" % ("PE32+" if info["pe_plus"] else "PE32"))
    print("  image base     : 0x%X" % info["image_base"])
    print("  entry RVA      : 0x%X" % info["entry"])
    print("  link timestamp : %d%s" % (
        info["timestamp"], "  (zeroed - common in crafted/teaching files)"
        if info["timestamp"] == 0 else ""))
    print("  sections       :")
    for s in info["sections"]:
        flags = []
        if s["chars"] & 0x20000000:
            flags.append("X")
        if s["chars"] & 0x40000000:
            flags.append("R")
        if s["chars"] & 0x80000000:
            flags.append("W")
        print("    %-8s vrva=0x%-6X vsize=0x%-5X rawsize=0x%-5X [%s]" % (
            s["name"], s["vrva"], s["vsize"], s["rawsize"], "".join(flags)))
    print("  imports        :")
    flagged = []
    for dll, funcs in info["imports"].items():
        print("    %s" % dll)
        for fn in funcs:
            note = SUSPICIOUS.get(fn)
            print("      %-20s %s" % (fn, "<- " + note if note else ""))
            if note:
                flagged.append(fn)
    print("  capability hints from imports: %s" % (
        ", ".join(sorted(set(flagged))) if flagged else "none flagged"))
    print("Note: imports show CAPABILITY, not proof of behaviour. Confirm with "
          "dynamic analysis. This tool did not execute the file.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
