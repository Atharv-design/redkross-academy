#!/usr/bin/env python3
"""elfinfo.py - RedKross C10 static analysis: parse an ELF file's structure.

Reads the ELF header and program headers and reports architecture, type, entry
point and loadable segments. Pure stdlib; never executes the file.

  python elfinfo.py specimen/rkspecimen.elf
"""
import struct
import sys

ET = {0: "NONE", 1: "REL (object)", 2: "EXEC (executable)",
      3: "DYN (shared/PIE)", 4: "CORE"}
EM = {0x3E: "x86-64", 0x03: "x86", 0xB7: "AArch64", 0x28: "ARM"}
PT = {0: "NULL", 1: "LOAD", 2: "DYNAMIC", 3: "INTERP", 4: "NOTE",
      6: "PHDR", 7: "TLS"}


def parse(path):
    with open(path, "rb") as f:
        data = f.read()
    if data[:4] != b"\x7fELF":
        raise ValueError("not an ELF (no magic)")
    ei_class = data[4]          # 1=32-bit, 2=64-bit
    ei_data = data[5]           # 1=LE, 2=BE
    if ei_class != 2:
        raise ValueError("this teaching parser handles ELF64 only")
    (e_type, e_machine, e_version, e_entry, e_phoff, e_shoff, e_flags,
     e_ehsize, e_phentsize, e_phnum, e_shentsize, e_shnum,
     e_shstrndx) = struct.unpack_from("<HHIQQQIHHHHHH", data, 16)
    phdrs = []
    for i in range(e_phnum):
        o = e_phoff + i * e_phentsize
        (p_type, p_flags, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz,
         p_align) = struct.unpack_from("<IIQQQQQQ", data, o)
        phdrs.append({"type": p_type, "flags": p_flags, "vaddr": p_vaddr,
                      "filesz": p_filesz, "memsz": p_memsz})
    return {"ei_data": ei_data, "e_type": e_type, "e_machine": e_machine,
            "e_entry": e_entry, "phdrs": phdrs}


def main(argv):
    if len(argv) != 2:
        print("usage: python elfinfo.py <file>")
        return 2
    info = parse(argv[1])
    print("ELF structure: %s" % argv[1])
    print("  class       : ELF64")
    print("  endianness  : %s" % ("little" if info["ei_data"] == 1 else "big"))
    print("  type        : %s" % ET.get(info["e_type"], info["e_type"]))
    print("  machine     : %s" % EM.get(info["e_machine"], hex(info["e_machine"])))
    print("  entry       : 0x%X" % info["e_entry"])
    print("  segments    :")
    for p in info["phdrs"]:
        fl = ("R" if p["flags"] & 4 else "-") + \
             ("W" if p["flags"] & 2 else "-") + \
             ("X" if p["flags"] & 1 else "-")
        print("    %-8s vaddr=0x%-8X filesz=0x%-5X memsz=0x%-5X [%s]" % (
            PT.get(p["type"], p["type"]), p["vaddr"], p["filesz"],
            p["memsz"], fl))
    print("Note: this tool only reads the ELF structure; it does not run it.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
