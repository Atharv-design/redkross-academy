#!/bin/sh
# C21 Module 7 lab: sign, verify, tamper and attest with cosign against a
# LOCAL lab registry (rk-registry on the rk-supply Docker network, published
# on 127.0.0.1:5000). Keys and password are lab-only; never reuse them.
# Transparency-log upload is disabled because the lab is offline; see the
# module text for why production signing should use a transparency log.
export MSYS_NO_PATHCONV=1
W="$(pwd -W 2>/dev/null || pwd)"
COS="docker run --rm --network rk-supply -e COSIGN_PASSWORD=rk-lab-only -v $W:/work -w /work gcr.io/projectsigstore/cosign:latest"
R=rk-registry:5000/kestrel-api
DIG=$(cat digest_1.0.0.txt)
step() { echo; echo "### $*"; }

step "0. Publish the reviewed build as 1.0.0 (its digest was signed earlier)"
docker tag kestrel-api:good13 localhost:5000/kestrel-api:1.0.0
docker push -q localhost:5000/kestrel-api:1.0.0

step "1. Verify the signed release by tag (expected: success)"
$COS verify --key keys/rk-lab.pub --insecure-ignore-tlog=true --allow-http-registry $R:1.0.0 >out.txt 2>err.txt
rc=$?; cat err.txt; echo "exit=$rc; signature payloads returned: $(wc -l < out.txt)"

step "2. Verify the same digest with a different public key (expected: failure)"
[ -f keys/other.pub ] || $COS generate-key-pair --output-key-prefix keys/other >/dev/null 2>&1
$COS verify --key keys/other.pub --insecure-ignore-tlog=true --allow-http-registry $R@$DIG >/dev/null 2>err.txt
echo "exit=$? : $(grep -m1 '^Error:' err.txt)"

step "3. An unauthorised rebuild is pushed under the same tag 1.0.0"
docker build -q -f Dockerfile.tampered -t localhost:5000/kestrel-api:1.0.0 . >/dev/null
docker push -q localhost:5000/kestrel-api:1.0.0 >/dev/null
NEW=$(docker buildx imagetools inspect localhost:5000/kestrel-api:1.0.0 --format '{{json .Manifest}}' \
  | python -c "import json,sys;print(json.load(sys.stdin)['digest'])")
echo "tag 1.0.0 now resolves to $NEW"
echo "signed digest was           $DIG"

step "4. Verify by tag again (expected: failure - the new digest is unsigned)"
$COS verify --key keys/rk-lab.pub --insecure-ignore-tlog=true --allow-http-registry $R:1.0.0 >/dev/null 2>err.txt
echo "exit=$? : $(grep -m1 '^Error:' err.txt)"

step "5. Verify the original digest (expected: success - digests are immutable)"
$COS verify --key keys/rk-lab.pub --insecure-ignore-tlog=true --allow-http-registry $R@$DIG >/dev/null 2>&1
echo "exit=$?"

step "6. Attach the SBOM as a signed attestation and verify it"
cp ../images/sbom_good13.cdx.json sbom.cdx.json
$COS attest --yes --key keys/rk-lab.key --use-signing-config=false --tlog-upload=false --allow-http-registry \
  --type cyclonedx --predicate sbom.cdx.json $R@$DIG 2>&1 | grep -v -i deprecated | tail -1
$COS verify-attestation --key keys/rk-lab.pub --insecure-ignore-tlog=true --allow-http-registry \
  --type cyclonedx $R@$DIG 2>/dev/null | python -c "
import base64,json,sys
for line in sys.stdin:
    env=json.loads(line); st=json.loads(base64.b64decode(env['payload']))
    print('attestation predicateType:', st['predicateType'])
    print('subject digest           :', st['subject'][0]['digest'])
    print('components in SBOM        :', len(st['predicate'].get('components', [])))"
echo "exit=$?"
rm -f err.txt out.txt
