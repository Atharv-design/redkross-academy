"""Collect security evidence from a lab cluster you administer (C21 M08).

Usage: python evidence.py --node rk-k3s-hard --api https://127.0.0.1:16444 --out DIR

Each control is checked by an observable test, not by reading a setting
alone where a test is possible (for example, Pod Security is checked by a
server-side dry run of a privileged pod in a temporary namespace). The
report and a JSON evidence file (with a SHA-256 of the report) go to DIR.
Requires kubectl (KUBECONFIG set), docker (for the k3s node checks) and the
other C21 tools at their lab paths.
"""
import datetime
import hashlib
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "iac"))
import rk_policy  # noqa: E402

SYSTEM_NS = {"kube-system", "kube-public", "kube-node-lease"}
PRIV_POD = {"apiVersion": "v1", "kind": "Pod", "metadata": {"name": "evidence-probe"},
            "spec": {"containers": [{"name": "c", "image": "docker.io/curlimages/curl:8.17.0",
                                     "securityContext": {"privileged": True}}]}}


def sh(cmd, inp=None):
    r = subprocess.run(cmd, input=inp, capture_output=True, text=True)
    return r.returncode, (r.stdout + r.stderr).strip()


def kjson(*args):
    return json.loads(sh(["kubectl", *args, "-o", "json"])[1])


def app_namespaces():
    return [n["metadata"]["name"] for n in kjson("get", "ns")["items"] if n["metadata"]["name"] not in SYSTEM_NS]


def c01_anonymous(a):
    _, code = sh(["curl", "-sk", "-o", os.devnull, "-w", "%{http_code}", a.api + "/api/v1/namespaces"])
    return code == "401", f"unauthenticated GET /api/v1/namespaces -> HTTP {code}"


def c02_encryption(a):
    _, out = sh(["docker", "exec", a.node, "k3s", "secrets-encrypt", "status"])
    line = out.splitlines()[0] if out else "no output"
    return "Enabled" in line, line


def c03_audit(a):
    _, out = sh(["docker", "inspect", "--format", "{{json .Args}}", a.node])
    on = "audit-log-path" in out and "audit-policy-file" in out
    return on, "API server started with audit policy and log path" if on else "no audit-log-path argument"


def c04_pod_security_default(a):
    ns = "evidence-probe-ns"
    sh(["kubectl", "create", "ns", ns])
    rc, out = sh(["kubectl", "-n", ns, "create", "--dry-run=server", "-f", "-"], json.dumps(PRIV_POD))
    sh(["kubectl", "delete", "ns", ns, "--wait=false"])
    ok = rc != 0 and "PodSecurity" in out
    return ok, ("privileged pod in an unlabelled namespace denied by PodSecurity" if ok
                else "privileged pod in an unlabelled namespace accepted (no cluster-wide default)")


def c05_namespace_labels(a):
    weak = []
    for n in kjson("get", "ns")["items"]:
        name = n["metadata"]["name"]
        if name in SYSTEM_NS or name == "default" or n.get("status", {}).get("phase") == "Terminating":
            continue  # the C04 probe namespace is still being deleted at this point
        level = n["metadata"].get("labels", {}).get("pod-security.kubernetes.io/enforce", "none")
        if level != "restricted":
            weak.append(f"{name}={level}")
    return not weak, "all workload namespaces enforce restricted" if not weak else "below restricted: " + ", ".join(weak)


def c06_default_deny(a):
    missing = []
    for ns in app_namespaces():
        if not kjson("get", "pods", "-n", ns)["items"]:
            continue
        pols = kjson("get", "networkpolicy", "-n", ns)["items"]
        if not any(p["spec"].get("podSelector") in ({}, None) and "Ingress" in p["spec"].get("policyTypes", [])
                   and not p["spec"].get("ingress") for p in pols):
            missing.append(ns)
    return not missing, "default-deny present in every namespace with pods" if not missing else \
        "no default-deny in: " + ", ".join(missing)


def c07_rbac(a):
    rc, out = sh([sys.executable, os.path.join(HERE, "..", "k8s", "rbac_review.py"), "--accept",
                  os.path.join(HERE, "..", "k8s", "rbac_accepted.txt")])
    last = out.splitlines()[-1]
    return rc == 0, last


def c08_admission(a):
    bound = {b["spec"]["policyName"] for b in kjson("get", "validatingadmissionpolicybindings")["items"]}
    need = {"rk-image-policy", "rk-digest-policy"}
    return need <= bound, f"bound policies: {', '.join(sorted(bound)) or 'none'}"


def c09_workloads(a):
    bad = []
    for ns in app_namespaces():
        for kind in ("deployments", "pods"):
            for obj in kjson("get", kind, "-n", ns)["items"]:
                if kind == "pods" and obj["metadata"].get("ownerReferences"):
                    continue
                obj["kind"] = "Deployment" if kind == "deployments" else "Pod"
                ps = rk_policy.pod_spec(obj)
                ids = [rid for rid, eff, fn in rk_policy.RULES if eff == "DENY" and list(fn(ps))]
                if ids:
                    bad.append(f"{ns}/{obj['metadata']['name']}({','.join(ids)})")
    return not bad, "all live workloads pass rk_policy DENY rules" if not bad else "violations: " + "; ".join(bad)


def c10_digests(a):
    tagged = []
    for ns in app_namespaces():
        for p in kjson("get", "pods", "-n", ns)["items"]:
            for c in p["spec"]["containers"]:
                if "kestrel-api" in c["image"] and "@sha256:" not in c["image"]:
                    tagged.append(f"{ns}/{p['metadata']['name']}")
    return not tagged, "first-party images run by digest" if not tagged else "tag references: " + ", ".join(tagged)


CONTROLS = [("C01", "API rejects anonymous requests", c01_anonymous),
            ("C02", "Secrets encrypted at rest", c02_encryption),
            ("C03", "API audit logging enabled", c03_audit),
            ("C04", "Cluster-wide Pod Security default", c04_pod_security_default),
            ("C05", "Workload namespaces enforce restricted", c05_namespace_labels),
            ("C06", "Default-deny NetworkPolicy", c06_default_deny),
            ("C07", "No open cluster-wide RBAC risk", c07_rbac),
            ("C08", "Admission policies bound", c08_admission),
            ("C09", "Live workloads pass policy", c09_workloads),
            ("C10", "First-party images pinned by digest", c10_digests)]


class Args:
    def __init__(self, argv):
        self.node = argv[argv.index("--node") + 1]
        self.api = argv[argv.index("--api") + 1]
        self.out = argv[argv.index("--out") + 1]


def main(argv):
    a = Args(argv)
    os.makedirs(a.out, exist_ok=True)
    now = datetime.datetime.now(datetime.UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    _, ver = sh(["kubectl", "version", "-o", "json"])
    server = json.loads(ver)["serverVersion"]["gitVersion"]
    lines = [f"Cluster security evidence - node {a.node}, API {a.api}, server {server}", f"Collected {now}", ""]
    results = []
    for cid, title, fn in CONTROLS:
        ok, ev = fn(a)
        results.append({"id": cid, "control": title, "pass": ok, "evidence": ev})
        lines.append(f"{cid} {'PASS' if ok else 'FAIL'}  {title}")
        lines.append(f"      {ev}")
    score = sum(r["pass"] for r in results)
    lines += ["", f"Score: {score}/{len(results)} controls passed"]
    report = "\n".join(lines) + "\n"
    open(os.path.join(a.out, "evidence_report.txt"), "w", encoding="utf-8").write(report)
    meta = {"collected": now, "node": a.node, "server": server, "results": results,
            "report_sha256": hashlib.sha256(report.encode()).hexdigest()}
    json.dump(meta, open(os.path.join(a.out, "evidence.json"), "w", encoding="utf-8"), indent=2)
    print(report, end="")
    print(f"report sha256 {meta['report_sha256']}")
    return 0 if score == len(results) else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
