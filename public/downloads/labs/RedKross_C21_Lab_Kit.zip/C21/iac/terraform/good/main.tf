# C21 Module 6: remediated Terraform for static analysis ONLY. Never apply.
terraform {
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.0" }
  }
}

resource "aws_kms_key" "statements" {
  description         = "kestrel statements bucket key"
  enable_key_rotation = true
}

resource "aws_s3_bucket" "statements" {
  bucket = "kestrel-pay-statements-lab"
}

resource "aws_s3_bucket_public_access_block" "statements" {
  bucket                  = aws_s3_bucket.statements.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_server_side_encryption_configuration" "statements" {
  bucket = aws_s3_bucket.statements.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.statements.arn
    }
  }
}

resource "aws_s3_bucket_versioning" "statements" {
  bucket = aws_s3_bucket.statements.id
  versioning_configuration { status = "Enabled" }
}

resource "aws_s3_bucket_logging" "statements" {
  bucket        = aws_s3_bucket.statements.id
  target_bucket = "kestrel-pay-access-logs-lab"
  target_prefix = "statements/"
}

resource "aws_security_group" "bastion" {
  name        = "kestrel-bastion"
  description = "bastion access from the corporate VPN range only"
  ingress {
    description = "SSH from corporate VPN"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["10.50.0.0/16"]
  }
  egress {
    description = "HTTPS to internal package mirror"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["10.60.0.0/24"]
  }
}

resource "aws_eks_cluster" "payments" {
  name                      = "kestrel-payments"
  role_arn                  = "arn:aws:iam::111122223333:role/kestrel-eks"
  enabled_cluster_log_types = ["api", "audit", "authenticator"]
  vpc_config {
    subnet_ids              = ["subnet-0aaa", "subnet-0bbb"]
    endpoint_public_access  = false
    endpoint_private_access = true
  }
  encryption_config {
    resources = ["secrets"]
    provider { key_arn = aws_kms_key.statements.arn }
  }
}

resource "aws_iam_policy" "ci" {
  name = "kestrel-ci"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["ecr:BatchGetImage", "ecr:GetDownloadUrlForLayer", "ecr:PutImage"]
      Resource = "arn:aws:ecr:ap-south-1:111122223333:repository/kestrel-api"
    }]
  })
}
