# C21 Module 6: deliberately weak Terraform for static analysis ONLY.
# Never apply. Names are fictional ("Kestrel Pay").
terraform {
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.0" }
  }
}

resource "aws_s3_bucket" "statements" {
  bucket = "kestrel-pay-statements-lab"
}

resource "aws_security_group" "bastion" {
  name        = "kestrel-bastion"
  description = "bastion access"
  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_eks_cluster" "payments" {
  name     = "kestrel-payments"
  role_arn = "arn:aws:iam::111122223333:role/kestrel-eks"
  vpc_config {
    subnet_ids             = ["subnet-0aaa", "subnet-0bbb"]
    endpoint_public_access = true
  }
}

resource "aws_iam_policy" "ci" {
  name = "kestrel-ci"
  policy = jsonencode({
    Version   = "2012-10-17"
    Statement = [{ Effect = "Allow", Action = "*", Resource = "*" }]
  })
}
