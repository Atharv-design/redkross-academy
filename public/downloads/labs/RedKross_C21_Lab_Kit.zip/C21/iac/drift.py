"""Configuration drift between Git-declared manifests and a live namespace.

Usage: python drift.py NAMESPACE MANIFEST [MANIFEST ...]

Reports three kinds of drift for namespaced objects of the kinds below:
  CHANGED    a field declared in Git has a different live value
  MISSING    declared in Git but absent from the cluster
  UNMANAGED  present in the cluster but not declared in Git
Only fields that Git declares are compared, because the API server adds
defaults (that is the same idea as a server-side "kubectl diff").
Exit code 1 if any drift is found.
"""
import json
import subprocess
import sys

import yaml

KINDS = {"Deployment": "deployments.apps", "Service": "services", "ServiceAccount": "serviceaccounts",
         "Role": "roles.rbac.authorization.k8s.io", "RoleBinding": "rolebindings.rbac.authorization.k8s.io",
         "NetworkPolicy": "networkpolicies.networking.k8s.io", "Pod": "pods"}
IGNORE_UNMANAGED = {("ServiceAccount", "default")}


def leaves(obj, path=()):
    """Yield (path tuple, value); tuples keep keys such as 'kubernetes.io/x.y' intact."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from leaves(v, path + (k,))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from leaves(v, path + (i,))
    else:
        yield path, obj


def get_path(obj, path):
    cur = obj
    for part in path:
        if isinstance(part, int):
            if not isinstance(cur, list) or part >= len(cur):
                return "<absent>"
        elif not isinstance(cur, dict) or part not in cur:
            return "<absent>"
        cur = cur[part]
    return cur


def show(path):
    return "".join(f"[{p}]" if isinstance(p, int) else (f".{p}" if i else p) for i, p in enumerate(path))


def live_objects(ns):
    out = {}
    for kind, res in KINDS.items():
        data = json.loads(subprocess.run(["kubectl", "get", res, "-n", ns, "-o", "json"],
                                         capture_output=True, text=True, check=True).stdout)
        for it in data["items"]:
            if kind == "Pod" and it["metadata"].get("ownerReferences"):
                continue  # managed by a controller; compare the controller instead
            out[(kind, it["metadata"]["name"])] = it
    return out


def main(argv):
    ns, manifests = argv[0], argv[1:]
    desired = {}
    for m in manifests:
        for doc in yaml.safe_load_all(open(m, encoding="utf-8")):
            if doc and doc.get("kind") in KINDS and doc.get("metadata", {}).get("namespace") == ns:
                desired[(doc["kind"], doc["metadata"]["name"])] = doc
    live = live_objects(ns)
    drift = 0
    for key, doc in sorted(desired.items()):
        if key not in live:
            print(f"MISSING    {key[0]}/{key[1]}")
            drift += 1
            continue
        for path, want in leaves({k: v for k, v in doc.items() if k in ("spec", "rules", "subjects",
                                                                        "roleRef", "automountServiceAccountToken")}):
            have = get_path(live[key], path)
            if have != want and not (isinstance(want, int) and str(have) == str(want)):
                print(f"CHANGED    {key[0]}/{key[1]}  {show(path)}: git={want!r} live={have!r}")
                drift += 1
    for key in sorted(set(live) - set(desired)):
        if key not in IGNORE_UNMANAGED:
            print(f"UNMANAGED  {key[0]}/{key[1]}")
            drift += 1
    print(f"{len(desired)} declared objects, {len(live)} live objects compared; drift items: {drift}")
    return 1 if drift else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
