"""Custom check: IAM policy statements that allow every action (C21 M06).

Usage: python tf_iam_wildcard.py DIR [DIR ...]   (exit 1 on a finding)
A text-level check written because the scanner used in the lab reported
nothing for this pattern. Limitation: it reads .tf text, so a policy built
from variables or data sources is not seen; production teams evaluate the
JSON output of "terraform show -json plan" instead.
"""
import glob
import os
import re
import sys

PAT = re.compile(r'"?Action"?\s*[=:]\s*(\[\s*)?"(\*|[a-z0-9-]+:\*)"', re.I)

found = 0
for d in sys.argv[1:]:
    for f in sorted(glob.glob(os.path.join(d, "*.tf"))):
        for n, line in enumerate(open(f, encoding="utf-8"), 1):
            m = PAT.search(line)
            if m:
                found += 1
                print(f"{f}:{n}: IAM statement allows {m.group(2)!r} - list the actions the role needs")
print(f"{found} finding(s)")
sys.exit(1 if found else 0)
