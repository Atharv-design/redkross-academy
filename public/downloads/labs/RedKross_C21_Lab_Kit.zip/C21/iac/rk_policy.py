"""Policy as code for Kubernetes manifests (C21 Module 6).

Usage:
  python rk_policy.py check FILE_OR_DIR [...]   # exit 1 if any DENY
  python rk_policy.py test TEST_DIR             # each test file starts with
                                                # "# expect: P01 P05" (or "none")
Rules are plain Python functions so that each one can be read, reviewed and
unit-tested like any other code. DENY blocks a merge; WARN is reported.
"""
import glob
import os
import re
import sys

import yaml

WORKLOAD_KINDS = {"Pod", "Deployment", "StatefulSet", "DaemonSet", "ReplicaSet", "Job", "CronJob"}


def pod_spec(obj):
    kind = obj.get("kind")
    spec = obj.get("spec") or {}
    if kind == "Pod":
        return spec
    if kind == "CronJob":
        return spec.get("jobTemplate", {}).get("spec", {}).get("template", {}).get("spec", {})
    return spec.get("template", {}).get("spec", {})


def containers(ps):
    return (ps.get("initContainers") or []) + (ps.get("containers") or [])


def p01(ps):
    for c in containers(ps):
        img = c.get("image", "")
        last = img.split("/")[-1]
        if "@sha256:" not in img and (":" not in last or last.endswith(":latest")):
            yield f"container {c['name']}: image '{img}' has no version tag (or uses latest)"


def p02(ps):
    for c in containers(ps):
        if (c.get("securityContext") or {}).get("privileged"):
            yield f"container {c['name']}: privileged"


def p03(ps):
    for v in ps.get("volumes") or []:
        if "hostPath" in v:
            yield f"volume {v['name']}: hostPath {v['hostPath'].get('path')}"


def p04(ps):
    for k in ("hostNetwork", "hostPID", "hostIPC"):
        if ps.get(k):
            yield f"{k}: true"


def p05(ps):
    pod_level = (ps.get("securityContext") or {}).get("runAsNonRoot")
    for c in containers(ps):
        if not (c.get("securityContext") or {}).get("runAsNonRoot", pod_level):
            yield f"container {c['name']}: runAsNonRoot not true"


def p06(ps):
    for c in containers(ps):
        if (c.get("securityContext") or {}).get("allowPrivilegeEscalation") is not False:
            yield f"container {c['name']}: allowPrivilegeEscalation not false"


def p07(ps):
    for c in ps.get("containers") or []:
        if not (c.get("resources") or {}).get("limits"):
            yield f"container {c['name']}: no resource limits"


def p08(ps):
    for c in containers(ps):
        drop = ((c.get("securityContext") or {}).get("capabilities") or {}).get("drop") or []
        if "ALL" not in drop:
            yield f"container {c['name']}: capabilities.drop does not include ALL"


def p09(ps):
    if ps.get("automountServiceAccountToken") is not False:
        yield "automountServiceAccountToken not false (confirm the workload needs API access)"


RULES = [("P01", "DENY", p01), ("P02", "DENY", p02), ("P03", "DENY", p03), ("P04", "DENY", p04),
         ("P05", "DENY", p05), ("P06", "DENY", p06), ("P07", "DENY", p07), ("P08", "DENY", p08),
         ("P09", "WARN", p09)]


def evaluate(path):
    results = []
    for doc in yaml.safe_load_all(open(path, encoding="utf-8")):
        if not doc or doc.get("kind") not in WORKLOAD_KINDS:
            continue
        name = f"{doc['kind']}/{doc.get('metadata', {}).get('name', '?')}"
        ps = pod_spec(doc)
        for rid, effect, fn in RULES:
            for msg in fn(ps):
                results.append((name, rid, effect, msg))
    return results


def files(args):
    for a in args:
        if os.path.isdir(a):
            yield from sorted(glob.glob(os.path.join(a, "*.yaml")))
        else:
            yield a


def check(args):
    deny = 0
    for f in files(args):
        res = evaluate(f)
        d = sum(1 for r in res if r[2] == "DENY")
        deny += d
        print(f"{f}: {d} deny, {len(res) - d} warn")
        for name, rid, effect, msg in res:
            print(f"   {effect:4s} {rid} {name}: {msg}")
    print(f"TOTAL deny={deny}")
    return 1 if deny else 0


def test(test_dir):
    failed = 0
    cases = sorted(glob.glob(os.path.join(test_dir, "*.yaml")))
    for f in cases:
        first = open(f, encoding="utf-8").readline()
        m = re.match(r"#\s*expect:\s*(.*)", first)
        want = set() if not m or m.group(1).strip() == "none" else set(m.group(1).split())
        got = {r[1] for r in evaluate(f)}
        ok = got == want
        failed += not ok
        print(f"{'PASS' if ok else 'FAIL'}  {os.path.basename(f):28s} expected {sorted(want) or 'none'}"
              f"{'' if ok else f' got {sorted(got)}'}")
    print(f"{len(cases)} cases, {failed} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    mode, rest = sys.argv[1], sys.argv[2:]
    sys.exit(check(rest) if mode == "check" else test(rest[0]))
