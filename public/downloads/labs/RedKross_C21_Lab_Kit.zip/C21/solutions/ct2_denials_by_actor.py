"""C21 course task CT2 model solution: denied API requests per actor in a window."""
import json
import sys
from collections import Counter

log, start, end = sys.argv[1], sys.argv[2], sys.argv[3]
seen, denied, total = set(), Counter(), 0
for line in open(log, encoding="utf-8"):
    e = json.loads(line)
    if not (start <= e["stageTimestamp"] < end) or e["auditID"] in seen:
        continue
    seen.add(e["auditID"])
    total += 1
    if e.get("responseStatus", {}).get("code") == 403:
        actor = (e.get("impersonatedUser") or {}).get("username") or e["user"]["username"]
        o = e.get("objectRef", {})
        denied[(actor, e["verb"], o.get("resource"), o.get("namespace"))] += 1
print(f"{total} unique requests in window; {sum(denied.values())} denied (403)")
for (actor, verb, res, ns), n in sorted(denied.items()):
    print(f"   {actor}  {verb} {res} ns={ns}  x{n}")
