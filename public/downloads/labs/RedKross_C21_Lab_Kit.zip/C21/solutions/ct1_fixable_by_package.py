"""C21 course task CT1 model solution: fixable CRITICAL/HIGH findings per package."""
import json
import sys
from collections import Counter

for path in sys.argv[1:]:
    seen, per_pkg = set(), Counter()
    for res in json.load(open(path, encoding="utf-8")).get("Results", []):
        for v in res.get("Vulnerabilities") or []:
            key = (v["VulnerabilityID"], v["PkgName"])
            if v.get("Severity") in ("CRITICAL", "HIGH") and v.get("FixedVersion") and key not in seen:
                seen.add(key)
                per_pkg[v["PkgName"]] += 1
    print(f"{path}: {sum(per_pkg.values())} fixable CRITICAL/HIGH in {len(per_pkg)} packages")
    for pkg, n in per_pkg.most_common(3):
        print(f"   {pkg:20s} {n}")
