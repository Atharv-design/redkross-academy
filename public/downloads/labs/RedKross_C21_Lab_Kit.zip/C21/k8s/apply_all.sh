#!/bin/sh
# Deploy the complete Kestrel lab configuration to a lab cluster.
# Usage: KUBECONFIG=... sh apply_all.sh NODE_CONTAINER   (rk-k3s or rk-k3s-hard)
# Run from LAB_ASSETS/C21/k8s after building images in ../images.
set -e
export MSYS_NO_PATHCONV=1
NODE=${1:-rk-k3s}
docker exec -i "$NODE" ctr images import - < ../images/good13.tar >/dev/null
kubectl apply -f kestrel-app.yaml
kubectl apply -f rbac-lab.yaml
kubectl label --overwrite ns kestrel rk.lab/policy=enforced \
  pod-security.kubernetes.io/enforce=restricted pod-security.kubernetes.io/enforce-version=v1.34 \
  pod-security.kubernetes.io/warn=restricted pod-security.kubernetes.io/audit=restricted
kubectl apply -f admission/image-policy.yaml
kubectl apply -f netpol/
kubectl -n kestrel wait --for=condition=Ready pod --all --timeout=180s
