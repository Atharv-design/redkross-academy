"""Detections over a Kubernetes API audit log (C21 Module 5).

Usage: python audit_detect.py AUDIT_LOG [--since ISO_TIMESTAMP]

Each rule is a small function over one audit event. The "actor" is the
impersonated user when impersonation was used, otherwise the user. Events
are de-duplicated by auditID (long-running requests such as exec produce
ResponseStarted and ResponseComplete records).
"""
import json
import sys

SYSTEM_PREFIXES = ("system:apiserver", "system:kube-", "system:node:", "system:k3s",
                   "system:serviceaccount:kube-system:")
SECRET_READERS_ALLOWED = set()          # add service accounts that must read secrets
POWERFUL_ROLES = {"cluster-admin", "admin", "edit"}


def actor(e):
    imp = e.get("impersonatedUser") or {}
    return imp.get("username") or e["user"]["username"]


def is_system(name):
    return name.startswith(SYSTEM_PREFIXES) or name == "k3s-cloud-controller-manager"


def r_exec(e, o):
    if o.get("subresource") in ("exec", "attach", "portforward"):
        cmd = e["requestURI"].split("command=")[1].split("&")[0] if "command=" in e["requestURI"] else "?"
        return "HIGH", f"{o['subresource']} into {o.get('namespace')}/{o.get('name')} command={cmd}"


def r_secret_read(e, o):
    a = actor(e)
    if o.get("resource") == "secrets" and e["verb"] in ("get", "list", "watch") \
            and a.startswith("system:serviceaccount:") and not is_system(a) and a not in SECRET_READERS_ALLOWED:
        code = e.get("responseStatus", {}).get("code")
        sev = "HIGH" if code == 200 else "MEDIUM"
        return sev, f"{e['verb']} secrets in {o.get('namespace', 'ALL')} -> HTTP {code}"


def r_powerful_binding(e, o):
    if o.get("resource") in ("rolebindings", "clusterrolebindings") and e["verb"] in ("create", "update", "patch"):
        ref = (e.get("requestObject") or {}).get("roleRef", {}).get("name", "")
        if ref in POWERFUL_ROLES and not is_system(actor(e)):
            subs = [s.get("name") for s in (e.get("requestObject") or {}).get("subjects", [])]
            return "HIGH", f"{o['resource'][:-1]} {o.get('namespace', '')}/{o.get('name')} grants {ref} to {subs}"


def r_admission_denied(e, o):
    ann = e.get("annotations") or {}
    if e.get("responseStatus", {}).get("code") in (403, 422) and o.get("resource") in ("pods", "deployments"):
        why = "PodSecurity" if any(k.startswith("pod-security") for k in ann) else "admission/authz"
        return "MEDIUM", f"{e['verb']} {o['resource']} {o.get('namespace')}/{o.get('name')} denied ({why})"


def r_token_request(e, o):
    if o.get("resource") == "serviceaccounts" and o.get("subresource") == "token" and not is_system(actor(e)):
        return "MEDIUM", f"token requested for {o.get('namespace')}/{o.get('name')}"


def r_authz_denied_sa(e, o):
    a = actor(e)
    if e.get("annotations", {}).get("authorization.k8s.io/decision") == "forbid" \
            and a.startswith("system:serviceaccount:") and not is_system(a):
        return "LOW", f"forbidden {e['verb']} {o.get('resource')} in {o.get('namespace')}"


RULES = [("AD1 interactive access", r_exec), ("AD2 secret read by SA", r_secret_read),
         ("AD3 powerful binding", r_powerful_binding), ("AD4 admission denial", r_admission_denied),
         ("AD5 token request", r_token_request), ("AD6 SA authorisation denied", r_authz_denied_sa)]


def main(argv):
    since = argv[argv.index("--since") + 1] if "--since" in argv else ""
    seen, alerts, total = set(), [], 0
    for line in open(argv[0], encoding="utf-8"):
        e = json.loads(line)
        total += 1
        if e["stageTimestamp"] < since or e["auditID"] in seen:
            continue
        o = e.get("objectRef") or {}
        for name, rule in RULES:
            hit = rule(e, o)
            if hit:
                seen.add(e["auditID"])
                via = f" (via {e['user']['username']})" if e.get("impersonatedUser") else ""
                alerts.append((e["stageTimestamp"][11:19], hit[0], name, actor(e) + via, hit[1]))
                break
    print(f"{total} audit records read; {len(alerts)} alerts")
    for t, sev, name, who, what in alerts:
        print(f"{t} {sev:6s} {name:28s} {who}")
        print(f"         {what[:150]}")


if __name__ == "__main__":
    main(sys.argv[1:])
