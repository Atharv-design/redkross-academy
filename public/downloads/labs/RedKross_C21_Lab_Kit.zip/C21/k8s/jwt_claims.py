"""Print the claims of a Kubernetes service account token (no verification).

Usage: kubectl create token SA -n NS | python jwt_claims.py
Shows only non-secret claims; never paste real tokens into shared files.
"""
import base64
import datetime
import json
import sys

tok = sys.stdin.read().strip()
payload = tok.split(".")[1]
claims = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
iat, exp = claims["iat"], claims["exp"]
print("aud :", claims.get("aud"))
print("sub :", claims.get("sub"))
print("iat :", datetime.datetime.fromtimestamp(iat, datetime.UTC).isoformat())
print("exp :", datetime.datetime.fromtimestamp(exp, datetime.UTC).isoformat(),
      f"(lifetime {(exp - iat) // 60} minutes)")
k = claims.get("kubernetes.io", {})
wa = claims.get("kubernetes.io", {}).get("warnafter")
if wa:
    print("warnafter:", datetime.datetime.fromtimestamp(wa, datetime.UTC).isoformat(),
          f"({(wa - iat) // 60} minutes; kubelet refreshes the file before this)")
print("bound to pod:", k.get("pod", {}).get("name", "(none - not a pod-bound token)"))
