"""RBAC review for a Kubernetes cluster you administer (C21 Module 4).

Reads roles, cluster roles and bindings (live via kubectl, or from a saved
JSON export) and reports subjects that hold high-risk permissions. Built-in
"system:" roles bound only to "system:" subjects are skipped so that the
report shows grants your organisation made.

Usage:
  python rbac_review.py                 # live: runs kubectl get ... -o json
  python rbac_review.py export.json     # offline: output of
      kubectl get roles,clusterroles,rolebindings,clusterrolebindings -A -o json
  --accept FILE   accepted grants, one per line: "subject binding owner reason"
Exit code 1 if an unaccepted CLUSTER-WIDE high-risk grant exists.
"""
import json
import subprocess
import sys

# (check id, description, test(apiGroup, resource, verb) )
RISKS = [
    ("K01", "wildcard verb or resource", lambda g, r, v: v == "*" or r == "*"),
    ("K02", "read secrets", lambda g, r, v: r in ("secrets", "*") and v in ("get", "list", "watch", "*")),
    ("K03", "exec/attach/port-forward into pods",
     lambda g, r, v: r in ("pods/exec", "pods/attach", "pods/portforward") and v in ("create", "get", "*")),
    ("K04", "create workloads (can mount any secret or service account in scope)",
     lambda g, r, v: r in ("pods", "deployments", "daemonsets", "statefulsets", "jobs", "cronjobs")
     and v in ("create", "*")),
    ("K05", "RBAC escalation verbs (bind/escalate/impersonate)",
     lambda g, r, v: v in ("bind", "escalate", "impersonate")),
    ("K06", "write RBAC bindings", lambda g, r, v: r in ("rolebindings", "clusterrolebindings")
     and v in ("create", "update", "patch", "*")),
    ("K07", "node proxy or token creation", lambda g, r, v: r in ("nodes/proxy", "serviceaccounts/token")),
]


def load(argv):
    if argv:
        return json.load(open(argv[0], encoding="utf-8"))["items"]
    out = subprocess.run(["kubectl", "get", "roles,clusterroles,rolebindings,clusterrolebindings",
                          "-A", "-o", "json"], capture_output=True, text=True, check=True).stdout
    return json.loads(out)["items"]


def builtin(s):
    return s["name"].startswith("system:") or (s["kind"] == "ServiceAccount"
                                               and s.get("namespace") == "kube-system")


def load_accept(argv):
    accepted = {}
    if "--accept" in argv:
        i = argv.index("--accept")
        for line in open(argv[i + 1], encoding="utf-8"):
            if line.strip() and not line.startswith("#"):
                subj, binding, owner, *reason = line.split()
                accepted[(subj, binding)] = f"{owner}: {' '.join(reason)}"
        del argv[i:i + 2]
    return accepted


def subj_name(s):
    if s["kind"] == "ServiceAccount":
        return f"sa:{s.get('namespace', '?')}/{s['name']}"
    return f"{s['kind'].lower()}:{s['name']}"


def main(argv):
    accepted = load_accept(argv)
    items = load(argv)
    roles = {}
    for it in items:
        if it["kind"] in ("Role", "ClusterRole"):
            ns = it["metadata"].get("namespace", "")
            roles[(it["kind"], ns, it["metadata"]["name"])] = it.get("rules") or []
    findings = {}
    for b in items:
        if b["kind"] not in ("RoleBinding", "ClusterRoleBinding"):
            continue
        ref = b["roleRef"]
        bns = b["metadata"].get("namespace", "")
        key = (ref["kind"], bns if ref["kind"] == "Role" else "", ref["name"])
        subjects = b.get("subjects") or []
        if ref["name"].startswith("system:") and all(builtin(s) for s in subjects):
            continue
        scope = f"namespace {bns}" if b["kind"] == "RoleBinding" else "CLUSTER-WIDE"
        hits = set()
        if ref["name"] == "cluster-admin":
            hits.add(("K00", "cluster-admin"))
        for rule in roles.get(key, []):
            for g in rule.get("apiGroups", [""]):
                for r in rule.get("resources", []):
                    for v in rule.get("verbs", []):
                        for cid, desc, test in RISKS:
                            if test(g, r, v):
                                hits.add((cid, desc))
        for s in subjects:
            if hits:
                findings.setdefault(subj_name(s), []).append((scope, b["metadata"]["name"], ref["name"],
                                                              sorted(hits)))
    print(f"RBAC review: {sum(1 for i in items if i['kind'].endswith('Binding'))} bindings, "
          f"{len(roles)} roles examined")
    if not findings:
        print("No high-risk grants to non-system subjects.")
    open_cluster = 0
    for subj in sorted(findings):
        for scope, bname, rname, hits in findings[subj]:
            note = accepted.get((subj, bname))
            status = f"ACCEPTED ({note})" if note else "OPEN"
            open_cluster += scope == "CLUSTER-WIDE" and not note
            print(f"\n{subj}  via {bname} -> {rname}  [{scope}]  {status}")
            for cid, desc in hits:
                print(f"   {cid}  {desc}")
    print(f"\nOpen cluster-wide high-risk grants: {open_cluster}")
    return 1 if open_cluster else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
