#!/bin/sh
# Generate a short, labelled sequence of API activity on YOUR OWN hardened
# lab cluster so that the audit log has something to detect. Every action
# is taken by the lab administrator (directly or with --as impersonation)
# against lab objects. Nothing touches other systems.
export MSYS_NO_PATHCONV=1
SA=system:serviceaccount:kestrel
echo "[A1] routine: ci-deployer restarts the api Deployment"
kubectl -n kestrel rollout restart deployment/api --as=$SA:ci-deployer
echo "[A2] interactive: administrator runs a command inside the frontend pod"
kubectl -n kestrel exec frontend -- id
echo "[A3] legacy-ops lists secrets in kube-system"
kubectl -n kube-system get secrets --as=$SA:legacy-ops -o name | wc -l
echo "[A4] reporting tries to list secrets (should be denied)"
kubectl -n kestrel get secrets --as=$SA:reporting 2>&1 | head -1
echo "[A5] a privileged pod is submitted to kestrel (should be denied)"
kubectl apply -f psa/privileged-pod.yaml 2>&1 | cut -c1-120
echo "[A6] a RoleBinding grants the built-in admin role to reporting"
kubectl -n kestrel create rolebinding reporting-admin --clusterrole=admin --serviceaccount=kestrel:reporting
echo "[A7] a token is requested for legacy-ops"
kubectl -n kestrel create token legacy-ops --duration=30m >/dev/null && echo "token issued (not stored)"
