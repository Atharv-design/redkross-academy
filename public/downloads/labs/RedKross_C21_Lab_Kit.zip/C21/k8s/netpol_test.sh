#!/bin/sh
# Reachability matrix for the kestrel namespace (lab cluster only).
# REACHABLE = a TCP connection and an HTTP answer (any status code);
# BLOCKED   = no answer within 4 seconds (curl reports 000).
probe() {  # $1 = client pod, $2 = URL
  code=$(kubectl -n kestrel exec "$1" -- curl -sk -o /dev/null -m 4 -w '%{http_code}' "$2" 2>/dev/null)
  if [ "$code" = "000" ] || [ -z "$code" ]; then echo "BLOCKED"; else echo "REACHABLE (HTTP $code)"; fi
}
for pair in "frontend http://api.kestrel/healthz" "batch http://api.kestrel/healthz" \
            "frontend https://kubernetes.default/version"; do
  set -- $pair
  printf '  %-9s %-44s %s\n' "$1" "$2" "$(probe "$1" "$2")"
done
