#!/bin/sh
# C21 Module 3 lab: explore the architecture of YOUR OWN local lab cluster.
# Requires KUBECONFIG pointing at the lab cluster and (for the datastore
# step) a k3s server container named rk-k3s. Read-only except for the
# kestrel namespace objects it creates and deletes.
set -u
export MSYS_NO_PATHCONV=1
step() { echo; echo "### $*"; }

step "1. Versions and nodes"
kubectl version | grep -v Kustomize
kubectl get nodes

step "2. The API server is a REST service: health checks (last 6 lines)"
kubectl get --raw='/readyz?verbose' | tail -6

step "3. Unauthenticated request to the API server"
curl -sk https://127.0.0.1:16443/api/v1/namespaces | head -c 300; echo

step "4. Resource types the API serves"
echo "namespaced:     $(kubectl api-resources --namespaced=true -o name | wc -l)"
echo "cluster-scoped: $(kubectl api-resources --namespaced=false -o name | wc -l)"

step "5. Where the control plane runs (k3s embeds it in one process)"
kubectl get pods -n kube-system -o custom-columns=NAME:.metadata.name,STATUS:.status.phase
docker exec rk-k3s sh -c 'ls /var/lib/rancher/k3s/server/db/'

step "6. Ownership chain: Pod -> ReplicaSet -> Deployment"
POD=$(kubectl -n kestrel get pod -l app=api -o jsonpath='{.items[0].metadata.name}')
RS=$(kubectl -n kestrel get pod "$POD" -o jsonpath='{.metadata.ownerReferences[0].kind}/{.metadata.ownerReferences[0].name}')
echo "pod $POD is owned by $RS"
kubectl -n kestrel get "$(echo "$RS" | tr 'A-Z' 'a-z')" -o jsonpath='{.metadata.ownerReferences[0].kind}/{.metadata.ownerReferences[0].name}{"\n"}'

step "7. Reconciliation: delete a pod, the ReplicaSet replaces it"
kubectl -n kestrel delete pod "$POD" --wait=true
kubectl -n kestrel wait --for=condition=Ready pod -l app=api --timeout=60s >/dev/null
kubectl -n kestrel get pods -l app=api -o custom-columns=NAME:.metadata.name,READY:.status.containerStatuses[0].ready

step "8. Secrets at rest in the datastore (default settings)"
kubectl -n kestrel create secret generic at-rest-demo --from-literal=token=rk-lab-at-rest-demo-value
kubectl -n kestrel get secret at-rest-demo -o jsonpath='{.data.token}'; echo "   <- base64 in the API, not encryption"
sleep 2
echo "datastore files containing the plaintext value: $(docker exec rk-k3s sh -c 'grep -l rk-lab-at-rest-demo-value /var/lib/rancher/k3s/server/db/state.db* 2>/dev/null | wc -l')"
docker exec rk-k3s k3s secrets-encrypt status 2>&1 | head -3
kubectl -n kestrel delete secret at-rest-demo
