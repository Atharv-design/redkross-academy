#!/bin/sh
# Start the hardened lab cluster (k3s in Docker, API on 127.0.0.1:16444).
# Run from this directory. Lab use only.
export MSYS_NO_PATHCONV=1
HERE="$(pwd -W 2>/dev/null || pwd)"
docker run -d --name rk-k3s-hard --privileged -p 127.0.0.1:16444:6443 \
  -v "$HERE:/etc/rk:ro" -v "$HERE/audit-logs:/var/log/rk-audit" \
  rancher/k3s:v1.34.1-k3s1 server \
  --disable=traefik --disable=metrics-server --tls-san 127.0.0.1 \
  --secrets-encryption \
  --kube-apiserver-arg=audit-policy-file=/etc/rk/audit-policy.yaml \
  --kube-apiserver-arg=audit-log-path=/var/log/rk-audit/audit.log \
  --kube-apiserver-arg=audit-log-maxage=7 \
  --kube-apiserver-arg=admission-control-config-file=/etc/rk/admission-config.yaml \
  --kube-apiserver-arg=service-account-extend-token-expiration=false \
  --kube-apiserver-arg=anonymous-auth=false
