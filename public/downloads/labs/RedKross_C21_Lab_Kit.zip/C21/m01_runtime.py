"""C21 Module 1 lab: compare a default container with a hardened one.

Runs two short-lived containers from a local image on YOUR OWN Docker
host, reads what the kernel reports from inside each one (capabilities,
user, namespaces, filesystem writability) and prints a side-by-side view.
Nothing leaves the host; both containers are removed afterwards.

Usage: python m01_runtime.py [image]      (default nginx:alpine)
"""
import subprocess
import sys

IMAGE = sys.argv[1] if len(sys.argv) > 1 else "nginx:alpine"

# Linux capability numbers (include/uapi/linux/capability.h)
CAPS = ["chown", "dac_override", "dac_read_search", "fowner", "fsetid", "kill",
        "setgid", "setuid", "setpcap", "linux_immutable", "net_bind_service",
        "net_broadcast", "net_admin", "net_raw", "ipc_lock", "ipc_owner",
        "sys_module", "sys_rawio", "sys_chroot", "sys_ptrace", "sys_pacct",
        "sys_admin", "sys_boot", "sys_nice", "sys_resource", "sys_time",
        "sys_tty_config", "mknod", "lease", "audit_write", "audit_control",
        "setfcap", "mac_override", "mac_admin", "syslog", "wake_alarm",
        "block_suspend", "audit_read", "perfmon", "bpf", "checkpoint_restore"]

PROBE = ("id -u; grep -E '^(CapEff|NoNewPrivs|Seccomp):' /proc/self/status; "
         "ls -l /proc/self/ns | awk 'NR>1{print $(NF-2), $NF}'; "
         "awk '$2==\"/\"{split($4,o,\",\"); print \"rootfs=\" o[1]}' /proc/mounts")

PROFILES = {
    "default": [],
    "hardened": ["--read-only", "--tmpfs", "/tmp", "--cap-drop", "ALL",
                 "--security-opt", "no-new-privileges", "--user", "101:101",
                 "--pids-limit", "64", "--memory", "128m"],
}


def decode(hexmask):
    mask = int(hexmask, 16)
    return [name for bit, name in enumerate(CAPS) if mask >> bit & 1]


def run(profile):
    cmd = ["docker", "run", "--rm", "--entrypoint", "sh", *PROFILES[profile], IMAGE, "-c", PROBE]
    out = subprocess.run(cmd, capture_output=True, text=True, check=True).stdout.splitlines()
    info = {"uid": out[0]}
    for line in out[1:]:
        if ":" in line and line.split(":")[0] in ("CapEff", "NoNewPrivs", "Seccomp"):
            k, v = line.split(":", 1)
            info[k] = v.strip()
        elif line.startswith("rootfs="):
            info["rootfs"] = line.split("=")[1]
        else:
            info.setdefault("ns", []).append(line)
    info["caps"] = decode(info["CapEff"])
    return info


def main():
    print(f"Image: {IMAGE}")
    results = {p: run(p) for p in PROFILES}
    for p, r in results.items():
        print(f"\n[{p}] docker run {' '.join(PROFILES[p]) or '(no options)'}")
        print(f"  uid inside container : {r['uid']}")
        print(f"  CapEff               : {r['CapEff']} ({len(r['caps'])} capabilities)")
        print(f"  capabilities         : {', '.join(r['caps']) or '(none)'}")
        print(f"  NoNewPrivs           : {r['NoNewPrivs']}")
        print(f"  Seccomp mode         : {r['Seccomp']} (2 = filter active)")
        print(f"  root mount option    : {r['rootfs']} (rw = writable, ro = read-only)")
    print("\nNamespaces seen by the container (inode numbers differ per container):")
    for line in results["default"]["ns"]:
        print("  ", line)
    removed = sorted(set(results["default"]["caps"]) - set(results["hardened"]["caps"]))
    print(f"\nCapabilities removed by hardening: {len(removed)}")


if __name__ == "__main__":
    main()
