"""Answer "which images contain package X?" from CycloneDX SBOMs (C21 M02).

Usage: python sbom_query.py PACKAGE sbom1.cdx.json [sbom2.cdx.json ...]
       python sbom_query.py --stats sbom1.cdx.json [...]
"""
import json
import sys
from collections import Counter


def components(path):
    doc = json.load(open(path, encoding="utf-8"))
    return doc, doc.get("components", [])


def main(argv):
    if argv[0] == "--stats":
        for p in argv[1:]:
            doc, comps = components(p)
            kinds = Counter()
            for c in comps:
                purl = c.get("purl", "")
                kinds[purl.split("/")[0].replace("pkg:", "") if purl else c.get("type", "?")] += 1
            print(f"{p}: specVersion {doc.get('specVersion')}, {len(comps)} components {dict(kinds)}")
        return
    name = argv[0].lower()
    for p in argv[1:]:
        _, comps = components(p)
        hits = [c for c in comps if c.get("name", "").lower() == name]
        if not hits:
            print(f"{p}: {name} not present")
        for c in hits:
            print(f"{p}: {c.get('name')} {c.get('version')}  {c.get('purl', '')}")


if __name__ == "__main__":
    main(sys.argv[1:])
