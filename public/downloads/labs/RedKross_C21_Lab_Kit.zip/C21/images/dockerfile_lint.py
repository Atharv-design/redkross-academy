"""A small, readable Dockerfile linter for C21 Module 2.

Usage: python dockerfile_lint.py Dockerfile [Dockerfile ...]
Exit code 1 if any HIGH finding is present. The rules are deliberately few
so that learners can read and extend them; production teams use Trivy,
Hadolint or Checkov, which implement many more checks.
"""
import os
import re
import sys

SECRET_WORDS = re.compile(r"(PASSWORD|PASSWD|SECRET|TOKEN|API_?KEY|PRIVATE_?KEY)", re.I)


def lint(path):
    lines = open(path, encoding="utf-8").read().splitlines()
    findings = []
    users = []
    ctx = os.path.dirname(os.path.abspath(path))
    for n, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        op, _, arg = line.partition(" ")
        op = op.upper()
        if op == "FROM":
            image = arg.split()[0]
            if "@sha256:" not in image:
                sev = "HIGH" if image.endswith(":latest") or ":" not in image.split("/")[-1] else "MEDIUM"
                findings.append((n, sev, "RK-D01", f"base image not pinned by digest: {image}"))
        elif op in ("ENV", "ARG") and SECRET_WORDS.search(arg.split("=")[0]):
            findings.append((n, "HIGH", "RK-D02", f"secret-like name in {op} is stored in image metadata"))
        elif op == "USER":
            users.append(arg.split(":")[0])
        elif op == "ADD" and re.match(r"https?://", arg):
            findings.append((n, "MEDIUM", "RK-D03", "ADD from URL: no integrity check; download and verify"))
        elif op == "RUN" and re.search(r"(curl|wget)[^|]*\|\s*(ba)?sh", arg):
            findings.append((n, "HIGH", "RK-D04", "pipes a download into a shell"))
        elif op == "COPY" and re.match(r"(--\S+\s+)*(\.|\S+/)\s+\S+$", arg):
            if not os.path.exists(os.path.join(ctx, ".dockerignore")):
                findings.append((n, "MEDIUM", "RK-D05", "copies a whole directory and no .dockerignore exists"))
    if not users or users[-1] in ("root", "0"):
        findings.append((len(lines), "HIGH", "RK-D06", "final USER is root (or not set)"))
    return findings


def main():
    worst = 0
    for path in sys.argv[1:]:
        f = lint(path)
        print(f"{path}: {len(f)} finding(s)")
        for n, sev, rule, msg in f:
            print(f"  line {n:2d}  {sev:6s} {rule}  {msg}")
            worst = max(worst, 1 if sev == "HIGH" else 0)
    sys.exit(worst)


if __name__ == "__main__":
    main()
