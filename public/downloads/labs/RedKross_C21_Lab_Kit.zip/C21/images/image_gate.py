"""Release gate over a Trivy JSON report (C21 Module 2, Practical 2).

Policy (edit to suit your organisation):
  - BLOCK on any CRITICAL or HIGH finding that has a fixed version,
    unless an unexpired exception exists for that vulnerability ID.
  - WARN on CRITICAL or HIGH findings with no fix (track and monitor).
  - BLOCK if any secret is detected.
Exceptions file: one per line "VULN-ID  expiry(YYYY-MM-DD)  owner  reason".

Usage: python image_gate.py REPORT.json [EXCEPTIONS.txt] [--today YYYY-MM-DD]
Exit code 0 = pass, 1 = blocked.
"""
import datetime
import json
import sys


def load_exceptions(path, today):
    out = {}
    if not path:
        return out
    for line in open(path, encoding="utf-8"):
        if line.strip() and not line.startswith("#"):
            vid, expiry, owner, *reason = line.split()
            if datetime.date.fromisoformat(expiry) >= today:
                out[vid] = (expiry, owner, " ".join(reason))
            else:
                print(f"  note: exception for {vid} expired on {expiry} - ignored")
    return out


def main(argv):
    today = datetime.date.today()
    if "--today" in argv:
        i = argv.index("--today")
        today = datetime.date.fromisoformat(argv[i + 1])
        argv = argv[:i] + argv[i + 2:]
    report = json.load(open(argv[0], encoding="utf-8"))
    exc = load_exceptions(argv[1] if len(argv) > 1 else None, today)
    block, warn, waived, seen = [], [], [], set()
    secrets = 0
    for res in report.get("Results", []):
        secrets += len(res.get("Secrets") or [])
        for v in res.get("Vulnerabilities") or []:
            key = (v["VulnerabilityID"], v["PkgName"])
            if key in seen or v.get("Severity") not in ("CRITICAL", "HIGH"):
                continue
            seen.add(key)
            item = f"{v['VulnerabilityID']} {v['PkgName']} {v.get('InstalledVersion')} -> {v.get('FixedVersion') or 'no fix'}"
            if not v.get("FixedVersion"):
                warn.append(item)
            elif v["VulnerabilityID"] in exc:
                waived.append(item + f"  [exception until {exc[v['VulnerabilityID']][0]}]")
            else:
                block.append(item)
    print(f"Gate for {argv[0]} on {today}:")
    print(f"  blocking (fixable CRITICAL/HIGH): {len(block)}")
    for b in block[:10]:
        print("    " + b)
    if len(block) > 10:
        print(f"    ... and {len(block) - 10} more")
    print(f"  waived by exception: {len(waived)}")
    for w in waived:
        print("    " + w)
    print(f"  warnings (CRITICAL/HIGH with no fix yet): {len(warn)}")
    print(f"  secrets: {secrets}")
    ok = not block and secrets == 0
    print("  RESULT: " + ("PASS" if ok else "BLOCK"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
