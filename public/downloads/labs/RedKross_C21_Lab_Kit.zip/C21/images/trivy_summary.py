"""Summarise Trivy JSON reports: findings by severity, fixable share, secrets.

Usage: python trivy_summary.py trivy_bad.json [trivy_good.json ...]
"""
import json
import sys
from collections import Counter

ORDER = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "UNKNOWN"]


def summarise(path):
    rep = json.load(open(path, encoding="utf-8"))
    meta = rep.get("Metadata", {})
    print(f"== {path}  (Trivy report created {rep.get('CreatedAt', '?')[:19]})")
    print(f"   OS: {meta.get('OS', {}).get('Family', '?')} {meta.get('OS', {}).get('Name', '')}")
    sev, fixable, by_class, secrets = Counter(), Counter(), Counter(), []
    seen = set()
    py_pkgs = []
    for res in rep.get("Results", []):
        for v in res.get("Vulnerabilities") or []:
            key = (v["VulnerabilityID"], v["PkgName"], v.get("InstalledVersion"))
            if key in seen:
                continue
            seen.add(key)
            sev[v.get("Severity", "UNKNOWN")] += 1
            by_class[res.get("Class", "?")] += 1
            if v.get("FixedVersion"):
                fixable[v.get("Severity", "UNKNOWN")] += 1
            if res.get("Class") == "lang-pkgs":
                py_pkgs.append(v)
        for s in res.get("Secrets") or []:
            secrets.append((res.get("Target"), s.get("RuleID"), s.get("Severity"), s.get("StartLine")))
    total = sum(sev.values())
    print(f"   Unique vulnerabilities: {total}  (OS packages {by_class['os-pkgs']}, "
          f"language packages {by_class['lang-pkgs']})")
    for s in ORDER:
        if sev[s]:
            print(f"     {s:8s} {sev[s]:4d}   with a fixed version available: {fixable[s]}")
    if py_pkgs:
        print("   Python package findings (fix = upgrade the pin):")
        for v in sorted(py_pkgs, key=lambda v: (ORDER.index(v.get('Severity', 'UNKNOWN')), v['VulnerabilityID'])):
            print(f"     {v['PkgName']:9s} {v['InstalledVersion']:8s} {v['VulnerabilityID']:15s} "
                  f"{v.get('Severity', ''):8s} fixed in {v.get('FixedVersion') or '-'}")
    print(f"   Secrets detected: {len(secrets)}")
    for t, rule, s, line in secrets:
        print(f"     {t} line {line}: rule {rule} ({s})")
    return total


if __name__ == "__main__":
    for p in sys.argv[1:]:
        summarise(p)
        print()
