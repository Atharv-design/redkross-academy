"""GRC toolkit for the Tamarind Logistics case (Course 17). All data fictional.

Subcommands (python grc_toolkit.py <cmd>):
  risk      risk register: inherent vs residual scores, treatment, expiry checks,
            ASCII heat map                                          (Module 2)
  csf       map internal controls to NIST CSF 2.0 categories; coverage and gaps
                                                                    (Module 3)
  exceptions  policy exception register checks                 (Module 4)
  bia       business impact analysis checks: dependency RTOs vs process RTO,
            backup interval vs RPO                                  (Module 5)
  audit     reproducible sample of access-review evidence; exception rate
                                                                    (Module 6)
  vendor    third-party questionnaire scoring with critical-fail items
                                                                    (Module 7)
Tested: CPython 3.14.4, 2026-11-07.
"""
import random
import sys
from datetime import date

AS_OF = date(2026, 11, 7)

# ---------------------------------------------------------------- Module 2
RISKS = [  # id, asset, scenario, L, I, control effect (L_red, I_red), treatment, owner, accept_until
    ("R01", "customer DB", "ransomware encrypts DB and backups", 3, 5, (1, 2), "mitigate", "CTO", None),
    ("R02", "payroll exports", "export emailed unencrypted to wrong recipient", 4, 3, (2, 1), "mitigate", "CFO", None),
    ("R03", "partner portal", "credential stuffing on partner logins", 4, 4, (2, 1), "mitigate", "CISO", None),
    ("R04", "legacy depot PC", "unsupported OS exploited", 3, 3, (0, 0), "accept", "Ops head", "2026-10-31"),
    ("R05", "courier API", "provider outage halts dispatch", 2, 4, (0, 1), "transfer", "COO", None),
    ("R06", "office Wi-Fi", "guest network reaches internal hosts", 2, 3, (1, 1), "mitigate", "IT lead", None),
]


def risk():
    print(f"{'id':4} {'inherent':>8} {'residual':>8}  treatment  owner     scenario")
    grid = {}
    for rid, asset, scen, l, i, (dl, di), treat, owner, until in RISKS:
        rl, ri = max(1, l - dl), max(1, i - di)
        grid.setdefault((rl, ri), []).append(rid)
        flag = ""
        if treat == "accept":
            flag = "  ACCEPTANCE EXPIRED" if until and date.fromisoformat(until) < AS_OF else f"  accepted to {until}"
        if rl * ri >= 12 and treat != "mitigate":
            flag += "  REVIEW: high residual not mitigated"
        print(f"{rid:4} {l * i:8} {rl * ri:8}  {treat:9}  {owner:8}  {scen}{flag}")
    print("\nresidual heat map (rows = impact 5..1, cols = likelihood 1..5)")
    for imp in range(5, 0, -1):
        cells = [",".join(grid.get((lik, imp), [])) or "." for lik in range(1, 6)]
        print(f"  I{imp} | " + " | ".join(f"{c:11}" for c in cells))


# ---------------------------------------------------------------- Module 3
CSF_CATEGORIES = {  # NIST CSWP 29 (CSF 2.0), 26 Feb 2024
    "GV": ["GV.OC", "GV.RM", "GV.RR", "GV.PO", "GV.OV", "GV.SC"],
    "ID": ["ID.AM", "ID.RA", "ID.IM"],
    "PR": ["PR.AA", "PR.AT", "PR.DS", "PR.PS", "PR.IR"],
    "DE": ["DE.CM", "DE.AE"],
    "RS": ["RS.MA", "RS.AN", "RS.CO", "RS.MI"],
    "RC": ["RC.RP", "RC.CO"],
}
CONTROLS = [  # internal control id, description, mapped CSF categories
    ("TL-01", "Information security policy approved by board annually", ["GV.PO", "GV.OV"]),
    ("TL-02", "Risk register reviewed quarterly by risk committee", ["GV.RM", "ID.RA"]),
    ("TL-03", "Asset inventory (CMDB) reconciled monthly", ["ID.AM"]),
    ("TL-04", "MFA for all remote and admin access", ["PR.AA"]),
    ("TL-05", "Quarterly access reviews for critical systems", ["PR.AA"]),
    ("TL-06", "Annual security awareness + phishing simulations", ["PR.AT"]),
    ("TL-07", "Encryption at rest and in transit for customer data", ["PR.DS"]),
    ("TL-08", "Patch critical vulnerabilities within 14 days", ["PR.PS", "ID.RA"]),
    ("TL-09", "SIEM monitoring with 24x7 MDR", ["DE.CM", "DE.AE"]),
    ("TL-10", "Incident response plan tested annually (tabletop)", ["RS.MA", "RS.CO"]),
    ("TL-11", "Immutable offline backups, restore test quarterly", ["PR.DS", "RC.RP"]),
    ("TL-12", "Vendor security assessment before onboarding", ["GV.SC"]),
]


def csf():
    covered = {}
    for cid, desc, cats in CONTROLS:
        for c in cats:
            covered.setdefault(c, []).append(cid)
    total = 0
    for fn, cats in CSF_CATEGORIES.items():
        hit = [c for c in cats if c in covered]
        total += len(hit)
        print(f"  {fn}: {len(hit)}/{len(cats)} categories covered; gaps: "
              f"{', '.join(c for c in cats if c not in covered) or 'none'}")
    n = sum(len(v) for v in CSF_CATEGORIES.values())
    print(f"overall: {total}/{n} categories have at least one mapped control")
    print("note: mapping coverage is not effectiveness - each control still needs testing (Module 6)")


# ---------------------------------------------------------------- Module 4
EXCEPTIONS = [  # id, standard, scope, reason, compensating, approver, risk_id, expires
    ("EX-01", "STD-AC-02 MFA on all remote access", "depot terminal server",
     "legacy app incompatible", "IP allowlist + session recording", "CISO", "R03", "2026-12-31"),
    ("EX-02", "STD-PT-01 patch criticals in 14 days", "label printers",
     "vendor firmware pending", "", "IT lead", "R04", "2026-09-30"),
    ("EX-03", "STD-CR-01 AES-256 at rest", "archive NAS",
     "hardware limit", "physical access control", "", "R02", "2027-03-31"),
]
APPROVER_LEVEL = {"CEO": 3, "CISO": 2, "IT lead": 1}


def exceptions():
    for eid, std, scope, reason, comp, approver, rid, exp in EXCEPTIONS:
        issues = []
        if date.fromisoformat(exp) < AS_OF:
            issues.append("EXPIRED")
        if not comp:
            issues.append("no compensating control")
        if not approver:
            issues.append("no approver")
        elif APPROVER_LEVEL.get(approver, 0) < 2:
            issues.append(f"approver '{approver}' below required level (CISO)")
        print(f"  {eid} {scope:22} -> {'; '.join(issues) if issues else 'valid'}  ({std}; risk {rid})")


# ---------------------------------------------------------------- Module 5
PROCESSES = {  # process: (MTD h, RTO h, RPO h, dependencies)
    "dispatch & tracking": (24, 8, 1, ["shipment DB", "courier API", "identity (SSO)"]),
    "customer portal": (48, 24, 4, ["shipment DB", "web cluster", "identity (SSO)"]),
    "payroll": (120, 72, 24, ["payroll SaaS", "identity (SSO)"]),
}
SYSTEMS = {  # system: (achievable RTO h, backup/replication interval h)
    "shipment DB": (6, 0.25), "courier API": (12, 0), "identity (SSO)": (4, 1),
    "web cluster": (2, 24), "payroll SaaS": (48, 24),
}


def bia():
    for proc, (mtd, rto, rpo, deps) in PROCESSES.items():
        issues = []
        if rto > mtd:
            issues.append("RTO exceeds MTD")
        for d in deps:
            srto, interval = SYSTEMS[d]
            if srto > rto:
                issues.append(f"{d} RTO {srto}h > process RTO {rto}h")
            if interval > rpo and interval > 0:
                issues.append(f"{d} backup interval {interval}h > RPO {rpo}h")
        print(f"  {proc:20} MTD {mtd:>3}h RTO {rto:>2}h RPO {rpo:>2}h -> "
              f"{'; '.join(issues) if issues else 'OK'}")


# ---------------------------------------------------------------- Module 6
def audit():
    rng = random.Random(20261107)                  # seeded so the auditor can re-perform the sample
    population = [f"USR-{n:04d}" for n in range(1, 241)]
    exceptions = {"USR-0007", "USR-0091", "USR-0133", "USR-0201"}   # leavers still active (fictional)
    sample = sorted(rng.sample(population, 25))
    found = [u for u in sample if u in exceptions]
    print(f"  population {len(population)} accounts; sample {len(sample)} (seed 20261107)")
    print(f"  sample: {', '.join(sample[:8])} ...")
    print(f"  exceptions in sample: {found or 'none'}  rate {len(found) / len(sample):.0%}")
    print("  tolerable rate set in audit plan: 0% for leaver removal -> "
          + ("CONTROL NOT EFFECTIVE (finding)" if found else "no exception noted"))
    full = sorted(u for u in population if u in exceptions)          # data analytics: test 100%
    print(f"  full-population test (HR leaver list vs active accounts): {len(full)} exceptions {full}")


# ---------------------------------------------------------------- Module 7
QUESTIONS = [  # id, question, weight, critical
    ("V1", "Independent security certification or report (ISO 27001 / SOC 2) current", 3, False),
    ("V2", "MFA enforced for all staff and admin access", 3, True),
    ("V3", "Customer data encrypted at rest and in transit", 3, True),
    ("V4", "Breach notification to customers within 24 hours in contract", 2, True),
    ("V5", "Sub-processors disclosed and assessed", 2, False),
    ("V6", "Data stored in approved regions (India) or documented transfer", 2, False),
    ("V7", "Annual penetration test with remediation evidence", 2, False),
    ("V8", "Tested backup and recovery with stated RTO/RPO", 2, False),
]
VENDORS = {
    "RouteOpt SaaS": {"V1": 1, "V2": 1, "V3": 1, "V4": 1, "V5": 1, "V6": 0, "V7": 1, "V8": 1},
    "QuickPrint Labels": {"V1": 0, "V2": 0, "V3": 1, "V4": 0, "V5": 0, "V6": 1, "V7": 0, "V8": 1},
}


def vendor():
    maxw = sum(w for _, _, w, _ in QUESTIONS)
    for name, ans in VENDORS.items():
        score = sum(w for q, _, w, _ in QUESTIONS if ans[q])
        crit = [q for q, _, _, c in QUESTIONS if c and not ans[q]]
        tier = "REJECT/REMEDIATE" if crit else ("approve" if score / maxw >= 0.8 else "approve with conditions")
        print(f"  {name:18} score {score}/{maxw} ({score / maxw:.0%}) critical fails {crit or '-'} -> {tier}")


if __name__ == "__main__":
    {"risk": risk, "csf": csf, "exceptions": exceptions, "bia": bia, "audit": audit, "vendor": vendor}[sys.argv[1]]()
