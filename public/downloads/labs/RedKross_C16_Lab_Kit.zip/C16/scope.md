# RedKross C16 - Wireless and mobile assessment scope and authorisation

Complete before any assessment. The lab ships filled for the provided artefacts;
adapt it for any authorised engagement.

## Authorisation
- Assessor: <your name>
- Authorised by: self (lab owner) / <authorising manager for a real engagement>
- Window: <when assessment is permitted>
- Purpose: defensive review of wireless and mobile security for your own or the
  lab's assets.

## In scope
- data/wifi_config.json, data/wifi_config_fixed.json (your own AP configuration)
- data/bt_config.json, data/bt_config_fixed.json (your own Bluetooth device)
- data/authorized_aps.json, data/observed_aps.json (an inventory and a scan you
  collected on a network you own/are authorised to survey)
- demo_app/ (the lab's DEMO mobile app - an original teaching artifact you own)
- data/api_config.json, data/api_config_fixed.json (your app's backend API
  configuration description)

## Out of scope (hard limits)
- Any wireless network, Bluetooth device, mobile app or API you do not own or are
  not authorised, in writing, to assess.
- Any RADIO activity against third parties: the tools are OFFLINE and perform no
  scanning, deauthentication, transmission or connection. Collecting a real scan
  must be done only on your own/authorised networks with proper tools and never
  includes attacking, deauthenticating or connecting to others' networks.
- Any real app store application analysed without authorisation. The demo app is
  provided precisely so no third-party app is needed.

## Rules of engagement
- All provided tools are offline document/data reviews - keep them that way.
- Investigate rogue/evil-twin findings physically and through your own controls;
  do not attack or connect to any AP.
- Record evidence (the saved tool outputs) for the report.

## Deliverable
- A wireless-and-mobile assessment report: per-control findings and status
  (Wi-Fi, Bluetooth, mobile app via MASVS, backend API), the rogue-AP analysis,
  and remediation moving each enforcing control from FAIL to PASS.
