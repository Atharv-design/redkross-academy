RedKross Academy - Course 16 Wireless and Mobile Security
Lab assets (original, offline, defender-only)
======================================================================

WHAT THIS LAB IS
This lab teaches wireless and mobile security as DEFENCE, entirely offline. Every
tool reviews a CONFIGURATION DOCUMENT, a PROVIDED SCAN, or an original DEMO mobile
app that you own - none performs any radio scanning, transmission, deauth or
connection, and none touches a real third-party network, device or app. You
review each control, find its weaknesses, harden it, and confirm the hardening by
re-running the reviewer.

REQUIREMENTS
- Python 3 (tested on CPython 3.14.4, Windows 11), standard library only.
- No internet, radio hardware, Android SDK or third-party package required.

TOOLS
  wifireview.py  review a WLAN/AP config (WPA3/WPA2, PMF, WPS, admin creds,
                 firmware, guest isolation). wifi_config.json FAILs (10 findings,
                 6 HIGH); wifi_config_fixed.json PASSes.
  roguescan.py   detect rogue/evil-twin APs in a PROVIDED offline scan against an
                 authorised-AP inventory (finds 2 evil-twins).
  btreview.py    review a Bluetooth/BLE config (association model, LE Secure
                 Connections, discoverability, PIN, key size). bt_config.json
                 FAILs (6 findings, 3 HIGH); bt_config_fixed.json PASSes.
  mobilecheck.py static review of the DEMO app (demo_app/) mapped to OWASP MASVS
                 categories (16 findings, 9 HIGH).
  apicheck.py    review the mobile backend API config (TLS, token handling,
                 authorization). api_config.json FAILs (7 findings, 5 HIGH);
                 api_config_fixed.json PASSes.
  review.py      consolidated control summary (3/3 enforcing config controls
                 FAIL->PASS, plus mobile-app and rogue-AP findings).

DEMO APP (teaching artifact, NOT a real APK)
  demo_app/manifest.json                 AndroidManifest-like, deliberate flaws
  demo_app/network_security_config.xml   permits cleartext + user CAs
  demo_app/src/MainActivity.txt          insecure data handling (hardcoded key,
                                         DES/ECB, external-storage secret, secret
                                         logging, cleartext HTTP, unsafe WebView)
  This is an original, inert excerpt for STATIC review only - it is not compiled
  or run, and it is not a real application.

DATA
  data/wifi_config*.json, data/bt_config*.json, data/api_config*.json  configs
  data/authorized_aps.json, data/observed_aps.json                      AP survey
  data/*_output.txt                                                      saved runs

SAFETY AND LEGALITY
  See scope.md. All tools are OFFLINE: no scanning, no deauth, no transmission,
  no connection. Assess only wireless networks, Bluetooth devices, mobile apps
  and APIs you own or are authorised, in writing, to assess. In India,
  unauthorised access to or interference with a wireless network or device is an
  offence under the Information Technology Act, 2000 (e.g. ss.43, 66), and radio
  use is regulated; keep to your own/authorised assets. Not legal advice.

Standards: NIST SP 800-153 (WLANs), Wi-Fi Alliance WPA3/PMF, NIST SP 800-121
Rev.2 (Bluetooth), OWASP MASVS and MASTG (mobile). Verified at source 2026-11-08.

EVERYTHING IS ORIGINAL AND OFFLINE. No radio activity, no third-party targets,
no real app. The lab teaches defenders to review and harden wireless and mobile
security.
