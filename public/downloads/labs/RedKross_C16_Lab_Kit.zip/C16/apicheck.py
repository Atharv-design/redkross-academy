#!/usr/bin/env python3
"""apicheck.py - RedKross C16: offline review of a mobile app's backend API
security configuration.

Reviews a JSON description of the API the mobile app talks to - transport (TLS),
token handling, and backend authorization - against mobile API best practice
(OWASP MASVS-NETWORK/AUTH and API security guidance). ENTIRELY OFFLINE: it
reviews a configuration document and makes no network request.

  python apicheck.py data/api_config.json
  python apicheck.py data/api_config_fixed.json
"""
import json
import sys


def review(cfg):
    findings = []

    def add(sev, masvs, control, msg):
        findings.append((sev, masvs, control, msg))

    base = cfg.get("base_url", "")
    tls = cfg.get("tls", {})
    if base.startswith("http://") or not tls.get("enabled", False):
        add("HIGH", "MASVS-NETWORK", "transport",
            "API served over cleartext/no-TLS; require HTTPS for all endpoints")
    minv = str(tls.get("min_version", ""))
    if tls.get("enabled") and minv and minv < "1.2":
        add("HIGH", "MASVS-NETWORK", "tls-version",
            "TLS minimum version %s is deprecated; require TLS 1.2 or higher"
            % minv)

    auth = cfg.get("auth", {})
    if auth.get("token_in") == "url_query":
        add("HIGH", "MASVS-AUTH", "token-placement",
            "token passed in the URL query (logged by servers/proxies); send it "
            "in the Authorization header")
    if auth.get("token_type") == "static_api_key":
        add("HIGH", "MASVS-AUTH", "token-type",
            "static long-lived API key as the user token; use short-lived "
            "bearer tokens with refresh")
    try:
        life = int(auth.get("token_lifetime_days", 0))
        if life > 30:
            add("MEDIUM", "MASVS-AUTH", "token-lifetime",
                "token lifetime %d days is excessive; use short lifetimes with "
                "refresh/revocation" % life)
    except (TypeError, ValueError):
        pass
    if not auth.get("server_side_authorization", False):
        add("HIGH", "MASVS-AUTH", "authorization",
            "no server-side authorization; the backend must enforce authz on "
            "every request, never trust the client")
    if not cfg.get("object_level_authorization", False):
        add("HIGH", "MASVS-AUTH", "object-authorization",
            "no object-level authorization; verify the user owns each object "
            "(prevents IDOR/BOLA)")
    if not cfg.get("rate_limiting", False):
        add("MEDIUM", "MASVS-NETWORK", "rate-limiting",
            "no API rate limiting; add it to resist brute-force and abuse")

    return findings


def main(argv):
    if len(argv) != 2:
        print("usage: python apicheck.py <api_config.json>")
        return 2
    with open(argv[1]) as f:
        cfg = json.load(f)
    findings = review(cfg)
    order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    findings.sort(key=lambda x: order.get(x[0], 9))
    highs = sum(1 for f in findings if f[0] == "HIGH")
    print("Mobile backend API security review: %s" % cfg.get("name", argv[1]))
    if not findings:
        print("  no findings - configuration meets the reviewed controls. PASS")
    for sev, masvs, control, msg in findings:
        print("  [%-6s] %-14s %-20s %s" % (sev, masvs, control, msg))
    print("  ---")
    print("  %d finding(s), %d HIGH -> %s" % (
        len(findings), highs, "FAIL" if highs else
        ("REVIEW" if findings else "PASS")))
    print("Offline review only - no requests made. Mapped to OWASP MASVS "
          "(NETWORK/AUTH).")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
