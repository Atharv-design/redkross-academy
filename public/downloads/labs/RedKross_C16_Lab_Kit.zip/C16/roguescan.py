#!/usr/bin/env python3
"""roguescan.py - RedKross C16: offline rogue / evil-twin AP detection.

Compares a PROVIDED site-survey scan (a JSON capture you already collected on a
network you are authorised to assess) against an inventory of authorised access
points, and flags:
  - EVIL TWIN : one of your SSIDs advertised by an unknown BSSID (impersonation);
  - ROGUE/UNKNOWN: an unknown BSSID advertising a managed SSID, especially OPEN;
  - FOREIGN   : neighbouring networks (not your SSID) - informational.

It is ENTIRELY OFFLINE: it analyses a provided scan file and performs NO radio
scanning, transmission or connection. Collecting the scan itself must be done
only on networks you own or are authorised to survey, with proper tools.

  python roguescan.py data/authorized_aps.json data/observed_aps.json
"""
import json
import sys


def detect(auth, scan):
    managed = set(auth.get("managed_ssids", []))
    authorized = auth.get("authorized_bssids", {})
    auth_bssids = {b.lower() for b in authorized}
    results = []
    for ap in scan.get("observed", []):
        bssid = ap.get("bssid", "").lower()
        ssid = ap.get("ssid", "")
        sec = ap.get("security", "").upper()
        if bssid in auth_bssids:
            exp = authorized[[b for b in authorized if b.lower() == bssid][0]]
            if exp.get("ssid") != ssid:
                results.append(("HIGH", "ssid-mismatch", ap,
                                "authorised BSSID broadcasting unexpected SSID"))
            else:
                results.append(("OK", "authorised", ap, "known authorised AP"))
        elif ssid in managed:
            # unknown BSSID using one of our SSIDs => evil twin / rogue
            sev = "HIGH"
            note = "EVIL TWIN: managed SSID on UNKNOWN BSSID"
            if sec in ("OPEN", "NONE", "WEP"):
                note += " with weak/open security (classic credential trap)"
            results.append((sev, "evil-twin", ap, note))
        else:
            results.append(("INFO", "foreign", ap,
                            "neighbouring network (not a managed SSID)"))
    return results


def main(argv):
    if len(argv) != 3:
        print("usage: python roguescan.py <authorized_aps.json> <observed_aps.json>")
        return 2
    with open(argv[1]) as f:
        auth = json.load(f)
    with open(argv[2]) as f:
        scan = json.load(f)
    results = detect(auth, scan)
    order = {"HIGH": 0, "INFO": 1, "OK": 2}
    results.sort(key=lambda x: order.get(x[0], 9))
    print("Rogue/evil-twin AP analysis (offline, provided scan):")
    rogue = 0
    for sev, kind, ap, note in results:
        if sev == "HIGH":
            rogue += 1
        print("  [%-4s] %-12s %s / %-20s ch%-3s %sdBm %-5s  %s" % (
            sev, kind, ap.get("bssid"), ap.get("ssid"), ap.get("channel"),
            ap.get("signal_dbm"), ap.get("security"), note))
    print("  ---")
    print("  %d rogue/evil-twin finding(s) requiring investigation." % rogue)
    print("Offline analysis only - no scanning performed. Investigate flagged "
          "BSSIDs physically; do not connect to or attack any AP.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
