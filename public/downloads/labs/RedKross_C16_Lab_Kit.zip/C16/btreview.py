#!/usr/bin/env python3
"""btreview.py - RedKross C16: offline Bluetooth/BLE configuration review.

Reviews a Bluetooth/BLE device's pairing and security configuration against NIST
SP 800-121 Rev.2 (Guide to Bluetooth Security) guidance: association model (Just
Works vs authenticated), LE Secure Connections vs legacy pairing, discoverability,
default PINs, and encryption key size. ENTIRELY OFFLINE: reviews a configuration
document; no Bluetooth radio activity.

  python btreview.py data/bt_config.json
  python btreview.py data/bt_config_fixed.json

Authorised use only: review devices you own or are authorised to assess.
"""
import json
import sys


def review(cfg):
    findings = []

    def add(sev, control, msg):
        findings.append((sev, control, msg))

    method = cfg.get("pairing_method", "")
    if method.lower() == "just works":
        add("HIGH", "association",
            "'Just Works' association provides NO man-in-the-middle protection; "
            "use Numeric Comparison or Passkey Entry where devices have I/O")

    if not cfg.get("secure_connections", False) or \
            "legacy" in cfg.get("le_security", "").lower():
        add("HIGH", "le-secure-connections",
            "LE legacy pairing in use; enable LE Secure Connections (ECDH) for "
            "strong key agreement")

    if cfg.get("discoverable", "").lower() in ("always", "on", "true"):
        add("MEDIUM", "discoverable",
            "device is always discoverable; make it discoverable only on demand "
            "and for a limited time")

    pin = str(cfg.get("default_pin", ""))
    if pin and pin.lower() not in ("none", "") and (pin in ("0000", "1234")
                                                    or pin.isdigit()):
        add("HIGH", "default-pin",
            "weak/default pairing PIN %r; do not use fixed legacy PINs" % pin)

    try:
        ks = int(cfg.get("min_encryption_key_size", 0))
        if ks and ks < 16:
            add("MEDIUM", "key-size",
                "minimum encryption key size %d bytes is below the 16-byte "
                "maximum; require the largest key size supported" % ks)
    except (TypeError, ValueError):
        pass

    if not cfg.get("bonded_devices_reviewed", False):
        add("LOW", "bonded-devices",
            "bonded/paired device list not reviewed; periodically remove stale "
            "or unknown bonds")

    return findings


def main(argv):
    if len(argv) != 2:
        print("usage: python btreview.py <bt_config.json>")
        return 2
    with open(argv[1]) as f:
        cfg = json.load(f)
    findings = review(cfg)
    order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    findings.sort(key=lambda x: order.get(x[0], 9))
    highs = sum(1 for f in findings if f[0] == "HIGH")
    print("Bluetooth/BLE configuration review: %s (%s)" % (
        argv[1], cfg.get("device", "?")))
    if not findings:
        print("  no findings - configuration meets the reviewed controls. PASS")
    for sev, control, msg in findings:
        print("  [%-6s] %-22s %s" % (sev, control, msg))
    print("  ---")
    print("  %d finding(s), %d HIGH -> %s" % (
        len(findings), highs, "FAIL" if highs else
        ("REVIEW" if findings else "PASS")))
    print("Offline review only - no Bluetooth activity. Cites NIST SP 800-121 "
          "Rev.2 (Guide to Bluetooth Security).")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
