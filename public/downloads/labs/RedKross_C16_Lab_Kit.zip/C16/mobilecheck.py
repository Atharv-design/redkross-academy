#!/usr/bin/env python3
"""mobilecheck.py - RedKross C16: static review of the DEMO mobile app.

Statically inspects the lab's demo app (an original teaching artifact under
demo_app/, NOT a real APK) for insecure-data-handling and configuration
weaknesses, mapping each finding to an OWASP MASVS category. It reads the
manifest, the network security config and the source excerpts; it never builds
or runs anything.

  python mobilecheck.py demo_app

MASVS categories used: MASVS-STORAGE, MASVS-CRYPTO, MASVS-NETWORK,
MASVS-PLATFORM, MASVS-CODE. Review only apps you own or are authorised to assess.
"""
import json
import os
import re
import sys


def check_manifest(path, add):
    with open(path) as f:
        mani = json.load(f)
    app = mani.get("application", {})
    if app.get("debuggable"):
        add("HIGH", "MASVS-CODE", "manifest",
            "application is debuggable=true (must be false in release)")
    if app.get("allowBackup"):
        add("MEDIUM", "MASVS-STORAGE", "manifest",
            "allowBackup=true may expose app data via backup; disable unless "
            "needed")
    if app.get("usesCleartextTraffic"):
        add("HIGH", "MASVS-NETWORK", "manifest",
            "usesCleartextTraffic=true permits unencrypted HTTP; require TLS")
    for c in mani.get("components", []):
        if c.get("exported") and c.get("type") in ("activity", "content_provider"):
            if not c.get("intent_filters") and c.get("type") == "activity" \
                    or c.get("type") == "content_provider":
                add("MEDIUM", "MASVS-PLATFORM", "manifest",
                    "%s %r is exported without clear need; restrict export"
                    % (c.get("type"), c.get("name")))
    dangerous = {"WRITE_EXTERNAL_STORAGE", "READ_CONTACTS", "ACCESS_FINE_LOCATION"}
    perms = [p.split(".")[-1] for p in mani.get("permissions", [])]
    over = dangerous.intersection(perms)
    if over:
        add("LOW", "MASVS-PLATFORM", "manifest",
            "requests sensitive permissions %s; confirm each is necessary and "
            "justified" % sorted(over))


def check_netsec(path, add):
    with open(path) as f:
        txt = f.read()
    if re.search(r'cleartextTrafficPermitted\s*=\s*"true"', txt):
        add("HIGH", "MASVS-NETWORK", "netsec-config",
            "network security config permits cleartext traffic; set "
            "cleartextTrafficPermitted=false and pin/trust only system CAs")
    if re.search(r'certificates\s+src\s*=\s*"user"', txt):
        add("MEDIUM", "MASVS-NETWORK", "netsec-config",
            "trusts user-added CAs; this enables interception via a user CA - "
            "trust only the system store for sensitive apps")


def check_source(path, add):
    with open(path) as f:
        src = f.read()
    rel = os.path.basename(path)
    if re.search(r'API_KEY\s*=\s*"[^"]+"', src) or \
            re.search(r'(rk_live_[0-9a-f]+)', src):
        add("HIGH", "MASVS-CRYPTO", rel,
            "hardcoded API key/secret in source; move secrets off the client")
    if "http://" in src:
        add("HIGH", "MASVS-NETWORK", rel,
            "cleartext http:// endpoint in source; use https://")
    if re.search(r'getExternalStorage|ExternalStorageDirectory', src):
        add("HIGH", "MASVS-STORAGE", rel,
            "writes to shared/external storage; sensitive data belongs in app-"
            "private storage, encrypted")
    if re.search(r'Log\.[dviwe]\([^)]*token', src, re.I):
        add("HIGH", "MASVS-STORAGE", rel,
            "logs a secret/token; never log sensitive data")
    if re.search(r'DES|/ECB/|"RC4"|MD5', src):
        add("HIGH", "MASVS-CRYPTO", rel,
            "weak cryptography (DES/ECB/RC4/MD5); use AES-GCM with a managed key")
    if re.search(r'setJavaScriptEnabled\(true\)', src):
        add("MEDIUM", "MASVS-PLATFORM", rel,
            "WebView JavaScript enabled; ensure content is trusted and no JS "
            "bridge exposes native APIs")
    if re.search(r'setAllowFileAccessFromFileURLs\(true\)', src):
        add("HIGH", "MASVS-PLATFORM", rel,
            "WebView allows file access from file URLs; disable to prevent local-"
            "file exfiltration")


def main(argv):
    if len(argv) != 2:
        print("usage: python mobilecheck.py <demo_app dir>")
        return 2
    root = argv[1]
    findings = []

    def add(sev, masvs, loc, msg):
        findings.append((sev, masvs, loc, msg))

    mani = os.path.join(root, "manifest.json")
    netsec = os.path.join(root, "network_security_config.xml")
    if os.path.exists(mani):
        check_manifest(mani, add)
    if os.path.exists(netsec):
        check_netsec(netsec, add)
    srcdir = os.path.join(root, "src")
    if os.path.isdir(srcdir):
        for fn in sorted(os.listdir(srcdir)):
            check_source(os.path.join(srcdir, fn), add)

    order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    findings.sort(key=lambda x: order.get(x[0], 9))
    highs = sum(1 for f in findings if f[0] == "HIGH")
    print("Mobile app static review (DEMO teaching artifact): %s" % root)
    for sev, masvs, loc, msg in findings:
        print("  [%-6s] %-14s %-16s %s" % (sev, masvs, loc, msg))
    print("  ---")
    print("  %d finding(s), %d HIGH -> %s" % (
        len(findings), highs, "FAIL" if highs else "PASS"))
    print("Static review only - nothing built or executed. Mapped to OWASP "
          "MASVS categories; see OWASP MASTG for test procedures.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
