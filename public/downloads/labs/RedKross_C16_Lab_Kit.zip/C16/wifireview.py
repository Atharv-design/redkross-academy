#!/usr/bin/env python3
"""wifireview.py - RedKross C16: offline WLAN/access-point configuration review.

Reads a Wi-Fi/AP configuration (a JSON document describing YOUR OWN or the lab's
wireless network) and reports security weaknesses against current guidance
(WPA3/WPA2, Protected Management Frames, WPS, admin credentials, firmware, guest
isolation). It is ENTIRELY OFFLINE: it reviews a configuration document and makes
no radio transmission, scan, or connection of any kind.

  python wifireview.py data/wifi_config.json
  python wifireview.py data/wifi_config_fixed.json

Authorised use only: review configurations for networks you own or are
authorised to assess. This tool never touches the air.
"""
import json
import sys

WEAK_CIPHERS = {"WEP", "TKIP", "TKIP+AES"}
WEAK_MODES = {"OPEN", "WEP", "WPA", "WPA-PSK", "WPA2-TKIP"}


def review(cfg):
    findings = []

    def add(sev, control, msg):
        findings.append((sev, control, msg))

    mode = cfg.get("security_mode", "").upper()
    cipher = cfg.get("cipher", "").upper()
    if mode in ("OPEN", "NONE", ""):
        add("HIGH", "encryption", "open network: no encryption; use WPA3/WPA2")
    elif "WEP" in mode or mode == "WPA-PSK" or mode == "WPA":
        add("HIGH", "encryption",
            "obsolete security mode %r; use WPA3-Personal (SAE) or WPA2-AES"
            % cfg.get("security_mode"))
    elif mode == "WPA2-PERSONAL":
        add("MEDIUM", "encryption",
            "WPA2-Personal: acceptable with a strong passphrase and AES, but "
            "prefer WPA3-Personal (SAE) for password-guess resistance")
    if cipher in WEAK_CIPHERS:
        add("HIGH", "cipher",
            "weak/deprecated cipher %r (TKIP/WEP); require AES-CCMP/GCMP"
            % cfg.get("cipher"))

    pw = cfg.get("passphrase", "")
    if mode.endswith("PERSONAL") or "PSK" in mode:
        if len(pw) < 15 or pw.isalpha() or pw.isalnum() and pw.islower():
            add("HIGH", "passphrase",
                "weak PSK/SAE passphrase (short or low-complexity); use a long, "
                "random passphrase")

    if cfg.get("pmf", "").lower() in ("disabled", "off", "none", ""):
        add("HIGH", "pmf",
            "Protected Management Frames (802.11w) disabled; WPA3 requires PMF - "
            "enable it to stop deauth/forging of management frames")

    if cfg.get("wps", "").lower() in ("enabled", "on", "true"):
        add("HIGH", "wps",
            "WPS enabled: the PIN method is brute-forceable; disable WPS")

    au = cfg.get("admin_user", "")
    ap = cfg.get("admin_password", "")
    if au.lower() in ("admin", "root", "") or ap.lower() in ("admin", "password",
                                                             "", "root"):
        add("HIGH", "admin-creds",
            "default/weak AP admin credentials; set a unique admin user and a "
            "long random password")

    fw = cfg.get("firmware", "")
    fw_latest = cfg.get("firmware_latest", "")
    if fw_latest and fw != fw_latest:
        add("MEDIUM", "firmware",
            "AP firmware %r is out of date (latest %r); update to patch known "
            "vulnerabilities" % (fw, fw_latest))

    guest = cfg.get("guest_network", {})
    if guest.get("enabled"):
        if not guest.get("isolation"):
            add("MEDIUM", "guest-isolation",
                "guest network lacks client isolation; isolate guest clients")
        if guest.get("same_vlan_as_corp"):
            add("HIGH", "guest-segmentation",
                "guest network shares the corporate VLAN; place guests on a "
                "separate, segmented VLAN")

    if cfg.get("mac_filtering") == "relied_on_as_security":
        add("LOW", "mac-filtering",
            "MAC filtering relied on as security: MACs are easily spoofed; treat "
            "it as hygiene, not a control")

    return findings


def main(argv):
    if len(argv) != 2:
        print("usage: python wifireview.py <wifi_config.json>")
        return 2
    with open(argv[1]) as f:
        cfg = json.load(f)
    findings = review(cfg)
    print("WLAN configuration review: %s (SSID %s)" % (
        argv[1], cfg.get("ssid", "?")))
    order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    findings.sort(key=lambda x: order.get(x[0], 9))
    highs = sum(1 for f in findings if f[0] == "HIGH")
    if not findings:
        print("  no findings - configuration meets the reviewed controls. PASS")
    for sev, control, msg in findings:
        print("  [%-6s] %-18s %s" % (sev, control, msg))
    print("  ---")
    print("  %d finding(s), %d HIGH -> %s" % (
        len(findings), highs, "FAIL" if highs else
        ("REVIEW" if findings else "PASS")))
    print("Offline review only - no radio activity. Cites NIST SP 800-153 and "
          "Wi-Fi Alliance WPA3/PMF guidance.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
