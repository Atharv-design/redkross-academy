#!/usr/bin/env python3
"""review.py - RedKross C16: consolidated wireless-and-mobile assessment summary.

Runs the offline reviewers over the lab's pre-hardening and hardened artefacts
and prints one control summary showing each control moving FAIL -> PASS, plus the
rogue-AP finding. This is the capstone aid: it demonstrates that the assessment
is evidence (re-runnable checks), not opinion. Entirely offline.

  python review.py
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def count(mod_review, path):
    with open(path) as f:
        cfg = json.load(f)
    findings = mod_review(cfg)
    highs = sum(1 for x in findings if x[0] == "HIGH")
    return len(findings), highs


def main(argv):
    import wifireview
    import btreview
    import apicheck
    import mobilecheck
    import roguescan

    d = os.path.join(HERE, "data")
    rows = []

    n, h = count(wifireview.review, os.path.join(d, "wifi_config.json"))
    n2, h2 = count(wifireview.review, os.path.join(d, "wifi_config_fixed.json"))
    rows.append(("Wi-Fi/AP config (WPA3/PMF/WPS)", n, h, n2, h2))

    n, h = count(btreview.review, os.path.join(d, "bt_config.json"))
    n2, h2 = count(btreview.review, os.path.join(d, "bt_config_fixed.json"))
    rows.append(("Bluetooth/BLE pairing", n, h, n2, h2))

    n, h = count(apicheck.review, os.path.join(d, "api_config.json"))
    n2, h2 = count(apicheck.review, os.path.join(d, "api_config_fixed.json"))
    rows.append(("Mobile backend API", n, h, n2, h2))

    # mobile app static review (demo app only has the insecure version)
    import io
    from contextlib import redirect_stdout
    buf = io.StringIO()
    with redirect_stdout(buf):
        mobilecheck.main(["mobilecheck.py", os.path.join(HERE, "demo_app")])
    mob_line = [l for l in buf.getvalue().splitlines() if "finding(s)," in l]
    mob = mob_line[0].strip() if mob_line else "n/a"

    # rogue AP analysis
    with open(os.path.join(d, "authorized_aps.json")) as f:
        auth = json.load(f)
    with open(os.path.join(d, "observed_aps.json")) as f:
        scan = json.load(f)
    rogue = sum(1 for r in roguescan.detect(auth, scan) if r[0] == "HIGH")

    print("Wireless and mobile assessment: control summary")
    print("-" * 58)
    for name, n, h, n2, h2 in rows:
        before = "%d finding(s) (%d HIGH)" % (n, h)
        after = "%d finding(s)" % n2
        status_b = "FAIL" if h else ("REVIEW" if n else "PASS")
        status_a = "PASS" if h2 == 0 and n2 == 0 else ("REVIEW" if n2 else "PASS")
        print("%s" % name)
        print("  before: %-26s %s" % (before, status_b))
        print("  after : %-26s %s" % (after, status_a))
    print("Mobile app (DEMO) static review")
    print("  %s (hardening is an exercise: fix each MASVS finding)" % mob)
    print("Rogue/evil-twin APs in provided scan")
    print("  %d evil-twin/rogue AP(s) to investigate" % rogue)
    print("-" * 58)
    passed = sum(1 for _, _, h, n2, h2 in rows if h and h2 == 0 and n2 == 0)
    print("Enforcing config controls: %d/%d moved FAIL -> PASS." % (passed,
                                                                    len(rows)))
    print("Offline, evidence-based: every number is reproducible by re-running "
          "the reviewers.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
