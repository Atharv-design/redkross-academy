"""Zero trust policy decision point (PDP) teaching model (Course 22).

Follows the NIST SP 800-207 logical split: a policy engine (decide) and a
policy administrator / enforcement point (act). Every request is evaluated
per session using identity, authentication strength, device posture,
context risk and resource sensitivity; the default is deny. Decisions are
ALLOW, STEP_UP (require stronger authentication) or DENY, each with reasons,
and every decision is logged.
Run: python zt_pdp.py            (prints decisions for sample requests)
     python -m unittest zt_pdp   (runs tests)
Tested: CPython 3.14.4, 2026-11-07. All identities and resources fictional.
"""
import json
import unittest
from dataclasses import dataclass, field

AUTH_STRENGTH = {"password": 1, "otp": 2, "push_number_match": 2, "fido2": 3}
SENSITIVITY_MIN_AUTH = {"internal": 2, "confidential": 2, "restricted": 3}

POLICY = {  # resource -> allowed groups, sensitivity, extra conditions
    "shipment-portal-admin": {"groups": {"ops-admins"}, "sensitivity": "restricted",
                              "managed_device": True},
    "payroll-app": {"groups": {"finance"}, "sensitivity": "confidential",
                    "managed_device": True},
    "intranet": {"groups": {"staff", "finance", "ops-admins"}, "sensitivity": "internal",
                 "managed_device": False},
}


@dataclass
class Request:
    user: str
    groups: set
    auth: str
    device_managed: bool
    device_compliant: bool
    geo_risk: str          # "low" | "medium" | "high" (from threat intel / impossible travel)
    resource: str
    reasons: list = field(default_factory=list)


def decide(r: Request):
    p = POLICY.get(r.resource)
    if p is None:
        return "DENY", ["unknown resource (default deny)"]
    if not (r.groups & p["groups"]):
        return "DENY", ["subject not entitled to resource"]
    if p["managed_device"] and not r.device_managed:
        return "DENY", ["unmanaged device not allowed for this resource"]
    if r.device_managed and not r.device_compliant:
        return "DENY", ["device fails posture (patch/EDR/encryption)"]
    if r.geo_risk == "high":
        return "DENY", ["high-risk context (e.g. impossible travel)"]
    need = SENSITIVITY_MIN_AUTH[p["sensitivity"]] + (1 if r.geo_risk == "medium" else 0)
    have = AUTH_STRENGTH.get(r.auth, 0)
    if have < min(need, 3):
        return "STEP_UP", [f"auth strength {have} < required {min(need, 3)}"]
    dev = "managed+compliant" if r.device_managed else "unmanaged (permitted here)"
    return "ALLOW", [f"entitled; auth {have}; device {dev}; risk {r.geo_risk}"]


def enforce(r: Request, log):
    decision, reasons = decide(r)
    log.append({"user": r.user, "resource": r.resource, "decision": decision, "reasons": reasons})
    return decision


SAMPLES = [
    Request("priya", {"ops-admins", "staff"}, "fido2", True, True, "low", "shipment-portal-admin"),
    Request("priya", {"ops-admins", "staff"}, "otp", True, True, "low", "shipment-portal-admin"),
    Request("ravi", {"finance", "staff"}, "push_number_match", True, True, "low", "payroll-app"),
    Request("ravi", {"finance", "staff"}, "push_number_match", False, False, "low", "payroll-app"),
    Request("ravi", {"finance", "staff"}, "push_number_match", True, True, "medium", "payroll-app"),
    Request("asha", {"staff"}, "otp", False, False, "low", "intranet"),
    Request("asha", {"staff"}, "otp", True, True, "low", "payroll-app"),
    Request("vendor-qp", {"vendors"}, "password", False, False, "low", "label-printer-mgmt"),
    Request("gopal", {"staff"}, "otp", True, True, "high", "intranet"),
]


class Tests(unittest.TestCase):
    def test_default_deny_unknown_resource(self):
        self.assertEqual(decide(SAMPLES[7])[0], "DENY")

    def test_restricted_needs_phishing_resistant(self):
        self.assertEqual(decide(SAMPLES[0])[0], "ALLOW")
        self.assertEqual(decide(SAMPLES[1])[0], "STEP_UP")

    def test_unmanaged_device_blocked_for_payroll(self):
        self.assertEqual(decide(SAMPLES[3])[0], "DENY")

    def test_medium_risk_raises_required_strength(self):
        self.assertEqual(decide(SAMPLES[4])[0], "STEP_UP")

    def test_not_entitled(self):
        self.assertEqual(decide(SAMPLES[6])[0], "DENY")

    def test_high_risk_denied_even_for_intranet(self):
        self.assertEqual(decide(SAMPLES[8])[0], "DENY")


if __name__ == "__main__":
    log = []
    for s in SAMPLES:
        d = enforce(s, log)
        print(f"{s.user:10} {s.resource:22} {s.auth:18} managed={str(s.device_managed):5} "
              f"risk={s.geo_risk:6} -> {d:7} {log[-1]['reasons'][0]}")
    print("decision log record example:", json.dumps(log[1]))
