"""Control validation matrix (Course 22, Module 7).

Architecture assurance asks: for each security requirement, which control
implements it, which test proves the control works, and where is the
evidence? This tool reads requirements.json (requirement -> control ->
evidence file -> pattern that the evidence must contain) and builds the
matrix from saved lab outputs. Status per requirement:
  VALIDATED    evidence file exists and contains the expected result
  FAILED       evidence exists but does not show the expected result
  NO-EVIDENCE  evidence file missing (control claimed but not demonstrated)
Each evidence file is hashed (SHA-256) so the matrix can be re-checked later.
Run: python control_matrix.py [requirements.json]
Tested: CPython 3.14.4, 2026-11-08. Reads local files only.
"""
import hashlib
import json
import os
import re
import sys


def check(req, base):
    path = os.path.join(base, req["evidence"])
    if not os.path.exists(path):
        return "NO-EVIDENCE", "-"
    data = open(path, "rb").read()
    digest = hashlib.sha256(data).hexdigest()[:12]
    ok = re.search(req["expect"], data.decode("utf-8", "replace"), re.M) is not None
    return ("VALIDATED" if ok else "FAILED"), digest


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "requirements.json"
    base = os.path.dirname(os.path.abspath(path))
    reqs = json.load(open(path, encoding="utf-8"))
    counts = {"VALIDATED": 0, "FAILED": 0, "NO-EVIDENCE": 0}
    print(f"{'ID':4s} {'STATUS':12s} {'SHA256':12s} REQUIREMENT -> CONTROL")
    for r in reqs:
        status, digest = check(r, base)
        counts[status] += 1
        print(f"{r['id']:4s} {status:12s} {digest:12s} {r['requirement']}")
        print(f"{'':31s}-> {r['control']} [{r['evidence']}]")
    total = len(reqs)
    print(f"summary: {counts['VALIDATED']}/{total} validated, {counts['FAILED']} failed, "
          f"{counts['NO-EVIDENCE']} without evidence")
    return 0 if counts["VALIDATED"] == total else 1


if __name__ == "__main__":
    sys.exit(main())
