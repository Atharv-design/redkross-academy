#!/bin/sh
# Course 22 micro-segmentation lab: three tiers on separate Docker networks.
#   tl-front : web <-> app              tl-data (internal, no default route) : app <-> db
# web is NOT attached to tl-data, so it cannot reach db; db has no route out.
# All containers are local and removed at the end.
export MSYS_NO_PATHCONV=1
docker network create tl-front >/dev/null
docker network create --internal tl-data >/dev/null
docker run -d --rm --name tl-db  --network tl-data alpine:3.20 sh -c "nc -lk -p 5432 -e echo db-ok" >/dev/null
docker run -d --rm --name tl-app --network tl-front alpine:3.20 sh -c "nc -lk -p 8080 -e echo app-ok" >/dev/null
docker network connect tl-data tl-app
docker run -d --rm --name tl-web --network tl-front alpine:3.20 sleep 300 >/dev/null
sleep 2
probe() { # from to port
  out=$(docker exec "$1" sh -c "echo | nc -w 2 $2 $3 2>&1" | head -1)
  printf '  %-7s -> %-7s :%-5s %s\n' "$1" "$2" "$3" "${out:-NO CONNECTION}"
}
echo "== connectivity matrix"
probe tl-web tl-app 8080
probe tl-app tl-db 5432
probe tl-web tl-db 5432
DBIP=$(docker inspect -f "{{(index .NetworkSettings.Networks \"tl-data\").IPAddress}}" tl-db)
probe tl-web "$DBIP" 5432
echo "== routes inside tl-db (internal network)"
docker exec tl-db ip route | sed 's/^/  /'
echo "== egress attempt from tl-db to 1.1.1.1:443"
docker exec tl-db sh -c "nc -w 2 1.1.1.1 443 </dev/null && echo reachable || echo 'blocked (no route)'" 2>&1 | tail -1 | sed 's/^/  /'
docker rm -f tl-web tl-app tl-db >/dev/null 2>&1
docker network rm tl-front tl-data >/dev/null
echo "== cleanup done"
