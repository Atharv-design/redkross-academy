"""Generate a deterministic synthetic zero trust telemetry file (Course 22, M06).

Writes decision_log.jsonl: two hours of fictional Tamarind Logistics events
with five embedded conditions for decision_monitor.py to find (a gateway log
gap, a PDP outage handled fail-closed, an untracked policy change, a deny
burst and a session not revoked after posture failure). No real data.
Tested: CPython 3.14.4, 2026-11-08.
"""
import json
import random
from datetime import datetime, timedelta

random.seed(22)
T0 = datetime(2026, 11, 8, 9, 0, 0)
USERS = [("priya", "dev-p1", "shipment-portal-admin"), ("ravi", "dev-r1", "payroll-app"),
         ("asha", "dev-a1", "intranet"), ("gopal", "dev-g1", "intranet")]
ev = []


def add(minute, **kw):
    kw["ts"] = (T0 + timedelta(minutes=minute, seconds=random.randint(0, 50))).isoformat()
    ev.append(kw)


sid = 0
for m in range(0, 120, 3):
    add(m, source="pdp", kind="heartbeat")
    if not 40 <= m < 62:              # gateway (PEP) log gap 40-62 min
        add(m, source="pep", kind="heartbeat")
    u, dev, res = random.choice(USERS)
    if 70 <= m < 79:                   # PDP outage: fail-closed decisions
        add(m, source="pep", kind="decision", user=u, device=dev, resource=res,
            decision="DENY", path="fail_closed", session=f"s{sid}")
    else:
        add(m, source="pdp", kind="decision", user=u, device=dev, resource=res,
            decision="ALLOW", path="engine", session=f"s{sid}")
        add(m + 2, source="pdp", kind="session_end", session=f"s{sid}")
    sid += 1
# deny burst: vendor account repeatedly refused (unknown resource)
for i in range(6):
    add(85 + i, source="pdp", kind="decision", user="vendor-qp", device="unmanaged",
        resource="label-printer-mgmt", decision="DENY", path="engine", session=f"v{i}")
# policy changes: one tracked, one not
add(30, source="pdp", kind="policy_change", actor="sec-arch", change="payroll-app min auth 2->3",
    ticket="CHG-1042")
add(95, source="pdp", kind="policy_change", actor="ops-admin2",
    change="intranet allow group contractors", ticket="")
# posture drift: priya's session revoked promptly; ravi's is not
add(100, source="pdp", kind="decision", user="priya", device="dev-p1",
    resource="shipment-portal-admin", decision="ALLOW", path="engine", session="s900")
add(101, source="pdp", kind="decision", user="ravi", device="dev-r1",
    resource="payroll-app", decision="ALLOW", path="engine", session="s901")
add(104, source="edr", kind="posture", device="dev-p1", compliant=False, reason="EDR agent stopped")
add(106, source="pdp", kind="revoke", session="s900", reason="posture change")
add(108, source="edr", kind="posture", device="dev-r1", compliant=False, reason="disk encryption off")

with open("decision_log.jsonl", "w", encoding="utf-8") as fh:
    for e in sorted(ev, key=lambda x: x["ts"]):
        fh.write(json.dumps(e) + "\n")
print(f"wrote decision_log.jsonl ({len(ev)} events)")
