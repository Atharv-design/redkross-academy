"""Continuous-verification monitor over zero trust telemetry (Course 22, Module 6).

Reads a JSON Lines event file (no network access) containing policy decision
point (PDP) decisions, posture updates, session revocations, policy changes
and per-source heartbeats, and reports monitoring signals:
  M1 telemetry gap      a source silent for more than GAP_MIN minutes
  M2 PDP unavailable    decisions made by the fail-safe path (fail_closed)
  M3 untracked change   policy change without a change-ticket reference
  M4 deny burst         >= BURST denies for one user within BURST_WIN minutes
  M5 stale session      device posture became non-compliant during an active
                        session and no revocation followed within REVOKE_MIN
Run: python make_decision_log.py && python decision_monitor.py decision_log.jsonl
Tested: CPython 3.14.4, 2026-11-08. All identities and systems fictional.
"""
import json
import sys
from collections import defaultdict
from datetime import datetime, timedelta

GAP_MIN, BURST, BURST_WIN, REVOKE_MIN = 10, 5, 10, 5


def ts(s):
    return datetime.fromisoformat(s)


def monitor(events):
    alerts = []
    events = sorted(events, key=lambda e: e["ts"])
    # M1 telemetry gaps per source
    last = {}
    for e in events:
        src = e["source"]
        if src in last and ts(e["ts"]) - last[src] > timedelta(minutes=GAP_MIN):
            gap = int((ts(e["ts"]) - last[src]).total_seconds() // 60)
            alerts.append(("M1", e["ts"], f"source {src} silent for {gap} min before this event"))
        last[src] = ts(e["ts"])
    # M2 PDP fail-safe decisions
    fs = [e for e in events if e.get("kind") == "decision" and e.get("path") == "fail_closed"]
    if fs:
        alerts.append(("M2", fs[0]["ts"], f"{len(fs)} decisions taken by fail-closed path "
                       f"({fs[0]['ts']} to {fs[-1]['ts']}): PDP unavailable"))
    # M3 policy changes without ticket
    for e in events:
        if e.get("kind") == "policy_change" and not e.get("ticket"):
            alerts.append(("M3", e["ts"], f"policy change by {e['actor']} ({e['change']}) "
                           "has no change ticket"))
    # M4 deny bursts
    denies = defaultdict(list)
    for e in events:
        if e.get("kind") == "decision" and e.get("decision") == "DENY" and e.get("path") != "fail_closed":
            denies[e["user"]].append(ts(e["ts"]))
    for user, times in denies.items():
        for i in range(len(times)):
            win = [t for t in times[i:] if t - times[i] <= timedelta(minutes=BURST_WIN)]
            if len(win) >= BURST:
                alerts.append(("M4", times[i].isoformat(), f"{user}: {len(win)} denies in "
                               f"{BURST_WIN} min"))
                break
    # M5 posture drift without revocation
    active = {}
    for e in events:
        k = e.get("kind")
        if k == "decision" and e.get("decision") == "ALLOW":
            active[e["session"]] = e
        elif k in ("session_end", "revoke"):
            active.pop(e.get("session"), None)
        elif k == "posture" and not e["compliant"]:
            for sid, d in active.items():
                if d["device"] == e["device"]:
                    revoked = any(x.get("kind") in ("revoke", "session_end")
                                  and x.get("session") == sid
                                  and timedelta(0) <= ts(x["ts"]) - ts(e["ts"])
                                  <= timedelta(minutes=REVOKE_MIN) for x in events)
                    if not revoked:
                        alerts.append(("M5", e["ts"], f"session {sid} ({d['user']}) still active "
                                       f"after device {e['device']} failed posture ({e['reason']})"))
    return sorted(alerts, key=lambda a: a[1])


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "decision_log.jsonl"
    events = [json.loads(ln) for ln in open(path, encoding="utf-8") if ln.strip()]
    alerts = monitor(events)
    print(f"{len(events)} events read from {path}")
    for code, when, msg in alerts:
        print(f"  {code} {when}  {msg}")
    print(f"summary: {len(alerts)} alerts")


if __name__ == "__main__":
    main()
