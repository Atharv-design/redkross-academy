"""CT2 model solution: roadmap phase status from the assurance matrix.
Run from LAB_ASSETS/C22: python solutions/ct2_phase_status.py roadmap_fixed.json requirements.json
Tested: CPython 3.14.4, 2026-11-08."""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from control_matrix import check  # noqa: E402

rm = json.load(open(sys.argv[1]))
reqs = {r["id"]: r for r in json.load(open(sys.argv[2]))}
base = os.path.dirname(os.path.abspath(sys.argv[2]))
status = {rid: check(r, base)[0] for rid, r in reqs.items()}
for p in sorted({i["phase"] for i in rm["initiatives"]}):
    items = [i for i in rm["initiatives"] if i["phase"] == p]
    done = sum(1 for i in items if status.get(i["validated_by"]) == "VALIDATED")
    print(f"phase {p}: {done}/{len(items)} initiatives evidenced")
    for i in items:
        print(f"  {i['id']} {i['validated_by']:4s} {status.get(i['validated_by'], 'UNKNOWN'):12s} {i['title']}")
