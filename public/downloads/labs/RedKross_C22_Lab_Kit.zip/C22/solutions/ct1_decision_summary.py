"""CT1 model solution: per-user decision summary from decision_log.jsonl.
Run from LAB_ASSETS/C22: python solutions/ct1_decision_summary.py decision_log.jsonl
Tested: CPython 3.14.4, 2026-11-08."""
import json
import sys
from collections import Counter, defaultdict

ev = [json.loads(x) for x in open(sys.argv[1] if len(sys.argv) > 1 else "decision_log.jsonl")]
per = defaultdict(Counter)
for e in ev:
    if e.get("kind") == "decision":
        key = e["decision"] + ("(fail-closed)" if e.get("path") == "fail_closed" else "")
        per[e["user"]][key] += 1
for u in sorted(per):
    print(f"{u:10s} " + ", ".join(f"{k}={v}" for k, v in sorted(per[u].items())))
fc = [e["ts"] for e in ev if e.get("path") == "fail_closed"]
print(f"fail-closed decisions: {len(fc)} from {fc[0]} to {fc[-1]}" if fc else "fail-closed: none")
