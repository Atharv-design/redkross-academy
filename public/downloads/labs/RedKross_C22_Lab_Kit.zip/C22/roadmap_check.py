"""Zero trust roadmap checker (Course 22, Module 8 capstone).

Reads roadmap.json: current and target maturity per CISA ZTMM v2.0 pillar
(Traditional, Initial, Advanced, Optimal) and a list of initiatives with
phase, pillar, dependencies, owner and the requirement ID (requirements.json,
Module 7) that will validate it. Checks, from files only:
  - every pillar and cross-cutting capability has a current and target stage
  - no target skips more than two stages in the plan horizon
  - every pillar whose target is above current has at least one initiative
  - dependencies are scheduled in an earlier or the same phase
  - every initiative has an owner and a validating requirement that exists
Prints a maturity table and the findings. Exit 1 if any finding.
Run: python roadmap_check.py roadmap.json [requirements.json]
Tested: CPython 3.14.4, 2026-11-08. Organisation and plan are fictional.
"""
import json
import sys

STAGES = ["Traditional", "Initial", "Advanced", "Optimal"]
AREAS = ["Identity", "Devices", "Networks", "Applications and Workloads", "Data",
         "Visibility and Analytics", "Automation and Orchestration", "Governance"]


def check(rm, req_ids):
    f = []
    mat = rm.get("maturity", {})
    for a in AREAS:
        m = mat.get(a)
        if not m:
            f.append(f"{a}: no current/target maturity stated")
            continue
        cur, tgt = STAGES.index(m["current"]), STAGES.index(m["target"])
        if tgt - cur > 2:
            f.append(f"{a}: target {m['target']} skips more than two stages from {m['current']}")
        if tgt > cur and not any(i["pillar"] == a for i in rm["initiatives"]):
            f.append(f"{a}: target above current but no initiative planned")
    by_id = {i["id"]: i for i in rm["initiatives"]}
    for i in rm["initiatives"]:
        for d in i.get("depends_on", []):
            dep = by_id.get(d)
            if dep is None:
                f.append(f"{i['id']}: depends on unknown initiative {d}")
            elif dep["phase"] > i["phase"]:
                f.append(f"{i['id']} (phase {i['phase']}) depends on {d} scheduled later "
                         f"(phase {dep['phase']})")
        if not i.get("owner"):
            f.append(f"{i['id']}: no owner")
        if i.get("validated_by") not in req_ids:
            f.append(f"{i['id']}: validating requirement {i.get('validated_by')!r} not in matrix")
    return f


def main():
    rm = json.load(open(sys.argv[1] if len(sys.argv) > 1 else "roadmap.json", encoding="utf-8"))
    reqs = json.load(open(sys.argv[2] if len(sys.argv) > 2 else "requirements.json", encoding="utf-8"))
    req_ids = {r["id"] for r in reqs}
    print(f"{'area':30s} {'current':12s} target")
    for a in AREAS:
        m = rm.get("maturity", {}).get(a, {})
        print(f"{a:30s} {m.get('current', '-'):12s} {m.get('target', '-')}")
    for p in sorted({i["phase"] for i in rm["initiatives"]}):
        ids = [i["id"] for i in rm["initiatives"] if i["phase"] == p]
        print(f"phase {p}: {', '.join(ids)}")
    findings = check(rm, req_ids)
    for x in findings:
        print(f"  FINDING {x}")
    print(f"summary: {len(rm['initiatives'])} initiatives, {len(findings)} findings -> "
          f"{'FAIL' if findings else 'PASS'}")
    return 1 if findings else 0


if __name__ == "__main__":
    sys.exit(main())
