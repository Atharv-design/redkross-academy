"""Architecture design-review checker (Course 22 Modules 5-7).

Evaluates a fictional Tamarind service catalogue against architecture
guardrails derived from data classification, key custody, logging and
resilience requirements. Prints findings per service and a summary.
Run: python arch_review.py      Tested: CPython 3.14.4, 2026-11-07.
"""
SERVICES = [  # name, data class, encryption at rest key, key admins, data admins, tls,
              # logs to central SIEM, log retention days, replicas, admin MFA, internet-facing, behind PEP
    dict(name="shipment-api", data="confidential", key="kms-cmk", key_admins={"sec-keys"},
         data_admins={"app-ops"}, tls="1.3", central_logs=True, retention=365, replicas=3,
         admin_mfa="fido2", internet=True, pep=True),
    dict(name="customer-db", data="restricted", key="kms-cmk", key_admins={"app-ops"},
         data_admins={"app-ops"}, tls="1.2", central_logs=True, retention=90, replicas=2,
         admin_mfa="fido2", internet=False, pep=True),
    dict(name="payroll-export", data="restricted", key="provider-default", key_admins=set(),
         data_admins={"finance-it"}, tls="1.2", central_logs=False, retention=30, replicas=1,
         admin_mfa="otp", internet=False, pep=False),
    dict(name="partner-sftp", data="confidential", key="kms-cmk", key_admins={"sec-keys"},
         data_admins={"integration"}, tls="1.0", central_logs=True, retention=200, replicas=1,
         admin_mfa="password", internet=True, pep=False),
]
CRITICAL = {"shipment-api", "customer-db"}          # from the BIA (Course 17 Module 5)
LOG_RETENTION_MIN = 180                             # CERT-In Directions: 180 days


def review(s):
    f = []
    if s["data"] == "restricted" and s["key"] != "kms-cmk":
        f.append("restricted data must use a customer-managed key in KMS/HSM")
    if s["key"] == "kms-cmk" and s["key_admins"] & s["data_admins"]:
        f.append("key custody not separated: same team administers keys and data")
    if s["tls"] not in ("1.2", "1.3"):
        f.append(f"TLS {s['tls']} below minimum 1.2")
    if not s["central_logs"]:
        f.append("no central logging (blind spot for detection and investigation)")
    if s["retention"] < LOG_RETENTION_MIN:
        f.append(f"log retention {s['retention']}d < {LOG_RETENTION_MIN}d (CERT-In)")
    if s["name"] in CRITICAL and s["replicas"] < 2:
        f.append("critical service with single replica (single point of failure)")
    if s["admin_mfa"] not in ("fido2",) and s["data"] in ("restricted", "confidential"):
        f.append(f"admin MFA '{s['admin_mfa']}' not phishing-resistant")
    if s["internet"] and not s["pep"]:
        f.append("internet-facing without policy enforcement point (direct exposure)")
    return f


total = 0
for s in SERVICES:
    findings = review(s)
    total += len(findings)
    print(f"{s['name']:15} [{s['data']:12}] {'OK' if not findings else str(len(findings)) + ' finding(s)'}")
    for x in findings:
        print(f"    - {x}")
print(f"summary: {total} findings across {len(SERVICES)} services")
