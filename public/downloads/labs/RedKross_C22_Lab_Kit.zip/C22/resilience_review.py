"""Monitoring and resilience architecture review (Course 22, Module 6).

Reads a JSON description of an organisation's logging and resilience
architecture (no network access, no live systems) and reports gaps:
  - required telemetry sources missing or not sent to the central platform
  - retention below the policy minimum (default 180 days)
  - no time synchronisation on a source
  - central log store not immutable / single collector (single point of failure)
  - policy decision point (PDP) failure mode not defined per sensitivity
    (restricted resources must fail closed, with a documented break-glass path)
  - backups not immutable/offline or restore not tested within the RTO
  - incident-response tooling dependent on the production identity provider
Run: python resilience_review.py [telemetry_arch.json]
Exit code 1 if any HIGH finding. Tested: CPython 3.14.4, 2026-11-08.
All organisations, systems and values are fictional.
"""
import json
import sys

REQUIRED_SOURCES = {
    "idp": "identity provider sign-ins and token issuance",
    "pdp": "policy decision log (every ALLOW / STEP_UP / DENY with reasons)",
    "pep": "enforcement point / gateway access log",
    "edr": "endpoint detection and response telemetry",
    "dns": "DNS resolver query log",
    "cloud_control_plane": "cloud control-plane audit log",
    "kms": "key management (key use and key policy changes)",
}


def review(arch):
    f = []  # (severity, area, message)
    min_ret = arch.get("policy", {}).get("min_retention_days", 180)
    srcs = {s["type"]: s for s in arch.get("sources", [])}
    for t, desc in REQUIRED_SOURCES.items():
        s = srcs.get(t)
        if s is None:
            f.append(("HIGH", "coverage", f"missing source '{t}' ({desc})"))
            continue
        if not s.get("central", False):
            f.append(("HIGH", "coverage", f"{s['name']}: not forwarded to central platform"))
        if s.get("retention_days", 0) < min_ret:
            f.append(("MEDIUM", "retention",
                      f"{s['name']}: retention {s.get('retention_days', 0)}d < {min_ret}d"))
        if not s.get("time_sync", False):
            f.append(("MEDIUM", "time", f"{s['name']}: no time synchronisation (timeline risk)"))
    store = arch.get("central_store", {})
    if not store.get("immutable", False):
        f.append(("HIGH", "integrity", "central log store is not immutable (logs can be altered)"))
    if store.get("collectors", 1) < 2:
        f.append(("MEDIUM", "availability", "single log collector (single point of failure)"))
    if not store.get("pipeline_health_alerts", False):
        f.append(("MEDIUM", "availability", "no alert when a source stops sending (silent gaps)"))
    for res in arch.get("pdp_failure_modes", []):
        mode, sens = res.get("mode"), res.get("sensitivity")
        if mode not in ("fail_closed", "fail_open", "cached_decisions"):
            f.append(("HIGH", "failure-mode", f"{res['resource']}: PDP failure mode undefined"))
        elif sens == "restricted" and mode != "fail_closed":
            f.append(("HIGH", "failure-mode",
                      f"{res['resource']}: restricted resource set to {mode}; must fail closed"))
        if mode == "fail_closed" and not res.get("break_glass", False):
            f.append(("MEDIUM", "failure-mode",
                      f"{res['resource']}: fails closed with no documented break-glass path"))
    for b in arch.get("backups", []):
        if not (b.get("immutable") or b.get("offline")):
            f.append(("HIGH", "recovery", f"{b['system']}: backups neither immutable nor offline"))
        tested = b.get("restore_tested_hours")
        if tested is None:
            f.append(("HIGH", "recovery", f"{b['system']}: restore never tested"))
        elif tested > b.get("rto_hours", 0):
            f.append(("MEDIUM", "recovery",
                      f"{b['system']}: tested restore {tested}h exceeds RTO {b['rto_hours']}h"))
    ir = arch.get("ir_tooling", {})
    if ir.get("depends_on_production_idp", True):
        f.append(("HIGH", "incident-ready",
                  "IR tooling depends on production IdP (unusable if identity is compromised)"))
    if not ir.get("out_of_band_comms", False):
        f.append(("MEDIUM", "incident-ready", "no out-of-band communications for responders"))
    return f


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "telemetry_arch.json"
    arch = json.load(open(path, encoding="utf-8"))
    findings = review(arch)
    print(f"review of {path} ({arch.get('organisation', '?')})")
    order = {"HIGH": 0, "MEDIUM": 1}
    for sev, area, msg in sorted(findings, key=lambda x: (order[x[0]], x[1])):
        print(f"  {sev:6s} {area:14s} {msg}")
    high = sum(1 for x in findings if x[0] == "HIGH")
    print(f"summary: {len(findings)} findings ({high} HIGH) -> {'FAIL' if high else 'PASS'}")
    return 1 if high else 0


if __name__ == "__main__":
    sys.exit(main())
