"""rk_sigma - a small teaching evaluator for a SUBSET of the Sigma rule format.

Supported: logsource mapping (table LOGSOURCE below); selections that are a
map (AND of fields) or a list of maps (OR); list values (OR, or AND with the
"all" modifier); modifiers contains, startswith, endswith, re, all;
conditions using and / or / not / parentheses / "1 of x*" / "all of x*".
Not supported: correlation rules, aggregation, field references, base64
modifiers. Use sigma-cli (pySigma) for real validation and conversion; this
module exists so learners can read every line of the matching logic.

Usage:
  python rk_sigma.py scan RULE_DIR EVENTS.jsonl      hits per rule
  python rk_sigma.py test RULE_DIR TEST_DIR          unit tests (exit 1 on fail)
"""
import fnmatch
import glob
import json
import os
import re
import sys

import yaml

# Sigma logsource -> predicate over our lab event schema
LOGSOURCE = {
    ("windows", None, "process_creation"): lambda e: e.get("log") == "sysmon" and e.get("EventID") == 1,
    ("windows", "security", None): lambda e: e.get("log") == "security",
    (None, None, "dns"): lambda e: e.get("log") == "dns",
    (None, None, "firewall"): lambda e: e.get("log") == "flow",
}


def logsource_pred(ls):
    key = (ls.get("product"), ls.get("service"), ls.get("category"))
    if key not in LOGSOURCE:
        raise ValueError("unsupported logsource %r" % (key,))
    return LOGSOURCE[key]


def value_match(actual, expected, mods):
    if actual is None:
        return expected is None
    a = str(actual)
    e = str(expected)
    if "re" in mods:
        return re.search(e, a) is not None
    pattern = sigma_to_regex(e)
    if "contains" in mods:
        pattern = ".*" + pattern + ".*"
    elif "startswith" in mods:
        pattern = pattern + ".*"
    elif "endswith" in mods:
        pattern = ".*" + pattern
    # Sigma string matching is case-insensitive
    return re.fullmatch(pattern, a, re.IGNORECASE | re.DOTALL) is not None


def sigma_to_regex(value):
    """Sigma plain-value escaping: * and ? are wildcards; a backslash escapes
    *, ? or another backslash; any other backslash is literal."""
    out, i = [], 0
    while i < len(value):
        c = value[i]
        if c == "\\" and i + 1 < len(value) and value[i + 1] in "*?\\":
            out.append(re.escape(value[i + 1]))
            i += 2
            continue
        out.append(".*" if c == "*" else "." if c == "?" else re.escape(c))
        i += 1
    return "".join(out)


def field_match(event, key, expected):
    name, *mods = key.split("|")
    values = expected if isinstance(expected, list) else [expected]
    results = [value_match(event.get(name), v, mods) for v in values]
    return all(results) if "all" in mods else any(results)


def selection_match(event, sel):
    if isinstance(sel, list):                 # list of maps = OR
        return any(selection_match(event, s) for s in sel)
    return all(field_match(event, k, v) for k, v in sel.items())


TOKEN = re.compile(r"\(|\)|\b(?:and|or|not)\b|\b(?:1|all) of [\w*]+|[\w*]+")


def eval_condition(cond, detection, event):
    tokens = TOKEN.findall(cond)
    pos = [0]

    def peek():
        return tokens[pos[0]] if pos[0] < len(tokens) else None

    def take():
        pos[0] += 1
        return tokens[pos[0] - 1]

    def atom():
        t = take()
        if t == "(":
            v = expr()
            take()
            return v
        if t == "not":
            return not atom()
        m = re.match(r"(1|all) of ([\w*]+)", t)
        if m:
            names = [n for n in detection if n != "condition" and fnmatch.fnmatch(n, m.group(2))]
            vals = [selection_match(event, detection[n]) for n in names]
            return any(vals) if m.group(1) == "1" else all(vals)
        return selection_match(event, detection[t])

    def term():
        v = atom()
        while peek() == "and":
            take()
            r = atom()
            v = v and r
        return v

    def expr():
        v = term()
        while peek() == "or":
            take()
            r = term()
            v = v or r
        return v

    return expr()


class Rule:
    def __init__(self, path):
        with open(path, encoding="utf-8") as f:
            self.doc = yaml.safe_load(f)
        self.path = path
        self.title = self.doc["title"]
        self.id = self.doc["id"]
        self.level = self.doc.get("level", "medium")
        self.tags = self.doc.get("tags", [])
        self.pred = logsource_pred(self.doc["logsource"])
        self.det = self.doc["detection"]

    def match(self, event):
        return self.pred(event) and eval_condition(self.det["condition"], self.det, event)


def load_rules(rule_dir):
    return [Rule(p) for p in sorted(glob.glob(os.path.join(rule_dir, "*.yml")))]


def load_events(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def scan(rule_dir, events_path):
    rules = load_rules(rule_dir)
    events = load_events(events_path)
    for r in rules:
        hits = [e for e in events if r.match(e)]
        print("%-44s %-8s hits=%-3d %s" % (os.path.basename(r.path), r.level, len(hits),
                                           " ".join(sorted({e["host"] if "host" in e else
                                                            e.get("client", "?")
                                                            for e in hits}))))
    return rules, events


def test(rule_dir, test_dir):
    rules = {os.path.splitext(os.path.basename(r.path))[0]: r for r in load_rules(rule_dir)}
    failed = 0
    total = 0
    for tp in sorted(glob.glob(os.path.join(test_dir, "*.yml"))):
        with open(tp, encoding="utf-8") as f:
            spec = yaml.safe_load(f)
        rule = rules.get(spec["rule"])
        if rule is None:
            print("FAIL %s: rule %s not found" % (os.path.basename(tp), spec["rule"]))
            failed += 1
            continue
        for case in spec["cases"]:
            total += 1
            got = rule.match(case["event"])
            ok = got == case["expect"]
            failed += not ok
            print("%s %-36s %-40s expect=%s got=%s" % ("PASS" if ok else "FAIL", spec["rule"],
                                                        case["name"], case["expect"], got))
    untested = sorted(set(rules) - {yaml.safe_load(open(p, encoding="utf-8"))["rule"]
                                    for p in glob.glob(os.path.join(test_dir, "*.yml"))})
    for u in untested:
        print("WARN %s has no tests" % u)
    print("%d cases, %d failed, %d rules without tests" % (total, failed, len(untested)))
    return failed


if __name__ == "__main__":
    if len(sys.argv) != 4 or sys.argv[1] not in ("scan", "test"):
        print(__doc__)
        sys.exit(2)
    if sys.argv[1] == "scan":
        scan(sys.argv[2], sys.argv[3])
    else:
        sys.exit(1 if test(sys.argv[2], sys.argv[3]) else 0)
