"""Course 20 Module 8 (capstone) - build and gate a detection pack release.

Release gates, in order (any failure stops the release):
  G1 every rule has a unit-test file and all cases pass
  G2 every rule carries at least one ATT&CK technique tag
  G3 purple-team replay: no case regresses from the previous pack
  G4 false-positive budget: no rule exceeds MAX_DAILY_HITS on the
     reference day of telemetry, unless it is listed in BUDGET_EXCEPTIONS
Then writes pack/manifest.txt (sha256 of every rule) and
pack/release_report.txt.
Usage: python build_pack.py RULE_DIR TEST_DIR PREVIOUS_RULE_DIR [EVENTS.jsonl]
"""
import contextlib
import hashlib
import io
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import purple  # noqa: E402
import rk_sigma  # noqa: E402

MAX_DAILY_HITS = 25
BUDGET_EXCEPTIONS = {"rk_dns_long_txt_label": "aggregate per client in SIEM; ticket DET-112"}


def main():
    rule_dir, test_dir, prev_dir = sys.argv[1:4]
    events_path = sys.argv[4] if len(sys.argv) > 4 else "tamarind_telemetry.jsonl"
    report = []
    ok = True

    def gate(name, passed, detail):
        nonlocal ok
        ok = ok and passed
        line = "%s %-28s %s" % ("PASS" if passed else "FAIL", name, detail)
        report.append(line)
        print(line)

    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        failed = rk_sigma.test(rule_dir, test_dir)
    summary = buf.getvalue().strip().splitlines()[-1]
    untested = int(re.search(r"(\d+) rules without tests", summary).group(1))
    gate("G1 unit tests", failed == 0 and untested == 0, summary)

    rules = rk_sigma.load_rules(rule_dir)
    untagged = [os.path.basename(r.path) for r in rules
                if not any(re.fullmatch(r"attack\.t\d{4}(\.\d{3})?", t) for t in r.tags)]
    gate("G2 ATT&CK technique tags", not untagged, "untagged: %s" % (", ".join(untagged) or "none"))

    new, old = purple.replay(rule_dir), purple.replay(prev_dir)
    regressed = [c for c in new if old[c] and not new[c]]
    gate("G3 purple replay", not regressed, "detected %d/%d (previous %d/%d); regressed: %s" % (
        sum(1 for v in new.values() if v), len(new), sum(1 for v in old.values() if v), len(old),
        ", ".join(regressed) or "none"))

    events = rk_sigma.load_events(events_path)
    over = []
    for r in rules:
        n = sum(r.match(e) for e in events)
        name = os.path.basename(r.path)[:-4]
        if n > MAX_DAILY_HITS and name not in BUDGET_EXCEPTIONS:
            over.append("%s=%d" % (name, n))
    gate("G4 FP budget (<=%d/day)" % MAX_DAILY_HITS, not over,
         "over budget: %s; exceptions: %s" % (", ".join(over) or "none",
                                             "; ".join("%s (%s)" % kv for kv in
                                                       BUDGET_EXCEPTIONS.items())))
    if not ok:
        print("RELEASE BLOCKED")
        sys.exit(1)
    os.makedirs("pack", exist_ok=True)
    with open("pack/manifest.txt", "w", encoding="ascii", newline="\n") as f:
        for r in sorted(rules, key=lambda x: x.path):
            data = open(r.path, "rb").read()
            f.write("%s  %s  %s  %s\n" % (hashlib.sha256(data).hexdigest(),
                                          os.path.basename(r.path), r.level,
                                          " ".join(t for t in r.tags if t.startswith("attack.t"))))
    with open("pack/release_report.txt", "w", encoding="ascii", newline="\n") as f:
        f.write("Tamarind detection pack - release gates (FICTIONAL lab)\n")
        f.write("rules=%d source=%s previous=%s\n" % (len(rules), rule_dir, prev_dir))
        f.write("\n".join(report) + "\n")
    print("RELEASED: pack/manifest.txt (%d rules), pack/release_report.txt" % len(rules))


if __name__ == "__main__":
    main()
