"""Course 20 Module 6 - a teaching SOAR playbook engine with approval gates.

Takes alerts (rule hits from rk_sigma), groups them into one case per host,
enriches each case from a fictional asset inventory, and proposes response
actions. Safety properties demonstrated:
  * dry-run by default - nothing "executes" unless --execute is given, and
    even then the connectors only print SIMULATED (no real system is touched)
  * approval gates - containment needs a named approver; crown-jewel assets
    (tier 0) need two distinct approvers
  * idempotency - an action already completed for a case is not repeated
  * rate limit - at most MAX_CONTAINMENT containment actions per run
  * audit log - every decision appended to soar_audit.jsonl
Usage: python soar.py [--execute] [ACTION:CASE:APPROVER ...] | --selftest
"""
import json
import os
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rk_sigma  # noqa: E402

AUDIT = "soar_audit.jsonl"
MAX_CONTAINMENT = 2
ASSETS = {  # fictional CMDB extract
    "WS-07": {"owner": "user07", "tier": 2, "role": "finance workstation", "ip": "10.20.1.17"},
    "DC-01": {"owner": "it.admin", "tier": 0, "role": "domain controller", "ip": "10.20.5.5"},
    "FS-01": {"owner": "it.admin", "tier": 0, "role": "file server", "ip": "10.20.5.10"},
}
IP_TO_HOST = {a["ip"]: h for h, a in ASSETS.items()}
CONTAINMENT = {"isolate_host", "disable_account"}
SEVERITY = {"low": 1, "medium": 2, "high": 3, "critical": 4}


def audit(entry):
    entry["at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    with open(AUDIT, "a", encoding="ascii", newline="\n") as f:
        f.write(json.dumps(entry, sort_keys=True) + "\n")


def completed():
    done = set()
    if os.path.exists(AUDIT):
        for line in open(AUDIT, encoding="ascii"):
            e = json.loads(line)
            if e.get("result") == "SIMULATED-OK":
                done.add((e["action"], e["case"]))
    return done


def build_cases(rule_dir, events_path):
    rules = rk_sigma.load_rules(rule_dir)
    events = rk_sigma.load_events(events_path)
    cases = {}
    for r in rules:
        for e in events:
            if r.match(e):
                # entity resolution: DNS records carry an IP, endpoint records a host name
                key = e.get("host") or IP_TO_HOST.get(e.get("client"), e.get("client"))
                c = cases.setdefault(key, {"id": "CASE-%s" % key, "entity": key, "alerts": [],
                                           "max": 0})
                c["alerts"].append((e["ts"], r.title, r.level))
                c["max"] = max(c["max"], SEVERITY[r.level])
    return cases


def plan(case):
    steps = [("enrich_asset", False), ("collect_triage_package", False), ("notify_owner", False)]
    if case["max"] >= 3 and len({a[1] for a in case["alerts"]}) >= 3:
        steps.append(("isolate_host", True))
    return steps


def decide(action, gated, tier, approvers, already_done, execute, contained):
    """The whole safety policy in one pure function, so it can be unit-tested."""
    need = (2 if tier == 0 else 1) if gated else 0
    if already_done:
        return "SKIP-ALREADY-DONE"
    if not execute:
        return "WOULD-RUN" if len(approvers) >= need else "WOULD-WAIT-APPROVAL(%d/%d)" % (
            len(approvers), need)
    if len(approvers) < need:
        return "BLOCKED-NEEDS-APPROVAL(%d/%d)" % (len(approvers), need)
    if action in CONTAINMENT and contained >= MAX_CONTAINMENT:
        return "BLOCKED-RATE-LIMIT"
    return "SIMULATED-OK"


def selftest():
    checks = [
        ("tier-0 isolate, one approver", decide("isolate_host", True, 0, {"a"}, False, True, 0),
         "BLOCKED-NEEDS-APPROVAL(1/2)"),
        ("tier-0 isolate, two approvers", decide("isolate_host", True, 0, {"a", "b"}, False, True, 0),
         "SIMULATED-OK"),
        ("same approver twice counts once", decide("isolate_host", True, 0, set(["a", "a"]), False,
                                                    True, 0), "BLOCKED-NEEDS-APPROVAL(1/2)"),
        ("rate limit reached", decide("disable_account", True, 2, {"a"}, False, True,
                                      MAX_CONTAINMENT), "BLOCKED-RATE-LIMIT"),
        ("dry-run never executes", decide("isolate_host", True, 2, {"a"}, False, False, 0),
         "WOULD-RUN"),
        ("idempotent", decide("isolate_host", True, 2, {"a"}, True, True, 0), "SKIP-ALREADY-DONE"),
        ("ungated enrichment", decide("enrich_asset", False, 0, set(), False, True, 9),
         "SIMULATED-OK"),
    ]
    bad = 0
    for name, got, want in checks:
        bad += got != want
        print("%s %-34s %s" % ("PASS" if got == want else "FAIL", name, got))
    print("%d checks, %d failed" % (len(checks), bad))
    return bad


def main():
    if "--selftest" in sys.argv:
        sys.exit(1 if selftest() else 0)
    execute = "--execute" in sys.argv
    approvals = {}
    for a in sys.argv[1:]:
        if a.count(":") == 2:
            action, case, name = a.split(":")
            approvals.setdefault((action, case), set()).add(name)
    cases = build_cases("detections/rules", "tamarind_telemetry.jsonl")
    done = completed()
    contained = 0
    print("Mode: %s" % ("EXECUTE (simulated connectors)" if execute else "DRY-RUN"))
    for key in sorted(cases):
        c = cases[key]
        asset = ASSETS.get(key, {"owner": "unknown", "tier": 3, "role": "unmapped"})
        print("\n%s  alerts=%d  distinct_rules=%d  max_severity=%d  asset=%s tier=%d" % (
            c["id"], len(c["alerts"]), len({a[1] for a in c["alerts"]}), c["max"], asset["role"],
            asset["tier"]))
        for action, gated in plan(c):
            have = approvals.get((action, c["id"]), set())
            result = decide(action, gated, asset["tier"], have, (action, c["id"]) in done,
                            execute, contained)
            if result == "SIMULATED-OK" and action in CONTAINMENT:
                contained += 1
            print("  %-24s gated=%-5s approvers=%-14s -> %s" % (action, gated,
                                                               ",".join(sorted(have)) or "-", result))
            audit({"case": c["id"], "action": action, "gated": gated, "approvers": sorted(have),
                   "mode": "execute" if execute else "dry-run", "result": result})


if __name__ == "__main__":
    main()
