"""Course 20 Module 3 - DNS and flow analytics on the synthetic dataset.

Part 1 DNS: per-client query volume, NXDOMAIN ratio, TXT share and the
  longest first label; flags clients whose behaviour departs from the fleet.
Part 2 Flow: groups connections by (src, dst, dport) and measures how regular
  the gaps between them are (coefficient of variation, CV = stdev / mean).
  Very regular, frequent, small connections are a *lead* for investigation
  (software updaters and monitoring agents are regular too).
Part 3 Volume: largest outbound transfers with destination context.
Usage: python netdetect.py [EVENTS.jsonl]
"""
import json
import statistics
import sys
from collections import defaultdict
from datetime import datetime

PATH = sys.argv[1] if len(sys.argv) > 1 else "tamarind_telemetry.jsonl"
INTERNAL = "10.20."


def t(s):
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%S.%fZ")


def main():
    events = [json.loads(line) for line in open(PATH, encoding="utf-8")]
    dns = [e for e in events if e["log"] == "dns"]
    flows = [e for e in events if e["log"] == "flow"]

    print("== Part 1: DNS per client")
    per = defaultdict(list)
    for e in dns:
        per[e["client"]].append(e)
    print("%-12s %6s %8s %6s %9s" % ("client", "queries", "nxdomain", "txt", "max_label"))
    for c, qs in sorted(per.items(), key=lambda kv: -len(kv[1])):
        nx = sum(q["rcode"] == "NXDOMAIN" for q in qs)
        txt = sum(q["qtype"] == "TXT" for q in qs)
        lab = max(len(q["query"].split(".")[0]) for q in qs)
        mark = "  <== review" if txt > 10 or lab >= 25 else ""
        print("%-12s %6d %8d %6d %9d%s" % (c, len(qs), nx, txt, lab, mark))
    zones = defaultdict(set)
    for e in dns:
        zones[".".join(e["query"].split(".")[-2:])].add(e["query"])
    print("\nRegistered domains by number of distinct names queried (top 3):")
    for z, names in sorted(zones.items(), key=lambda kv: -len(kv[1]))[:3]:
        print("  %-28s %d distinct names" % (z, len(names)))

    print("\n== Part 2: connection regularity (pairs with >= 10 connections)")
    pairs = defaultdict(list)
    for e in flows:
        pairs[(e["src"], e["dst"], e["dport"])].append(e)
    rows = []
    for k, fs in pairs.items():
        if len(fs) < 10:
            continue
        times = sorted(t(f["ts"]) for f in fs)
        gaps = [(b - a).total_seconds() for a, b in zip(times, times[1:])]
        mean = statistics.mean(gaps)
        cv = statistics.pstdev(gaps) / mean if mean else 0
        out = statistics.median(f["bytes_out"] for f in fs)
        rows.append((cv, k, len(fs), mean, out))
    print("%-12s %-15s %5s %6s %9s %6s %10s" % ("src", "dst", "dport", "count", "mean_gap", "cv",
                                                "median_out"))
    for cv, k, n, mean, out in sorted(rows):
        mark = "  <== regular" if cv < 0.1 else ""
        print("%-12s %-15s %5d %6d %8.0fs %6.3f %10d%s" % (k[0], k[1], k[2], n, mean, cv, out, mark))

    print("\n== Part 3: largest outbound transfers")
    for e in sorted(flows, key=lambda f: -f["bytes_out"])[:4]:
        scope = "internal" if e["dst"].startswith(INTERNAL) else "EXTERNAL"
        print("  %s %-12s -> %-15s :%-4d out=%11d in=%7d %s" % (
            e["ts"][11:19], e["src"], e["dst"], e["dport"], e["bytes_out"], e["bytes_in"], scope))


if __name__ == "__main__":
    main()
