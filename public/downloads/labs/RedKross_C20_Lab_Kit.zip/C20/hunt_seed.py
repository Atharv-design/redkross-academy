"""Course 20 Module 5 - hunt validation helper: copy the dataset and append one
synthetic known-positive 4698 event (BK-01, script host from Public folder).
Usage: python hunt_seed.py tamarind_telemetry.jsonl seeded.jsonl
"""
import json, shutil, sys
src, dst = sys.argv[1], sys.argv[2]
shutil.copy(src, dst)
seed = {"ts": "2026-11-03T15:00:00.000Z", "log": "security", "EventID": 4698, "host": "BK-01",
        "SubjectUserName": "it.admin", "TaskName": r"\Seed\Test",
        "TaskCommand": r"wscript.exe C:\Users\Public\x.vbs"}
with open(dst, "a", newline="\n") as f:
    f.write(json.dumps(seed) + "\n")
print(json.dumps(seed))
