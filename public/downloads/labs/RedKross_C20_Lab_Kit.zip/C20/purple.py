"""Course 20 Module 7 - purple-team detection validation by telemetry replay.

No technique is executed. Each test case is a set of SYNTHETIC log records
describing what a technique variant would leave in our telemetry (written
from public documentation such as the Microsoft about_Pwsh page). The script
  1. replays every case against a rule set and reports detected / missed,
  2. repeats with a tuned rule set,
  3. runs both rule sets over the full day of Tamarind telemetry to check
     that tuning did not add false positives (regression test).
Usage: python purple.py BASELINE_DIR TUNED_DIR [EVENTS.jsonl]
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rk_sigma  # noqa: E402

PS = "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"
PWSH = "C:\\Program Files\\PowerShell\\7\\pwsh.exe"
WORD = "C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE"


def p(image, cmd, parent="C:\\Windows\\explorer.exe", host="LAB-01"):
    return {"log": "sysmon", "EventID": 1, "host": host, "Image": image, "ParentImage": parent,
            "CommandLine": cmd}


# (case id, ATT&CK technique, description, events)
CASES = [
    ("PT-01", "T1059.001", "encoded command, full parameter name",
     [p(PS, "powershell.exe -NoProfile -EncodedCommand ZABpAHIA")]),
    ("PT-02", "T1059.001", "encoded command, documented alias -ec (pwsh)",
     [p(PWSH, "pwsh.exe -NoProfile -ec ZABpAHIA")]),
    ("PT-03", "T1059.001", "encoded command, documented alias -e (pwsh)",
     [p(PWSH, "pwsh.exe -e ZABpAHIA")]),
    ("PT-04", "T1059.001", "encoded command, Windows PowerShell, lower case",
     [p(PS, "powershell.exe -encodedcommand ZABpAHIA")]),
    ("PT-05", "T1566.001", "Word starts Windows PowerShell",
     [p(PS, "powershell.exe -NoP", parent=WORD)]),
    ("PT-06", "T1566.001", "Word starts PowerShell 7",
     [p(PWSH, "pwsh.exe -NoP", parent=WORD)]),
    ("PT-07", "T1053.005", "task runs script from Public folder",
     [{"log": "security", "EventID": 4698, "host": "LAB-01", "TaskName": "\\T",
       "TaskCommand": "wscript.exe C:\\Users\\Public\\t.vbs"}]),
    ("PT-08", "T1685.005", "Security log cleared",
     [{"log": "security", "EventID": 1102, "host": "LAB-01"}]),
]


def replay(rule_dir):
    rules = rk_sigma.load_rules(rule_dir)
    out = {}
    for cid, tid, desc, events in CASES:
        hits = sorted({os.path.basename(r.path)[:-4] for r in rules for e in events if r.match(e)})
        out[cid] = hits
    return out


def main():
    base_dir, tuned_dir = sys.argv[1], sys.argv[2]
    events_path = sys.argv[3] if len(sys.argv) > 3 else "tamarind_telemetry.jsonl"
    base, tuned = replay(base_dir), replay(tuned_dir)
    print("%-6s %-10s %-48s %-9s %s" % ("case", "technique", "variant", "baseline", "tuned"))
    for cid, tid, desc, _ in CASES:
        print("%-6s %-10s %-48s %-9s %s" % (cid, tid, desc, "DETECTED" if base[cid] else "MISSED",
                                            "DETECTED" if tuned[cid] else "MISSED"))
    for name, res in (("baseline", base), ("tuned", tuned)):
        n = sum(1 for v in res.values() if v)
        print("%s: %d/%d cases detected" % (name, n, len(CASES)))
    print("\nRegression on full dataset (hits per rule):")
    events = rk_sigma.load_events(events_path)
    b = {os.path.basename(r.path): sum(r.match(e) for e in events) for r in rk_sigma.load_rules(base_dir)}
    t = {os.path.basename(r.path): sum(r.match(e) for e in events) for r in rk_sigma.load_rules(tuned_dir)}
    changed = 0
    for k in sorted(set(b) | set(t)):
        flag = "" if b.get(k) == t.get(k) else "  <== changed"
        changed += bool(flag)
        print("  %-40s baseline=%-4s tuned=%-4s%s" % (k, b.get(k, "-"), t.get(k, "-"), flag))
    print("rules with changed hit counts: %d" % changed)


if __name__ == "__main__":
    main()
