"""Course 20 Module 2 - endpoint process trees with identity context.

Reads Sysmon-style process events (EventID 1) from the synthetic dataset,
links children to parents by ProcessGuid, prints the tree for one host and
flags edges that match a simple parent/child policy. Then lists the
authentication events for the same user and host so the analyst sees the
identity side of the story.
Usage: python proctree.py HOST [EVENTS.jsonl]
"""
import json
import ntpath
import sys

HOST = sys.argv[1] if len(sys.argv) > 1 else "WS-07"
PATH = sys.argv[2] if len(sys.argv) > 2 else "tamarind_telemetry.jsonl"

OFFICE = {"winword.exe", "excel.exe", "powerpnt.exe", "outlook.exe"}
SHELLS = {"powershell.exe", "pwsh.exe", "cmd.exe", "wscript.exe", "cscript.exe", "mshta.exe"}
DISCOVERY = {"whoami.exe", "net.exe", "net1.exe", "nltest.exe", "systeminfo.exe"}
PERSIST = {"schtasks.exe", "reg.exe", "sc.exe"}
ARCHIVE = {"tar.exe", "7z.exe", "rar.exe"}


def flag(parent, child):
    p, c = parent.lower(), child.lower()
    if p in OFFICE and c in SHELLS:
        return "OFFICE->SHELL"
    if p in SHELLS and c in DISCOVERY:
        return "SHELL->DISCOVERY"
    if p in SHELLS and c in PERSIST:
        return "SHELL->PERSISTENCE"
    if p in SHELLS and c in ARCHIVE:
        return "SHELL->ARCHIVE"
    return ""


def main():
    events = [json.loads(line) for line in open(PATH, encoding="utf-8")]
    procs = [e for e in events if e["log"] == "sysmon" and e["EventID"] == 1 and e["host"] == HOST]
    by_guid = {e["ProcessGuid"]: e for e in procs}
    children = {}
    roots = []
    for e in procs:
        if e["ParentProcessGuid"] in by_guid:
            children.setdefault(e["ParentProcessGuid"], []).append(e)
        else:
            roots.append(e)
    flagged = []

    def show(e, depth):
        name = ntpath.basename(e["Image"])
        parent = by_guid.get(e["ParentProcessGuid"])
        f = flag(ntpath.basename(parent["Image"]), name) if parent else ""
        if f:
            flagged.append((e["ts"], f, e["CommandLine"]))
        cmd = e["CommandLine"] if len(e["CommandLine"]) <= 60 else e["CommandLine"][:57] + "..."
        print("%s %s%s  [%s] %s" % (e["ts"][11:19], "  " * depth, name, e["User"].split("\\")[-1],
                                    cmd) + ("   <== " + f if f else ""))
        for c in sorted(children.get(e["ProcessGuid"], []), key=lambda x: x["ts"]):
            show(c, depth + 1)

    print("Process tree for %s (%d process events)" % (HOST, len(procs)))
    for r in sorted(roots, key=lambda x: x["ts"]):
        show(r, 0)
    print("\nFlagged edges: %d" % len(flagged))
    for t, f, cmd in flagged:
        print("  %s %-19s %s" % (t[11:19], f, cmd[:70]))
    users = {e["User"].split("\\")[-1] for e in procs}
    print("\nIdentity context (security log) for users %s or source %s:" % (sorted(users), HOST))
    ips = {e["IpAddress"] for e in events if e["log"] == "security" and e.get("WorkstationName") == HOST}
    for e in events:
        if e["log"] != "security":
            continue
        if e.get("TargetUserName") in users or e.get("SubjectUserName") in users or \
                e.get("IpAddress") in ips or e["host"] == HOST:
            who = e.get("TargetUserName") or e.get("SubjectUserName")
            if e["EventID"] == 1102:
                extra = "security log cleared"
            else:
                extra = e.get("TaskName") or "type=%s src=%s" % (e.get("LogonType"), e.get("IpAddress"))
            print("  %s %-6s %-5s %-10s %s" % (e["ts"][11:19], e["host"], e["EventID"], who, extra))


if __name__ == "__main__":
    main()
