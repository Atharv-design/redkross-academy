"""Course 20 shared lab dataset: synthetic telemetry for the FICTIONAL company
"Tamarind Freight" (one working day, 2026-11-03 UTC).

Writes tamarind_telemetry.jsonl - one JSON event per line - with four logs:
  sysmon    process creation (EventID 1) in Sysmon-style field names
  security  Windows-style logon (4624/4625), scheduled task (4698), log
            cleared (1102)
  dns       resolver query log (query, qtype, rcode, client)
  flow      network flow summaries (src, dst, dport, bytes_out, bytes_in)

A hidden incident storyline sits inside ordinary business noise, including
benign activity that looks suspicious (IT admin PowerShell, a backup job).
Every host, user, domain (.example) and address (RFC 1918 / RFC 5737) is
fictional. Deterministic: fixed random seed, so every learner gets the same
file. No real product exported these records.
"""
import json
import random
import sys
from datetime import datetime, timedelta, timezone

SEED = 2003
DAY = datetime(2026, 11, 3, 0, 0, 0, tzinfo=timezone.utc)
OUT = sys.argv[1] if len(sys.argv) > 1 else "tamarind_telemetry.jsonl"

rng = random.Random(SEED)
events = []
guid_n = [0]


def ts(h, m, s=0, ms=0):
    return (DAY + timedelta(hours=h, minutes=m, seconds=s, milliseconds=ms)).strftime(
        "%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def guid():
    guid_n[0] += 1
    return "{%08d-0000-0000-0000-000000000000}" % guid_n[0]


def proc(t, host, user, image, parent, cmd, pguid=None, integrity="Medium"):
    g = guid()
    events.append({"ts": t, "log": "sysmon", "EventID": 1, "host": host, "User": user,
                   "Image": image, "ParentImage": parent, "CommandLine": cmd,
                   "IntegrityLevel": integrity, "ProcessGuid": g,
                   "ParentProcessGuid": pguid or guid()})
    return g


def sec(t, host, eid, **kw):
    e = {"ts": t, "log": "security", "EventID": eid, "host": host}
    e.update(kw)
    events.append(e)


def dns(t, client, query, rcode="NOERROR", qtype="A"):
    events.append({"ts": t, "log": "dns", "client": client, "query": query,
                   "qtype": qtype, "rcode": rcode})


def flow(t, src, dst, dport, out_b, in_b, proto="tcp"):
    events.append({"ts": t, "log": "flow", "src": src, "dst": dst, "dport": dport,
                   "proto": proto, "bytes_out": out_b, "bytes_in": in_b})


W = r"C:\Windows\System32"
PS = W + r"\WindowsPowerShell\v1.0\powershell.exe"
WORD = r"C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE"
EXCEL = r"C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE"
CHROME = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
EXPLORER = r"C:\Windows\explorer.exe"
USERS = {"WS-%02d" % i: "TAMARIND\\user%02d" % i for i in range(1, 13)}
IP = {"WS-%02d" % i: "10.20.1.%d" % (10 + i) for i in range(1, 13)}
IP.update({"FS-01": "10.20.5.10", "DC-01": "10.20.5.5", "ADM-01": "10.20.9.9",
           "BK-01": "10.20.5.20"})
BENIGN_DOMAINS = ["portal.tamarind.example", "mail.tamarind.example",
                  "updates.vendor-a.example", "cdn.vendor-b.example",
                  "docs.partner-c.example", "time.tamarind.example"]

# ---- business noise -------------------------------------------------------
EXPLORER_GUID = {}
for host, user in USERS.items():
    h0 = rng.randint(7, 9)
    m0 = rng.randint(0, 59)
    sec(ts(h0, m0), "DC-01", 4624, TargetUserName=user.split("\\")[1], LogonType=2,
        WorkstationName=host, IpAddress=IP[host])
    ex = proc(ts(h0, m0, 20), host, user, EXPLORER, W + r"\userinit.exe", "explorer.exe")
    EXPLORER_GUID[host] = ex
    for _ in range(rng.randint(2, 4)):
        h, m = rng.randint(h0, 17), rng.randint(0, 59)
        app = rng.choice([CHROME, WORD, EXCEL])
        proc(ts(h, m), host, user, app, EXPLORER, '"%s"' % app, pguid=ex)
    for _ in range(rng.randint(15, 25)):
        h, m, s = rng.randint(h0, 17), rng.randint(0, 59), rng.randint(0, 59)
        d = rng.choice(BENIGN_DOMAINS)
        dns(ts(h, m, s), IP[host], d)
        flow(ts(h, m, s, 200), IP[host], "203.0.113.%d" % (10 + BENIGN_DOMAINS.index(d)),
             443, rng.randint(800, 9000), rng.randint(5000, 400000))
    if rng.random() < 0.5:
        h, m = rng.randint(9, 17), rng.randint(0, 59)
        dns(ts(h, m), IP[host], rng.choice(["portal.tamarnd.example", "mial.tamarind.example"]),
            rcode="NXDOMAIN")

# failed logons from mistyped passwords (benign)
for i in (3, 8, 11):
    sec(ts(9, 5 + i), "DC-01", 4625, TargetUserName="user%02d" % i, LogonType=2,
        IpAddress=IP["WS-%02d" % i], Status="0xC000006A")

# IT admin PowerShell on ADM-01 - looks suspicious, is authorised
for k, (h, m) in enumerate([(10, 2), (13, 40), (15, 15)]):
    proc(ts(h, m), "ADM-01", "TAMARIND\\it.admin", PS, EXPLORER,
         "powershell.exe -NoProfile -File C:\\IT\\Scripts\\inventory_%d.ps1" % k,
         integrity="High")
    sec(ts(h, m, 30), "FS-01", 4624, TargetUserName="it.admin", LogonType=3,
        IpAddress=IP["ADM-01"])

# nightly backup job: large flows, scheduled task registered by IT change CHG-4471
sec(ts(11, 0), "BK-01", 4698, SubjectUserName="it.admin", TaskName="\\Tamarind\\NightlyBackup",
    TaskCommand=r"C:\Backup\rkbackup.exe --profile nightly")
for m in range(0, 30, 5):
    flow(ts(1, m), IP["FS-01"], IP["BK-01"], 445, 900_000_000, 40_000)

# ---- hidden incident storyline (synthetic records only) -------------------
V, VIP, VUSER = "WS-07", IP["WS-07"], "TAMARIND\\user07"
dns(ts(10, 41, 2), VIP, "invoices-share.example")
flow(ts(10, 41, 3), VIP, "198.51.100.40", 443, 1200, 88000)
w = proc(ts(10, 42, 10), V, VUSER, WORD, EXPLORER,
         '"WINWORD.EXE" /n "C:\\Users\\user07\\Downloads\\Invoice_Nov.docm"', pguid=EXPLORER_GUID[V])
p = proc(ts(10, 42, 31), V, VUSER, PS, WORD,
         "powershell.exe -NoP -W Hidden -EncodedCommand SQBFAFgAIAAoAE4AZQB3AA==", pguid=w)
proc(ts(10, 43, 5), V, VUSER, W + r"\whoami.exe", PS, "whoami.exe /groups", pguid=p)
proc(ts(10, 43, 20), V, VUSER, W + r"\net.exe", PS, "net.exe group \"Domain Admins\" /domain",
     pguid=p)
# periodic check-in to a lab-fictional domain with ~300 s interval and small jitter
t = DAY + timedelta(hours=10, minutes=44)
while t < DAY + timedelta(hours=17, minutes=30):
    label = "".join(rng.choice("abcdefghijklmnopqrstuvwxyz0123456789") for _ in range(28))
    s = t.strftime("%Y-%m-%dT%H:%M:%S.000Z")
    dns(s, VIP, label + ".cdn-sync.example", qtype="TXT")
    flow(s, VIP, "198.51.100.23", 443, rng.randint(400, 520), rng.randint(300, 420))
    t += timedelta(seconds=300 + rng.randint(-12, 12))
sec(ts(10, 47, 0), V, 4698, SubjectUserName="user07", TaskName="\\Microsoft\\OneDriveSync",
    TaskCommand=PS + " -NoP -W Hidden -File C:\\Users\\Public\\sync.ps1")
proc(ts(10, 47, 0), V, VUSER, W + r"\schtasks.exe", PS,
     'schtasks.exe /Create /SC ONLOGON /TN "\\Microsoft\\OneDriveSync" /TR "powershell.exe '
     '-NoP -W Hidden -File C:\\Users\\Public\\sync.ps1"', pguid=p)
for k in range(6):
    sec(ts(12, 10, 5 * k), "DC-01", 4625, TargetUserName="svc-print", LogonType=3,
        IpAddress=VIP, Status="0xC000006A")
sec(ts(12, 11, 0), "FS-01", 4624, TargetUserName="svc-print", LogonType=3, IpAddress=VIP)
proc(ts(12, 14, 0), V, VUSER, W + r"\tar.exe", PS,
     "tar.exe -czf C:\\Users\\Public\\q4.tgz \\\\FS-01\\Finance\\Q4", pguid=p)
flow(ts(12, 31, 0), VIP, "198.51.100.23", 443, 312_000_000, 9000)
sec(ts(12, 40, 0), V, 1102, SubjectUserName="user07")

events.sort(key=lambda e: e["ts"])
with open(OUT, "w", encoding="ascii", newline="\n") as f:
    for e in events:
        f.write(json.dumps(e, sort_keys=True) + "\n")
counts = {}
for e in events:
    counts[e["log"]] = counts.get(e["log"], 0) + 1
print("wrote %s: %d events %s" % (OUT, len(events), dict(sorted(counts.items()))))
