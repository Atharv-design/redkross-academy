"""Writes the Course 20 detection pack (rules/) and unit tests (tests/)."""
import os
import uuid

NS = uuid.UUID("6f1c1a2e-2020-4c20-9c20-202020202020")
os.makedirs("rules", exist_ok=True)
os.makedirs("tests", exist_ok=True)

RULES = {
"rk_office_spawns_powershell": dict(
 title="Office application spawns PowerShell", tags=["attack.execution", "attack.t1059.001", "attack.initial-access", "attack.t1566.001"],
 logsource="    category: process_creation\n    product: windows",
 detection="""    selection:
        ParentImage|endswith:
            - '\\WINWORD.EXE'
            - '\\EXCEL.EXE'
            - '\\POWERPNT.EXE'
        Image|endswith: '\\powershell.exe'
    condition: selection""",
 fp="Rare legitimate add-ins that launch PowerShell; document them as filters.", level="high"),
"rk_powershell_encoded_command": dict(
 title="PowerShell started with an encoded command", tags=["attack.execution", "attack.t1059.001", "attack.stealth", "attack.t1027"],
 logsource="    category: process_creation\n    product: windows",
 detection="""    selection:
        Image|endswith: '\\powershell.exe'
        CommandLine|contains: ' -EncodedCommand '
    condition: selection""",
 fp="Some management agents pass encoded commands; filter by signed parent.", level="medium"),
"rk_schtask_user_writable_path": dict(
 title="Scheduled task created that runs from a user-writable path", tags=["attack.persistence", "attack.t1053.005"],
 logsource="    product: windows\n    service: security",
 detection="""    selection:
        EventID: 4698
        TaskCommand|contains:
            - '\\Users\\Public\\'
            - '\\AppData\\'
            - '\\Temp\\'
    condition: selection""",
 fp="Per-user updaters installed under AppData.", level="high"),
"rk_security_log_cleared": dict(
 title="Windows Security event log cleared", tags=["attack.defense-impairment", "attack.t1685.005"],
 logsource="    product: windows\n    service: security",
 detection="""    selection:
        EventID: 1102
    condition: selection""",
 fp="Documented log maintenance; should be rare and change-controlled.", level="high"),
"rk_domain_admin_group_enum": dict(
 title="Domain Admins group enumerated with net.exe", tags=["attack.discovery", "attack.t1069.002"],
 logsource="    category: process_creation\n    product: windows",
 detection="""    selection:
        Image|endswith:
            - '\\net.exe'
            - '\\net1.exe'
        CommandLine|contains|all:
            - 'group'
            - 'domain admins'
    filter_admin_host:
        host: 'ADM-01'
    condition: selection and not filter_admin_host""",
 fp="Administrators auditing group membership from the admin workstation (filtered).", level="medium"),
"rk_dns_long_txt_label": dict(
 title="TXT query with a long random-looking first label", tags=["attack.command-and-control", "attack.t1071.004"],
 logsource="    category: dns",
 detection="""    selection:
        qtype: 'TXT'
        query|re: '^[a-z0-9]{25,}\\.'
    condition: selection""",
 fp="Some security and email-authentication services use long TXT labels; allowlist them.", level="medium"),
"rk_archive_of_network_share": dict(
 title="Archive tool run against a network share", tags=["attack.collection", "attack.t1560.001"],
 logsource="    category: process_creation\n    product: windows",
 detection="""    selection_tool:
        Image|endswith:
            - '\\tar.exe'
            - '\\7z.exe'
            - '\\rar.exe'
    selection_unc:
        CommandLine|contains: ' \\\\\\\\'
    condition: all of selection_*""",
 fp="Backup or migration jobs; these should run from service accounts on servers.", level="medium"),
}

for name, r in RULES.items():
    rid = uuid.uuid5(NS, name)
    tags = "\n".join("    - " + t for t in r["tags"])
    text = f"""title: {r['title']}
id: {rid}
status: experimental
description: RedKross Course 20 lab rule (fictional environment). {r['title']}.
author: RedKross Academy
date: 2026-11-07
tags:
{tags}
logsource:
{r['logsource']}
detection:
{r['detection']}
falsepositives:
    - {r['fp']}
level: {r['level']}
"""
    with open(f"rules/{name}.yml", "w", newline="\n") as f:
        f.write(text)

P = "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"
W = "C:\\Windows\\System32"
WORD = "C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE"
TESTS = {
"rk_office_spawns_powershell": [
 ("word_to_powershell", True, dict(log="sysmon", EventID=1, ParentImage=WORD, Image=P, host="WS-01")),
 ("explorer_to_powershell", False, dict(log="sysmon", EventID=1, ParentImage="C:\\Windows\\explorer.exe", Image=P, host="WS-01")),
 ("word_to_chrome", False, dict(log="sysmon", EventID=1, ParentImage=WORD, Image="C:\\chrome.exe", host="WS-01")),
],
"rk_powershell_encoded_command": [
 ("long_flag", True, dict(log="sysmon", EventID=1, Image=P, CommandLine="powershell.exe -NoP -EncodedCommand SQBF", host="WS-01")),
 ("script_file", False, dict(log="sysmon", EventID=1, Image=P, CommandLine="powershell.exe -File a.ps1", host="WS-01")),
],
"rk_schtask_user_writable_path": [
 ("public_path", True, dict(log="security", EventID=4698, TaskCommand="powershell.exe -File C:\\Users\\Public\\x.ps1", host="WS-01")),
 ("program_files", False, dict(log="security", EventID=4698, TaskCommand="C:\\Backup\\rkbackup.exe --profile nightly", host="BK-01")),
],
"rk_security_log_cleared": [
 ("cleared", True, dict(log="security", EventID=1102, host="WS-01")),
 ("logon", False, dict(log="security", EventID=4624, host="WS-01")),
],
"rk_domain_admin_group_enum": [
 ("workstation", True, dict(log="sysmon", EventID=1, Image=W + "\\net.exe", CommandLine='net.exe group "Domain Admins" /domain', host="WS-03")),
 ("admin_host_filtered", False, dict(log="sysmon", EventID=1, Image=W + "\\net.exe", CommandLine='net group "domain admins" /domain', host="ADM-01")),
 ("other_group", False, dict(log="sysmon", EventID=1, Image=W + "\\net.exe", CommandLine="net.exe group Finance /domain", host="WS-03")),
],
"rk_dns_long_txt_label": [
 ("random_label", True, dict(log="dns", qtype="TXT", query="k3j9x0q2m5n8b1v4c7z6l0p9a2s5.cdn-sync.example")),
 ("short_label", False, dict(log="dns", qtype="TXT", query="mail.tamarind.example")),
 ("long_label_a_record", False, dict(log="dns", qtype="A", query="k3j9x0q2m5n8b1v4c7z6l0p9a2s5.cdn-sync.example")),
],
"rk_archive_of_network_share": [
 ("tar_unc", True, dict(log="sysmon", EventID=1, Image=W + "\\tar.exe", CommandLine="tar.exe -czf out.tgz \\\\FS-01\\Finance", host="WS-01")),
 ("tar_rooted_local_path", False, dict(log="sysmon", EventID=1, Image=W + "\\tar.exe", CommandLine="tar.exe -czf out.tgz \\Work", host="WS-01")),
 ("tar_local", False, dict(log="sysmon", EventID=1, Image=W + "\\tar.exe", CommandLine="tar.exe -czf out.tgz C:\\Work", host="WS-01")),
],
}
import yaml, json
for rule, cases in TESTS.items():
    doc = {"rule": rule, "cases": []}
    for name, exp, ev in cases:
        doc["cases"].append({"name": name, "expect": exp, "event": ev})
    with open(f"tests/{rule}.yml", "w", newline="\n") as f:
        yaml.safe_dump(doc, f, sort_keys=False, width=200)
print("rules:", len(RULES), "test files:", len(TESTS))
