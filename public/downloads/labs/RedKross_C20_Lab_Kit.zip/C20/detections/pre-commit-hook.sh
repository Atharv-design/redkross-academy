#!/bin/sh
# Course 20 lab hook: block commits when any rule unit test fails
python rk_sigma.py test rules tests > .test_output.txt 2>&1
status=$?
tail -1 .test_output.txt
grep '^FAIL' .test_output.txt
exit $status
