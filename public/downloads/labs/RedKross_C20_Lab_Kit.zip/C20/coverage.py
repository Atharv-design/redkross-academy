"""Course 20 Module 1 - detection coverage matrix for the FICTIONAL Tamarind
Freight estate.

Joins three inventories that defensive engineering teams keep:
  1. telemetry sources: which hosts send which log, and retention
  2. technique priorities: ATT&CK techniques chosen from the threat model,
     with the log each needs (technique IDs checked against Enterprise
     ATT&CK 20.1 STIX data, 2026-11-07)
  3. the detection pack: Sigma rules (tags) and their unit tests
and scores each technique 0-3:
  0 = blind (required telemetry not collected)
  1 = visible (telemetry exists, no rule)
  2 = detected (rule exists, no passing unit test)
  3 = detected and tested
Usage: python coverage.py [RULE_DIR] [TEST_DIR]
"""
import glob
import os
import sys

import yaml

RULE_DIR = sys.argv[1] if len(sys.argv) > 1 else "detections/rules"
TEST_DIR = sys.argv[2] if len(sys.argv) > 2 else "detections/tests"

FLEET = ["WS-%02d" % i for i in range(1, 13)] + ["ADM-01", "DC-01", "FS-01", "BK-01"]
# log -> hosts sending it, retention days (fictional inventory)
TELEMETRY = {
    "sysmon": (FLEET, 90),
    "security": (["DC-01", "FS-01", "BK-01", "WS-07"], 180),   # workstation forwarding incomplete
    "dns": (["resolver"], 30),
    "flow": (["core-switch"], 30),
    "edr_registry": ([], 0),                                    # not deployed yet
}

PRIORITIES = [
    ("T1566.001", "Spearphishing Attachment", "sysmon"),
    ("T1059.001", "PowerShell", "sysmon"),
    ("T1027", "Obfuscated Files or Information", "sysmon"),
    ("T1053.005", "Scheduled Task", "security"),
    ("T1547.001", "Registry Run Keys / Startup Folder", "edr_registry"),
    ("T1069.002", "Domain Groups", "sysmon"),
    ("T1110.003", "Password Spraying", "security"),
    ("T1071.004", "Application Layer Protocol: DNS", "dns"),
    ("T1560.001", "Archive via Utility", "sysmon"),
    ("T1041", "Exfiltration Over C2 Channel", "flow"),
    ("T1685.005", "Clear Windows Event Logs", "security"),
]


def main():
    rule_tags = {}
    for p in glob.glob(os.path.join(RULE_DIR, "*.yml")):
        doc = yaml.safe_load(open(p, encoding="utf-8"))
        rule_tags[os.path.splitext(os.path.basename(p))[0]] = {t.lower() for t in doc.get("tags", [])}
    tested = set()
    for p in glob.glob(os.path.join(TEST_DIR, "*.yml")):
        spec = yaml.safe_load(open(p, encoding="utf-8"))
        if spec.get("cases"):
            tested.add(spec["rule"])
    print("Telemetry inventory")
    for log, (hosts, days) in TELEMETRY.items():
        share = "n/a" if log in ("dns", "flow") else "%d/%d hosts" % (
            len([h for h in hosts if h in FLEET]), len(FLEET))
        print("  %-13s %-14s retention=%sd" % (log, share, days))
    print()
    print("%-10s %-36s %-13s %-5s %s" % ("technique", "name", "telemetry", "score", "rules"))
    total = 0
    for tid, name, log in PRIORITIES:
        hosts, _ = TELEMETRY[log]
        rules = sorted(r for r, tags in rule_tags.items() if "attack." + tid.lower() in tags)
        if not hosts:
            score = 0
        elif not rules:
            score = 1
        elif not any(r in tested for r in rules):
            score = 2
        else:
            score = 3
        partial = log == "security" and len(hosts) < len(FLEET)
        total += score
        print("%-10s %-36s %-13s %d%-4s %s" % (tid, name[:36], log, score, "*" if partial else "",
                                              ", ".join(rules) or "-"))
    print()
    print("Coverage score %d / %d (%.0f%%). * = telemetry from only part of the fleet: "
          "a score is an upper bound for hosts that are not forwarding." % (
              total, 3 * len(PRIORITIES), 100.0 * total / (3 * len(PRIORITIES))))
    blind = [t for t, _, log in PRIORITIES if not TELEMETRY[log][0]]
    visible = [t for t, _, log in PRIORITIES
               if TELEMETRY[log][0] and not any("attack." + t.lower() in tg for tg in rule_tags.values())]
    print("Blind (fix telemetry first): %s" % (", ".join(blind) or "none"))
    print("Visible but no rule (write detections): %s" % (", ".join(visible) or "none"))


if __name__ == "__main__":
    main()
