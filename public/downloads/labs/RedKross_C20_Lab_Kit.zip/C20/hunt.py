"""Course 20 Module 5 - two hypothesis-driven hunts on the synthetic dataset.

Each hunt states its hypothesis, checks that the data it needs actually
exists (data requirements), runs a stack-count analysis, and states what a
null result would and would not mean.
  H1 Persistence: a host has a scheduled task whose command runs from a
     user-writable path or launches a script host.
  H2 Rare lineage: across the fleet, parent->child process pairs seen on
     exactly one host deserve review.
Usage: python hunt.py [EVENTS.jsonl]
"""
import json
import ntpath
import sys
from collections import defaultdict

PATH = sys.argv[1] if len(sys.argv) > 1 else "tamarind_telemetry.jsonl"
FLEET = ["WS-%02d" % i for i in range(1, 13)] + ["ADM-01", "DC-01", "FS-01", "BK-01"]
USER_WRITABLE = ("\\users\\public\\", "\\appdata\\", "\\temp\\")
SCRIPT_HOSTS = ("powershell.exe", "pwsh.exe", "wscript.exe", "cscript.exe", "mshta.exe")


def main():
    ev = [json.loads(line) for line in open(PATH, encoding="utf-8")]

    print("== H1: scheduled-task persistence")
    print("Data requirement: Windows Security 4698 from every host in scope.")
    senders = sorted({e["host"] for e in ev if e["log"] == "security"})
    missing = [h for h in FLEET if h not in senders]
    print("  hosts sending security log: %s" % ", ".join(senders))
    print("  hosts NOT sending (hunt cannot see them): %d of %d -> %s" % (
        len(missing), len(FLEET), ", ".join(missing)))
    tasks = [e for e in ev if e["log"] == "security" and e["EventID"] == 4698]
    print("  4698 events found: %d" % len(tasks))
    for e in tasks:
        cmd = e["TaskCommand"].lower()
        hit = [w for w in USER_WRITABLE if w in cmd] + [s for s in SCRIPT_HOSTS if s in cmd]
        print("  %s %-6s by %-9s %-26s %s" % (e["ts"][11:19], e["host"], e["SubjectUserName"],
                                              e["TaskName"], "SUSPECT " + ",".join(hit) if hit
                                              else "baseline (change CHG-4471)"))
    print("  Fallback for blind hosts: process telemetry for schtasks.exe /Create:")
    for e in ev:
        if e["log"] == "sysmon" and ntpath.basename(e["Image"]).lower() == "schtasks.exe" \
                and "/create" in e["CommandLine"].lower():
            print("   %s %-6s %s" % (e["ts"][11:19], e["host"], e["CommandLine"][:80]))

    print("\n== H2: rare parent->child pairs across the fleet")
    print("Data requirement: Sysmon EventID 1 with ParentImage on all hosts.")
    pair_hosts = defaultdict(set)
    for e in ev:
        if e["log"] == "sysmon" and e["EventID"] == 1:
            pair = (ntpath.basename(e["ParentImage"]).lower(), ntpath.basename(e["Image"]).lower())
            pair_hosts[pair].add(e["host"])
    print("  distinct pairs: %d" % len(pair_hosts))
    print("  %-40s %s" % ("pair (seen on exactly one host)", "host"))
    for pair, hosts in sorted(pair_hosts.items()):
        if len(hosts) == 1:
            print("  %-40s %s" % (" -> ".join(pair), ", ".join(hosts)))
    print("\nNull-result rule: 'no finding' only covers hosts and periods with data;"
          " record the gaps above in the hunt report.")


if __name__ == "__main__":
    main()
